# Setup Guide

## Prerequisites

- Python 3.9+
- Windows (agent uses `win32gui` for active app detection)

## Installation

```bash
# Clone the repository
git clone https://github.com/rishi3505/ai-continuous-authentication.git
cd ai-continuous-authentication

# Install dependencies
pip install -r requirements.txt
```

If `requirements.txt` does not exist, install manually:

```bash
pip install fastapi uvicorn pandas numpy scikit-learn joblib requests pynput psultil streamlit plotly pywin32
```

## Database Initialization

```bash
python backend/db.py
```

This creates `data/behavior.db` with all required tables.

## Generate Test Data (Optional)

```bash
python ml_service/generate_test_data.py
```

This seeds the database with 600 synthetic normal-behavior records.

## Train the Model

```bash
python ml_service/train.py
```

Trains an Isolation Forest model on the database records. Requires at least 500 records.

## Running the System

### 1. Start the ML Service (Risk Engine)

```bash
python ml_service/app.py
```

Starts on `http://localhost:8000` with auto-reload enabled.

### 2. Start the Dashboard

```bash
streamlit run dashboard/app.py
```

Opens at `http://localhost:8501`.

### 3. Start the Agent (Optional - requires physical device)

```bash
python agent/collector.py
```

Collects keyboard, mouse, and system behavioral data and sends it to the ML service.

## Verify the Setup

```bash
# Health check
curl http://localhost:8000/health

# Run integration tests
python ml_service/test_api.py
```

## Quick Start (All Services)

```bash
# Terminal 1
python ml_service/app.py

# Terminal 2
streamlit run dashboard/app.py

# Terminal 3 (optional)
python ml_service/test_api.py
```
