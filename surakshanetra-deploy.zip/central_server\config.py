"""
Central Management Server — Configuration
"""
import os
import secrets

from pathlib import Path

CENTRAL_SERVER_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = CENTRAL_SERVER_DIR.parent

SQLITE_DB_PATH = str(CENTRAL_SERVER_DIR / "data" / "central.db")

JWT_SECRET = os.environ.get("CMS_JWT_SECRET")
if not JWT_SECRET:
    JWT_SECRET = secrets.token_hex(32)
JWT_ALGORITHM = "HS256"
JWT_EXPIRY_HOURS = 24

API_KEY_HEADER = "X-API-Key"

HOST = os.environ.get("CMS_HOST", "0.0.0.0")
PORT = int(os.environ.get("CMS_PORT", "9000"))

ENABLE_HTTPS = os.environ.get("CMS_ENABLE_HTTPS", "false").lower() == "true"
SSL_CERT = os.environ.get("CMS_SSL_CERT", "")
SSL_KEY = os.environ.get("CMS_SSL_KEY", "")

HEARTBEAT_TIMEOUT_SECONDS = 120
OFFLINE_THRESHOLD_SECONDS = 180
DEGRADED_THRESHOLD_SECONDS = 60

MAX_ENDPOINTS_PER_PAGE = 100
MAX_INCIDENTS_PER_PAGE = 100
