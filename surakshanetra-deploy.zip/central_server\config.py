"""
Central Management Server — Configuration
"""
import os
import secrets

CENTRAL_SERVER_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.join(CENTRAL_SERVER_DIR, "..")

SQLITE_DB_PATH = os.path.join(CENTRAL_SERVER_DIR, "data", "central.db")

JWT_SECRET = os.environ.get("CMS_JWT_SECRET")
if not JWT_SECRET:
    JWT_SECRET = secrets.token_hex(32)
JWT_ALGORITHM = "HS256"
JWT_EXPIRY_HOURS = 24

API_KEY_HEADER = "X-API-Key"

HOST = os.environ.get("CMS_HOST", "0.0.0.0")
PORT = int(os.environ.get("CMS_PORT", "9000"))

ENABLE_HTTPS = os.environ.get("CMS_ENABLE_HTTPS", "false").lower() == "true"
SSL_CERT = os.environ.get("CMS_SSL_CERT", "")
SSL_KEY = os.environ.get("CMS_SSL_KEY", "")

HEARTBEAT_TIMEOUT_SECONDS = 120
OFFLINE_THRESHOLD_SECONDS = 180
DEGRADED_THRESHOLD_SECONDS = 60

MAX_ENDPOINTS_PER_PAGE = 100
MAX_INCIDENTS_PER_PAGE = 100
