# SurakshaNetra — STRIDE Analysis

## Version 1.0 — RC1

---

| Letter | Category | Definition |
|--------|----------|------------|
| S | Spoofing | Impersonating a user, agent, or system |
| T | Tampering | Modifying data or code in transit or at rest |
| R | Repudiation | Denying an action without audit |
| I | Information Disclosure | Exposing data to unauthorized parties |
| D | Denial of Service | Disrupting service availability |
| E | Elevation of Privilege | Gaining unauthorized access rights |

---

## 1. CMS (Central Management Server)

| Threat | Category | Existing Mitigation | Residual Risk |
|--------|----------|-------------------|---------------|
| JWT forgery with weak secret | S | `secrets.token_hex(32)` auto-generated key | LOW — env var override could still be weak |
| API key brute-force | S | 64-char hex keys | LOW — sufficient entropy |
| Password hash cracking | S | SHA-256 (salted) | MEDIUM — should use bcrypt/argon2 |
| SQL injection via behavior data | T | Parameterized queries (except `insert_behavior`) | LOW — single f-string with data.keys(), trusted-only caller |
| Path traversal in evidence download | T | Canonical path check via `os.path.commonpath` | LOW — fixed |
| Config tampering via API | T | JWT auth on all config endpoints | LOW — authorized users only |
| Audit log forgery | R | No crypto signing on audit logs | MEDIUM — no integrity verification on audit entries |
| Stack trace disclosure | I | Global handler returns generic error | LOW — traceback logged server-side |
| Database file read | I | SQLite WAL mode, file permissions | MEDIUM — no encryption at rest |
| Unauthenticated access | E | `Depends(authenticate_request)` on all 108 routes | NONE — verified in audit |
| Unauthorized admin actions | E | Role field in JWT (admin/analyst/viewer) | LOW — role checks are inline, not centralized |
| Rate limiting bypass | D | No rate limiting | MEDIUM — authenticated user could DoS |
| Connection exhaustion | D | No connection pooling limits | MEDIUM — uvicorn default workers |

### CMS Severity Summary
- **Critical**: 0 (all resolved)
- **High**: 2 (audit integrity, DB at rest encryption)
- **Medium**: 4 (rate limiting, bcrypt, connection exhaustion, query injection surface)

---

## 2. Agent Process

| Threat | Category | Existing Mitigation | Residual Risk |
|--------|----------|-------------------|---------------|
| Agent impersonation | S | API key per agent | LOW — key stored in config file |
| Config file tampering | T | Deep merge with defaults | MEDIUM — config is plaintext JSON on disk |
| Queue DB corruption | T | Graceful error handling | LOW — database is local |
| Behavioral data manipulation | T | Input validated on CMS side | LOW — CMS validates schema |
| wevtutil command injection | T | Fixed: `shell=False` + list form | NONE — fixed |
| Agent actions unlogged | R | Local logs + CMS audit | LOW — audit trail exists |
| Behavioral data exfiltration | I | HTTPS in transit | MEDIUM — offline queue is plaintext |
| pynput keylog leak | I | Non-privileged process | LOW — runs as current user |
| Offline queue overflow | D | `max_buffer_size: 5000` configurable | LOW — configurable limit |
| Resource exhaustion | D | Configurable collection intervals | LOW — rate-limited by design |
| Privilege escalation via wevtutil | E | `shell=False` | NONE — fixed |

### Agent Severity Summary
- **Critical**: 0 (all resolved)
- **High**: 0 (all resolved)
- **Medium**: 2 (config file plaintext, offline queue plaintext)

---

## 3. SOC Dashboard (React)

| Threat | Category | Existing Mitigation | Residual Risk |
|--------|----------|-------------------|---------------|
| XSS via API response | I | React JSX auto-escaping | LOW — custom JSX renders risk |
| JWT theft from browser | I | JWT in Authorization header, not localStorage | LOW — memory-only during session |
| API key in source maps | I | No API keys in frontend | NONE — keys only server-side |
| CSP bypass | I | Standard React build | MEDIUM — no explicit CSP policy in production |
| npm supply chain | T | Caret ranges, lockfile | LOW — audit recommended monthly |
| Dashboard DoS via slow queries | D | No client-side limits | LOW — API pagination exists |
| CSRF via malicious site | E | No CSRF token | LOW — JWT in header (not cookie) prevents CSRF |

### Dashboard Severity Summary
- **Critical**: 0
- **High**: 0
- **Medium**: 1 (CSP not configured)

---

## 4. ML Service

| Threat | Category | Existing Mitigation | Residual Risk |
|--------|----------|-------------------|---------------|
| Model poisoning via training | T | Only authorized data sources | LOW — internal-only training pipeline |
| Pickle deserialization attack | T | `joblib.load()` on local models only | LOW — no user-supplied models |
| Model stealing via API | I | Localhost-only binding | LOW — not exposed on network |
| Inference resource exhaustion | D | Synchronous requests | MEDIUM — no queue/rate limit for ML |

### ML Service Severity Summary
- **Critical**: 0
- **High**: 0
- **Medium**: 1 (no ML request throttling)

---

## 5. Forensics Module

| Threat | Category | Existing Mitigation | Residual Risk |
|--------|----------|-------------------|---------------|
| Path traversal during collection | T | `incident_id` sanitized with regex | NONE — fixed |
| Path traversal during download | T | Canonical path check | NONE — fixed |
| Evidence tampering after collection | T | SHA-256 hash in manifest | LOW — hash stored alongside evidence |
| Chain of custody forgery | R | Signed chain-of-custody records | LOW — SHA-256 checksums |
| Sensitive data in evidence | I | Evidence stored as plain ZIP | MEDIUM — no encryption within ZIP |
| Large evidence DoS | D | No file size limits | MEDIUM — single large ZIP could fill disk |

### Forensics Severity Summary
- **Critical**: 0 (all resolved)
- **High**: 0 (all resolved)
- **Medium**: 2 (plaintext evidence, no file size limit)

---

## 6. Threat Intelligence Module

| Threat | Category | Existing Mitigation | Residual Risk |
|--------|----------|-------------------|---------------|
| Malicious IOC injection | T | JSON parsing via `json.loads()` | LOW — validated by structure |
| Feed URL SSRF | I | Pre-configured feed list | LOW — no user-supplied feed URLs |
| IOC DB corruption | D | WAL mode, `CREATE TABLE IF NOT EXISTS` | LOW — SQLite ACID guarantees |
| Stale IOC data | R | TTL-based expiry per IOC | LOW — expiry configurable |

### Threat Intel Severity Summary
- **Critical**: 0
- **High**: 0
- **Medium**: 0

---

## 7. Overall Risk Summary

| Component | Critical | High | Medium | Low |
|-----------|----------|------|--------|-----|
| CMS | 0 | 2 | 4 | Several |
| Agent | 0 | 0 | 2 | Several |
| Dashboard | 0 | 0 | 1 | Several |
| ML Service | 0 | 0 | 1 | Several |
| Forensics | 0 | 0 | 2 | Several |
| Threat Intel | 0 | 0 | 0 | Several |
| **Total** | **0** | **2** | **10** | — |

### Outstanding High-Risk Items
1. **Audit log integrity** — No cryptographic signing of audit entries
2. **Database encryption at rest** — SQLite files are plaintext

### Outstanding Medium-Risk Items
1. Password hashing with SHA-256 (needs bcrypt/argon2)
2. No rate limiting on any endpoint
3. No Content-Security-Policy on dashboard
4. Connection pooling limits not configured
5. ML inference request throttling
6. Evidence ZIP files not encrypted
7. No file size limits on evidence upload
8. Config file stored in plaintext on agent
9. Offline queue data in plaintext
10. No account lockout on login endpoint
