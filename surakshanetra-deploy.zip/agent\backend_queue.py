import json
import os
import sqlite3
import threading
import time
from typing import Optional

import requests

from .logging_setup import get_logger

logger = get_logger("communication")

_QUEUE_DB_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
_QUEUE_DB_PATH = os.path.join(_QUEUE_DB_DIR, "agent_queue.db")

_lock = threading.Lock()


def _ensure_db():
    os.makedirs(_QUEUE_DB_DIR, exist_ok=True)
    conn = sqlite3.connect(_QUEUE_DB_PATH)
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS backend_queue (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            payload TEXT NOT NULL,
            timestamp REAL NOT NULL,
            retry_count INTEGER DEFAULT 0,
            max_retries INTEGER DEFAULT 10,
            status TEXT DEFAULT 'PENDING',
            last_error TEXT,
            created_at REAL NOT NULL
        )
    """)
    conn.commit()
    conn.close()


def enqueue(payload: dict, max_retries: int = 10):
    with _lock:
        _ensure_db()
        conn = sqlite3.connect(_QUEUE_DB_PATH)
        cursor = conn.cursor()
        now = time.time()
        cursor.execute("""
            INSERT INTO backend_queue (payload, timestamp, retry_count, max_retries, status, created_at)
            VALUES (?, ?, 0, ?, 'PENDING', ?)
        """, (json.dumps(payload), now, max_retries, now))
        conn.commit()
        conn.close()


def dequeue_batch(batch_size: int = 50) -> list:
    with _lock:
        _ensure_db()
        conn = sqlite3.connect(_QUEUE_DB_PATH)
        cursor = conn.cursor()
        cursor.execute("""
            SELECT id, payload, timestamp, retry_count, max_retries
            FROM backend_queue
            WHERE status = 'PENDING' AND retry_count < max_retries
            ORDER BY id ASC
            LIMIT ?
        """, (batch_size,))
        rows = cursor.fetchall()
        conn.close()
        return rows


def mark_success(queue_id: int):
    with _lock:
        conn = sqlite3.connect(_QUEUE_DB_PATH)
        cursor = conn.cursor()
        cursor.execute("UPDATE backend_queue SET status = 'SENT' WHERE id = ?", (queue_id,))
        conn.commit()
        conn.close()


def mark_failed(queue_id: int, error: str):
    with _lock:
        conn = sqlite3.connect(_QUEUE_DB_PATH)
        cursor = conn.cursor()
        cursor.execute("""
            UPDATE backend_queue
            SET retry_count = retry_count + 1, status = 'FAILED', last_error = ?
            WHERE id = ?
        """, (error[:500], queue_id))
        conn.commit()
        conn.close()


def mark_dropped(queue_id: int):
    with _lock:
        conn = sqlite3.connect(_QUEUE_DB_PATH)
        cursor = conn.cursor()
        cursor.execute("UPDATE backend_queue SET status = 'DROPPED' WHERE id = ?", (queue_id,))
        conn.commit()
        conn.close()


def flush(backend_url: str, batch_size: int = 50, timeout: int = 5) -> tuple:
    sent = 0
    failed = 0

    while True:
        batch = dequeue_batch(batch_size)
        if not batch:
            break

        for row in batch:
            qid, payload_json, ts, retry_count, max_retries = row
            try:
                payload = json.loads(payload_json)
                resp = requests.post(
                    f"{backend_url.rstrip('/')}/api/v1/analyze",
                    json=payload,
                    timeout=timeout
                )
                if resp.status_code == 200:
                    mark_success(qid)
                    sent += 1
                else:
                    raise ConnectionError(f"HTTP {resp.status_code}: {resp.text[:200]}")
            except Exception as e:
                mark_failed(qid, str(e))
                failed += 1
                if retry_count + 1 >= max_retries:
                    mark_dropped(qid)
                    logger.warning("Queue item %d dropped after %d retries: %s", qid, max_retries, e)

    return sent, failed


def get_queue_stats() -> dict:
    _ensure_db()
    conn = sqlite3.connect(_QUEUE_DB_PATH)
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT status, COUNT(*) FROM backend_queue GROUP BY status")
        rows = cursor.fetchall()
        stats = {"total": 0, "PENDING": 0, "SENT": 0, "FAILED": 0, "DROPPED": 0}
        for status, count in rows:
            stats[status] = count
            stats["total"] += count
        return stats
    finally:
        conn.close()


def cleanup_old_entries(older_than_hours: int = 24):
    _ensure_db()
    conn = sqlite3.connect(_QUEUE_DB_PATH)
    cursor = conn.cursor()
    cutoff = time.time() - (older_than_hours * 3600)
    cursor.execute("DELETE FROM backend_queue WHERE created_at < ? AND status IN ('SENT', 'DROPPED')", (cutoff,))
    deleted = cursor.rowcount
    conn.commit()
    conn.close()
    if deleted:
        logger.info("Cleaned up %d old queue entries", deleted)
    return deleted


def clear_all():
    _ensure_db()
    conn = sqlite3.connect(_QUEUE_DB_PATH)
    cursor = conn.cursor()
    cursor.execute("DELETE FROM backend_queue")
    count = cursor.rowcount
    conn.commit()
    conn.close()
    return count
