"""
IOC Matcher — Efficiently matches observed artifacts against the local IOC database.
Supports batch matching with configurable thresholds.
"""
import time
from typing import Optional

from threat_intelligence.ioc_manager import get_ioc_by_value
from threat_intelligence.intel_cache import IntelCache


class IOCMatcher:
    def __init__(self, cache_ttl: int = 300):
        self.cache = IntelCache(ttl=cache_ttl)
        self._stats = {"total_matches": 0, "cache_hits": 0, "cache_misses": 0, "last_match_time": 0}

    def match_value(self, value: str, value_type: Optional[str] = None) -> Optional[dict]:
        cache_key = f"match:{value_type}:{value}" if value_type else f"match:{value}"
        cached = self.cache.get(cache_key)
        if cached is not None:
            self._stats["cache_hits"] += 1
            return cached if cached.get("_match") else None
        self._stats["cache_misses"] += 1
        ioc = get_ioc_by_value(value)
        result = None
        if ioc:
            if value_type and ioc["type"] != value_type.upper():
                pass
            else:
                result = dict(ioc)
                self._stats["total_matches"] += 1
                self._stats["last_match_time"] = int(time.time())
        self.cache.set(cache_key, {"_match": bool(result), **(result or {})})
        return result

    def match_batch(self, artifacts: list[tuple[str, Optional[str]]]) -> list[dict]:
        matches = []
        for value, vtype in artifacts:
            m = self.match_value(value, vtype)
            if m:
                m["matched_value"] = value
                matches.append(m)
        return matches

    def match_payload(self, payload: dict) -> list[dict]:
        artifacts = []
        if ip := payload.get("ip_address"):
            artifacts.append((ip, "IP"))
        if domain := payload.get("domain"):
            artifacts.append((domain, "DOMAIN"))
        if url := payload.get("url"):
            artifacts.append((url, "URL"))
        if process := payload.get("active_app"):
            artifacts.append((process, "PROCESS_NAME"))
        if user_agent := payload.get("user_agent"):
            artifacts.append((user_agent, "USER_AGENT"))
        if email := payload.get("email"):
            artifacts.append((email, "EMAIL"))
        return self.match_batch(artifacts)

    def get_stats(self) -> dict:
        return {**self._stats, "cache_size": len(self.cache)}


_ioc_matcher = IOCMatcher()


def get_ioc_matcher() -> IOCMatcher:
    return _ioc_matcher


def match_value(value: str, value_type: Optional[str] = None) -> Optional[dict]:
    return _ioc_matcher.match_value(value, value_type)


def match_batch(artifacts: list[tuple[str, Optional[str]]]) -> list[dict]:
    return _ioc_matcher.match_batch(artifacts)
