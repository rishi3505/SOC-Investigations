import time
import threading
from pynput import keyboard

class KeyboardMonitor:
    """
    Monitors keyboard events tracking key presses, calculating keys per second speed,
    inter-key latency, holding durations, and exact last activities.
    """
    def __init__(self):
        self.lock = threading.Lock()
        
        self.key_press_times = {}
        self.hold_times = []
        self.latencies = []
        
        self.last_press_time = None
        self.press_count = 0
        
        # Idle tracking
        self.last_activity = time.time()
        
        self.listener = keyboard.Listener(
            on_press=self.on_press,
            on_release=self.on_release)
        
    def start(self):
        self.listener.start()
        
    def stop(self):
        self.listener.stop()
        
    def on_press(self, key):
        current_time = time.time()
        
        with self.lock:
            self.last_activity = current_time
            # Hash to ensure unrecoverable privacy-safe representations of multiple held keys
            key_id = hash(str(key))
            self.key_press_times[key_id] = current_time
            self.press_count += 1
            
            if self.last_press_time is not None:
                latency = current_time - self.last_press_time
                # Filter out absurdly high latencies that indicate long pauses, keeping focused metrics
                if latency < 10.0: 
                    self.latencies.append(latency)
                
            self.last_press_time = current_time
            
    def on_release(self, key):
        current_time = time.time()
        key_id = hash(str(key))
        
        with self.lock:
            self.last_activity = current_time
            if key_id in self.key_press_times:
                hold_time = current_time - self.key_press_times[key_id]
                self.hold_times.append(hold_time)
                del self.key_press_times[key_id]
                
    def _calculate_std_dev(self, data):
        if not data: return 0.0
        mean = sum(data) / len(data)
        variance = sum((x - mean) ** 2 for x in data) / len(data)
        return variance ** 0.5

    def get_metrics_and_reset(self):
        with self.lock:
            avg_hold_time = sum(self.hold_times) / len(self.hold_times) if self.hold_times else 0.0
            avg_latency = sum(self.latencies) / len(self.latencies) if self.latencies else 0.0
            latency_jitter = self._calculate_std_dev(self.latencies)
            
            metrics = {
                "avg_hold_time": avg_hold_time,
                "avg_key_latency": avg_latency,
                "latency_jitter": latency_jitter,
                "press_count": self.press_count,
                "last_activity": self.last_activity
            }
            
            self.hold_times.clear()
            self.latencies.clear()
            self.press_count = 0
            
            return metrics
