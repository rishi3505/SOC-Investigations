import streamlit as st
import requests
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import time
from datetime import datetime

API_BASE = "http://127.0.0.1:8000"

st.set_page_config(
    page_title="Continuous Auth Dashboard",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded"
)

st.markdown("""
<style>
    .risk-low { color: #00cc66; font-weight: bold; }
    .risk-medium { color: #ffaa00; font-weight: bold; }
    .risk-high { color: #ff3333; font-weight: bold; }
    .st-emotion-cache-1y4p8pa { padding: 1rem 1rem; }
</style>
""", unsafe_allow_html=True)

@st.cache_data(ttl=2)
def fetch_stats():
    try:
        r = requests.get(f"{API_BASE}/api/v1/dashboard/stats", timeout=3)
        return r.json() if r.status_code == 200 else None
    except:
        return None

@st.cache_data(ttl=2)
def fetch_sessions(user_id, limit=50):
    try:
        r = requests.get(f"{API_BASE}/api/v1/dashboard/sessions/{user_id}?limit={limit}", timeout=3)
        return r.json() if r.status_code == 200 else None
    except:
        return None

@st.cache_data(ttl=2)
def fetch_behavior(user_id, limit=100):
    try:
        r = requests.get(f"{API_BASE}/api/v1/dashboard/behavior/{user_id}?limit={limit}", timeout=3)
        return r.json() if r.status_code == 200 else None
    except:
        return None

@st.cache_data(ttl=5)
def fetch_locations():
    try:
        r = requests.get(f"{API_BASE}/api/v1/dashboard/locations", timeout=3)
        return r.json() if r.status_code == 200 else None
    except:
        return None

@st.cache_data(ttl=2)
def fetch_thresholds(user_id):
    try:
        r = requests.get(f"{API_BASE}/api/v1/dashboard/thresholds/{user_id}", timeout=3)
        return r.json() if r.status_code == 200 else None
    except:
        return None

@st.cache_data(ttl=5)
def fetch_incidents(user_id=None, status=None, limit=50):
    params = f"limit={limit}"
    if user_id: params += f"&user_id={user_id}"
    if status: params += f"&status={status}"
    try:
        r = requests.get(f"{API_BASE}/api/v1/incidents?{params}", timeout=3)
        return r.json() if r.status_code == 200 else None
    except:
        return None

@st.cache_data(ttl=5)
def fetch_incident_detail(incident_id):
    try:
        r = requests.get(f"{API_BASE}/api/v1/incidents/{incident_id}", timeout=3)
        return r.json() if r.status_code == 200 else None
    except:
        return None

@st.cache_data(ttl=10)
def fetch_response_history(user_id=None, limit=100):
    params = f"limit={limit}"
    if user_id: params += f"&user_id={user_id}"
    try:
        r = requests.get(f"{API_BASE}/api/v1/response-history?{params}", timeout=3)
        return r.json() if r.status_code == 200 else None
    except:
        return None

@st.cache_data(ttl=10)
def fetch_policy_audit(limit=100):
    try:
        r = requests.get(f"{API_BASE}/api/v1/policy-audit?limit={limit}", timeout=3)
        return r.json() if r.status_code == 200 else None
    except:
        return None

@st.cache_data(ttl=30)
def fetch_mitre_techniques():
    try:
        r = requests.get(f"{API_BASE}/api/v1/mitre-techniques", timeout=3)
        return r.json() if r.status_code == 200 else None
    except:
        return None

@st.cache_data(ttl=2)
def fetch_devices(limit=100):
    try:
        r = requests.get(f"{API_BASE}/api/v1/devices?limit={limit}", timeout=3)
        return r.json() if r.status_code == 200 else None
    except:
        return None

@st.cache_data(ttl=2)
def fetch_device_history(device_hash=None, limit=100):
    params = f"limit={limit}"
    if device_hash: params += f"&device_hash={device_hash}"
    try:
        r = requests.get(f"{API_BASE}/api/v1/devices/history?{params}", timeout=3)
        return r.json() if r.status_code == 200 else None
    except:
        return None

@st.cache_data(ttl=2)
def fetch_user_state(user_id):
    try:
        r = requests.get(f"{API_BASE}/api/v1/user-state/{user_id}", timeout=3)
        return r.json() if r.status_code == 200 else None
    except:
        return None

def risk_color(level):
    if level == "LOW":
        return "risk-low"
    elif level == "MEDIUM":
        return "risk-medium"
    elif level == "HIGH":
        return "risk-high"
    return ""

sidebar = st.sidebar
sidebar.title("🛡️ Navigation")
page = sidebar.radio("Go to", [
    "Overview",
    "Real-Time Monitoring",
    "Behavior Analysis",
    "User Profiles",
    "Trusted Locations",
    "Device Management",
    "Incidents",
    "Response History",
    "Policy Audit",
    "MITRE Techniques",
    "Test API"
])

sidebar.markdown("---")
sidebar.markdown("**ML Service**")
sidebar.markdown(f"`{API_BASE}`")

stats = fetch_stats()
if stats and stats.get("users"):
    default_user = stats["users"][0]["user_id"] if stats["users"] else "default_user"
else:
    default_user = "default_user"
selected_user = sidebar.text_input("User ID", value=default_user)
auto_refresh = sidebar.checkbox("Auto-refresh (2s)", value=(page == "Real-Time Monitoring"))

if auto_refresh:
    placeholder = st.empty()
    with placeholder.container():
        time.sleep(2)
        st.rerun()

if page == "Overview":
    st.title("🛡️ Continuous Authentication Dashboard")
    st.markdown("**AI-Powered Behavioral Biometrics & Anomaly Detection System**")

    col1, col2, col3, col4 = st.columns(4)
    stats = fetch_stats()
    if stats:
        col1.metric("Total Records", stats.get("total_records", 0))
        col2.metric("Total Users", stats.get("total_users", 0))
        try:
            h = requests.get(f"{API_BASE}/health", timeout=2).json()
            col3.metric("Model Loaded", "✅ Yes" if h.get("model_loaded") else "❌ No")
            col4.metric("Status", "✅ Online")
        except:
            col3.metric("Model", "⚠️ Unknown")
            col4.metric("Status", "❌ Offline")

        if stats.get("users"):
            st.subheader("User Profiles")
            users_df = pd.DataFrame(stats["users"])
            st.dataframe(users_df, use_container_width=True)

    st.subheader("System Architecture")
    st.markdown("""
    ```
    User Device → Agent (Behavior Collector) → ML Service (Risk Engine) → Dashboard
                                                    ↕
                                              Backend DB (SQLite)
    ```
    """)

elif page == "Real-Time Monitoring":
    st.title("📊 Real-Time Risk Monitoring")
    st.caption(f"Live session data for user: **{selected_user}**")

    thresholds = fetch_thresholds(selected_user)
    if thresholds:
        t = thresholds["thresholds"]
        col1, col2, col3 = st.columns(3)
        col1.metric("LOW Threshold", t.get("low", 30))
        col2.metric("MED Threshold", t.get("med", 60))
        col3.metric("HIGH Threshold", t.get("high", 85))

        samples = thresholds.get("samples_collected", 0)
        stage = "LEARNING" if samples < 200 else ("MONITORING" if samples < 500 else "PROTECTED")
        st.info(f"**Lifecycle Stage:** {stage} | **Samples:** {samples}")

    sessions = fetch_sessions(selected_user, limit=50)
    if sessions and sessions.get("sessions"):
        df = pd.DataFrame(sessions["sessions"])
        if not df.empty:
            df["timestamp"] = pd.to_datetime(df["timestamp"], unit="s")
            df = df.sort_values("timestamp")

            latest = df.iloc[-1]
            risk_level = "HIGH" if latest["is_anomalous"] else "LOW"

            c1, c2, c3 = st.columns(3)
            risk_class = risk_color(risk_level)
            c1.markdown(f"<h3>Current Risk</h3><h1 class='{risk_class}'>{risk_level}</h1>", unsafe_allow_html=True)
            c2.metric("Risk Score", f"{latest['risk_score']:.1f}")
            c3.metric("Anomalies in last 50", df["is_anomalous"].sum())

            fig = px.line(df, x="timestamp", y="risk_score",
                          title="Risk Score Trend (Last 50 Windows)",
                          labels={"risk_score": "Risk Score", "timestamp": "Time"},
                          color_discrete_sequence=["#ff6600"])
            fig.add_hline(y=t.get("high", 85), line_dash="dash", line_color="red", annotation_text="HIGH")
            fig.add_hline(y=t.get("med", 60), line_dash="dash", line_color="orange", annotation_text="MED")
            fig.add_hline(y=t.get("low", 30), line_dash="dash", line_color="green", annotation_text="LOW")
            fig.update_layout(height=400)
            st.plotly_chart(fig, use_container_width=True)

            fig2 = px.bar(df, x="timestamp", y="is_anomalous",
                          title="Anomaly Events Over Time",
                          labels={"is_anomalous": "Anomaly", "timestamp": "Time"},
                          color="is_anomalous",
                          color_discrete_map={0: "#00cc66", 1: "#ff3333"})
            fig2.update_layout(height=250)
            st.plotly_chart(fig2, use_container_width=True)

            with st.expander("Raw Session Data"):
                st.dataframe(df, use_container_width=True)
    else:
        st.warning("No session data available. Run the agent or test API first.")

elif page == "Behavior Analysis":
    st.title("📈 Behavior Data Analysis")
    st.caption(f"Analyzing behavior patterns for user: **{selected_user}**")

    behavior = fetch_behavior(selected_user, limit=200)
    if behavior and behavior.get("records"):
        df = pd.DataFrame(behavior["records"])
        if not df.empty:
            if "timestamp" in df.columns:
                df["timestamp"] = pd.to_datetime(df["timestamp"], unit="s")

            numeric_cols = df.select_dtypes(include=["number"]).columns.tolist()
            exclude = ["id", "app_switch_count", "time_of_day", "session_duration"]
            feature_cols = [c for c in numeric_cols if c not in exclude and c != "id"]

            col1, col2 = st.columns(2)
            with col1:
                feature_x = st.selectbox("X-axis feature", feature_cols, index=feature_cols.index("typing_speed") if "typing_speed" in feature_cols else 0)
            with col2:
                feature_y = st.selectbox("Y-axis feature", feature_cols, index=feature_cols.index("mouse_speed") if "mouse_speed" in feature_cols else 0)

            fig = px.scatter(df, x=feature_x, y=feature_y, color="active_app" if "active_app" in df.columns else None,
                            title=f"{feature_x} vs {feature_y}",
                            hover_data=["active_app", "city"] if "active_app" in df.columns and "city" in df.columns else None)
            st.plotly_chart(fig, use_container_width=True)

            col1, col2 = st.columns(2)
            with col1:
                feat_dist = st.selectbox("Feature distribution", feature_cols)
                fig2 = px.histogram(df, x=feat_dist, nbins=30, title=f"{feat_dist} Distribution",
                                   color_discrete_sequence=["#3366cc"])
                st.plotly_chart(fig2, use_container_width=True)

            with col2:
                app_col = "active_app" if "active_app" in df.columns else None
                if app_col:
                    app_counts = df[app_col].value_counts().reset_index()
                    app_counts.columns = [app_col, "count"]
                    fig3 = px.pie(app_counts, values="count", names=app_col, title="Active Applications")
                    st.plotly_chart(fig3, use_container_width=True)

            with st.expander("Raw Behavior Data"):
                st.dataframe(df, use_container_width=True)

            if "city" in df.columns:
                st.subheader("📍 Location Distribution")
                loc_df = df.groupby(["city", "country"]).size().reset_index(name="count")
                st.dataframe(loc_df, use_container_width=True)
    else:
        st.warning("No behavior data available.")

elif page == "User Profiles":
    st.title("👤 User Profiles & Thresholds")

    stats = fetch_stats()
    if stats and stats.get("users"):
        users_df = pd.DataFrame(stats["users"])
        st.dataframe(users_df, use_container_width=True)

        st.subheader(f"Thresholds for: {selected_user}")
        thresholds = fetch_thresholds(selected_user)
        if thresholds:
            t = thresholds["thresholds"]
            c1, c2, c3, c4 = st.columns(4)
            c1.metric("LOW", t.get("low", 30))
            c2.metric("MED", t.get("med", 60))
            c3.metric("HIGH", t.get("high", 85))
            c4.metric("Samples", thresholds.get("samples_collected", 0))

            fig = go.Figure()
            fig.add_trace(go.Bar(
                x=["LOW", "MEDIUM", "HIGH"],
                y=[t.get("low", 30), t.get("med", 60), t.get("high", 85)],
                marker_color=["#00cc66", "#ffaa00", "#ff3333"],
                text=[t.get("low", 30), t.get("med", 60), t.get("high", 85)],
                textposition="outside"
            ))
            fig.update_layout(title="Risk Thresholds", height=350)
            st.plotly_chart(fig, use_container_width=True)
    else:
        st.warning("No user profiles found. Generate test data first.")

elif page == "Trusted Locations":
    st.title("📍 Trusted Locations")

    locations = fetch_locations()
    if locations and locations.get("locations"):
        df = pd.DataFrame(locations["locations"])
        if not df.empty:
            df["last_seen"] = pd.to_datetime(df["last_seen"], unit="s")
            st.dataframe(df, use_container_width=True)

            fig = px.scatter_geo(df, locations="city" if "city" in df.columns else None,
                                size="trust_score",
                                title="Trusted Locations (Geo)",
                                hover_name="city")
            st.plotly_chart(fig, use_container_width=True)

            st.subheader("Location Trust Scores")
            fig2 = px.bar(df, x="city", y="trust_score", color="country",
                         title="Trust Score by Location",
                         labels={"trust_score": "Trust Score"})
            st.plotly_chart(fig2, use_container_width=True)
        else:
            st.info("No trusted locations yet.")
    else:
        st.info("No trusted locations yet. They will be auto-populated as the system learns.")

elif page == "Device Management":
    st.title("💻 Device Management")
    st.caption("Endpoint Identity Layer — Trusted device registry and hardware change monitoring")

    col1, col2 = st.columns(2)
    dev_limit = col1.number_input("Max Devices", value=100, step=10)
    dev_filter = col2.text_input("Filter by Device Hash (partial)")

    devices = fetch_devices(limit=dev_limit)
    if devices and devices.get("devices"):
        df = pd.DataFrame(devices["devices"])
        if not df.empty:
            if "first_seen" in df.columns:
                df["first_seen"] = pd.to_datetime(df["first_seen"], unit="s", errors="coerce")
            if "last_seen" in df.columns:
                df["last_seen"] = pd.to_datetime(df["last_seen"], unit="s", errors="coerce")

            if dev_filter:
                df = df[df["device_hash"].str.contains(dev_filter, case=False, na=False)]

            total = len(df)
            trusted = len(df[df["trust_status"] == "TRUSTED"])
            pending = len(df[df["trust_status"] == "PENDING_TRUST"])
            revoked = len(df[df["trust_status"] == "REVOKED"])

            m1, m2, m3, m4 = st.columns(4)
            m1.metric("Total Devices", total)
            m2.metric("Trusted", trusted)
            m3.metric("Pending", pending)
            m4.metric("Revoked", revoked)

            trust_colors = {"TRUSTED": "#00cc66", "PENDING_TRUST": "#ffaa00", "REVOKED": "#ff3333"}
            status_counts = df["trust_status"].value_counts().reset_index()
            status_counts.columns = ["status", "count"]
            fig = px.bar(status_counts, x="status", y="count", color="status",
                        color_discrete_map=trust_colors, title="Devices by Trust Status")
            st.plotly_chart(fig, use_container_width=True)

            st.subheader("Device Registry")
            display_cols = ["device_hash", "hostname", "trust_status", "trusted",
                           "first_seen", "last_seen", "notes", "user_id"]
            display_df = df[[c for c in display_cols if c in df.columns]].copy()
            st.dataframe(display_df, use_container_width=True)

            st.subheader("Manage Device Trust")
            c1, c2 = st.columns(2)
            with c1:
                approve_hash = st.text_input("Device Hash to Approve")
                approve_notes = st.text_input("Approval Notes")
                if st.button("✅ Approve Device"):
                    try:
                        r = requests.post(f"{API_BASE}/api/v1/devices/approve",
                                        json={"device_hash": approve_hash, "notes": approve_notes}, timeout=3)
                        if r.status_code == 200:
                            st.success(f"Device {approve_hash} approved")
                            st.rerun()
                        else:
                            st.error(f"Failed: {r.text}")
                    except Exception as e:
                        st.error(f"Error: {e}")
            with c2:
                revoke_hash = st.text_input("Device Hash to Revoke")
                if st.button("❌ Revoke Device"):
                    try:
                        r = requests.post(f"{API_BASE}/api/v1/devices/revoke",
                                        json={"device_hash": revoke_hash}, timeout=3)
                        if r.status_code == 200:
                            st.success(f"Device {revoke_hash} revoked")
                            st.rerun()
                        else:
                            st.error(f"Failed: {r.text}")
                    except Exception as e:
                        st.error(f"Error: {e}")

            with st.expander("Device History Log"):
                hist_hash = st.text_input("Enter device hash for history (leave empty for all)", value="")
                hist = fetch_device_history(device_hash=hist_hash if hist_hash else None, limit=100)
                if hist and hist.get("history"):
                    hist_df = pd.DataFrame(hist["history"])
                    if not hist_df.empty:
                        if "timestamp" in hist_df.columns:
                            hist_df["timestamp"] = pd.to_datetime(hist_df["timestamp"], unit="s", errors="coerce")
                        st.dataframe(hist_df, use_container_width=True)
                    else:
                        st.info("No history records.")
                else:
                    st.info("No device history available.")
        else:
            st.info("No devices found in device registry.")
    else:
        st.info("No devices registered yet. Device fingerprints are automatically registered when the agent sends data to the ML service.")

elif page == "Incidents":
    st.title("🚨 Incident Management")
    st.caption("Enterprise incident lifecycle management")

    col1, col2, col3 = st.columns(3)
    filter_status = col1.selectbox("Filter Status", ["ALL", "OPEN", "UNDER_INVESTIGATION", "VERIFICATION_PENDING", "CONTAINED", "RESOLVED", "CLOSED"])
    incident_user = col2.text_input("Filter by User ID", value="")
    inc_limit = col3.number_input("Max Records", value=50, step=10)

    status_param = None if filter_status == "ALL" else filter_status
    user_param = incident_user if incident_user else None
    incidents = fetch_incidents(user_id=user_param, status=status_param, limit=inc_limit)

    if incidents and incidents.get("incidents"):
        df = pd.DataFrame(incidents["incidents"])
        if not df.empty:
            df["timestamp"] = pd.to_datetime(df["timestamp"], unit="s", errors="coerce")
            if "resolved_at" in df.columns:
                df["resolved_at"] = pd.to_datetime(df["resolved_at"], unit="s", errors="coerce")

            color_map = {
                "OPEN": "#ff3333",
                "UNDER_INVESTIGATION": "#ff8800",
                "VERIFICATION_PENDING": "#ffaa00",
                "CONTAINED": "#4488ff",
                "RESOLVED": "#00cc66",
                "CLOSED": "#888888"
            }
            status_counts = df["status"].value_counts().reset_index()
            status_counts.columns = ["status", "count"]
            fig = px.bar(status_counts, x="status", y="count", color="status",
                        color_discrete_map=color_map, title="Incidents by Status")
            st.plotly_chart(fig, use_container_width=True)

            severity_order = ["INFO", "LOW", "MEDIUM", "HIGH", "CRITICAL"]
            sev_counts = df["severity"].value_counts().reindex(severity_order, fill_value=0).reset_index()
            sev_counts.columns = ["severity", "count"]
            fig2 = px.pie(sev_counts, values="count", names="severity",
                         title="Incidents by Severity",
                         color="severity",
                         color_discrete_map={
                             "INFO": "#888888", "LOW": "#00cc66",
                             "MEDIUM": "#ffaa00", "HIGH": "#ff6600", "CRITICAL": "#ff3333"
                         })
            st.plotly_chart(fig2, use_container_width=True)

            c1, c2, c3, c4 = st.columns(4)
            c1.metric("Total Incidents", len(df))
            c2.metric("Open", len(df[df["status"] == "OPEN"]))
            c3.metric("Critical", len(df[df["severity"] == "CRITICAL"]))
            c4.metric("Resolved/Closed", len(df[df["status"].isin(["RESOLVED", "CLOSED"])]))

            st.subheader("Incident Details")
            display_cols = ["incident_id", "user_id", "severity", "status", "risk_score",
                           "mitre_technique", "timestamp", "recommended_action"]
            display_df = df[[c for c in display_cols if c in df.columns]].copy()
            st.dataframe(display_df, use_container_width=True)

            with st.expander("Update Incident Status"):
                inc_id = st.text_input("Incident ID")
                new_status = st.selectbox("New Status",
                    ["OPEN", "UNDER_INVESTIGATION", "VERIFICATION_PENDING", "CONTAINED", "RESOLVED", "CLOSED"])
                res_notes = st.text_area("Resolution Notes")
                if st.button("Update Status"):
                    try:
                        r = requests.put(f"{API_BASE}/api/v1/incidents/{inc_id}/status",
                                        json={"status": new_status, "resolution_notes": res_notes}, timeout=3)
                        if r.status_code == 200:
                            st.success(f"Incident {inc_id} updated to {new_status}")
                            st.rerun()
                        else:
                            st.error(f"Failed: {r.text}")
                    except Exception as e:
                        st.error(f"Error: {e}")
        else:
            st.info("No incidents match the filter.")
    else:
        st.info("No incidents yet. Incidents are created automatically when the response engine detects suspicious activity.")

elif page == "Response History":
    st.title("📋 Response History")
    st.caption("Every action the response engine has taken")

    rh_user = st.text_input("Filter by User ID (leave empty for all)", value=selected_user)
    rh_limit = st.number_input("Records to show", value=100, step=10)
    rh = fetch_response_history(user_id=rh_user if rh_user else None, limit=rh_limit)

    if rh and rh.get("history"):
        df = pd.DataFrame(rh["history"])
        if not df.empty:
            if "timestamp" in df.columns:
                df["timestamp"] = pd.to_datetime(df["timestamp"], unit="s", errors="coerce")

            st.subheader("Response Action Distribution")
            action_counts = df["action_taken"].value_counts().reset_index()
            action_counts.columns = ["action", "count"]
            fig = px.bar(action_counts, x="action", y="count", color="action",
                        title="Response Actions Over Time")
            st.plotly_chart(fig, use_container_width=True)

            st.subheader("Evidence Score Trend")
            if "evidence_score" in df.columns and "timestamp" in df.columns:
                df_sorted = df.sort_values("timestamp")
                fig2 = px.line(df_sorted, x="timestamp", y="evidence_score",
                              title="Evidence Score Over Time",
                              markers=True)
                fig2.add_hline(y=50, line_dash="dash", line_color="orange", annotation_text="Suspicious Threshold")
                st.plotly_chart(fig2, use_container_width=True)

            st.subheader("Full History")
            display_cols = ["user_id", "action_taken", "response_level", "system_state",
                           "risk_score", "evidence_score", "confidence", "policy_id", "incident_id", "timestamp"]
            display_df = df[[c for c in display_cols if c in df.columns]].copy()
            st.dataframe(display_df, use_container_width=True)

            with st.expander("Raw JSON Output"):
                st.json(rh)
    else:
        st.info("No response history yet. Send some test data to generate responses.")

elif page == "Policy Audit":
    st.title("📜 Policy Audit Log")
    st.caption("Tracks every policy match and decision")

    pa_limit = st.number_input("Records to show", value=100, step=10)
    pa = fetch_policy_audit(limit=pa_limit)

    if pa and pa.get("audit"):
        df = pd.DataFrame(pa["audit"])
        if not df.empty:
            if "timestamp" in df.columns:
                df["timestamp"] = pd.to_datetime(df["timestamp"], unit="s", errors="coerce")

            col1, col2 = st.columns(2)
            with col1:
                pol_counts = df["policy_id"].value_counts().reset_index()
                pol_counts.columns = ["policy_id", "count"]
                fig = px.bar(pol_counts, x="policy_id", y="count",
                            title="Policy Match Frequency",
                            color="policy_id")
                st.plotly_chart(fig, use_container_width=True)
            with col2:
                match_counts = df["matched"].value_counts().reset_index()
                match_counts.columns = ["matched", "count"]
                fig2 = px.pie(match_counts, values="count", names="matched",
                             title="Policy Match vs No Match",
                             color="matched",
                             color_discrete_map={True: "#00cc66", False: "#ff3333"})
                st.plotly_chart(fig2, use_container_width=True)

            st.subheader("Audit Log")
            display_cols = ["policy_id", "policy_name", "user_id", "risk_score", "confidence",
                           "matched", "action_taken", "timestamp"]
            display_df = df[[c for c in display_cols if c in df.columns]].copy()
            st.dataframe(display_df, use_container_width=True)
    else:
        st.info("No policy audit entries yet.")

elif page == "MITRE Techniques":
    st.title("🔬 MITRE ATT&CK Mapping")
    st.caption("Tactics, techniques, and procedures mapped to behavioral signals")

    techniques = fetch_mitre_techniques()
    if techniques and techniques.get("techniques"):
        data = []
        for key, tech in techniques["techniques"].items():
            data.append({
                "Signal": key.replace("_", " ").title(),
                "Technique ID": tech.get("technique_id", ""),
                "Technique Name": tech.get("technique_name", ""),
                "Tactic": tech.get("tactic", ""),
                "Description": tech.get("description", "")
            })
        df = pd.DataFrame(data)
        st.dataframe(df, use_container_width=True)

        technique_counts = df["Tactic"].value_counts().reset_index()
        technique_counts.columns = ["Tactic", "Count"]
        fig = px.pie(technique_counts, values="Count", names="Tactic",
                    title="MITRE Tactics Distribution",
                    color_discrete_sequence=px.colors.qualifier.Set3)
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("MITRE techniques could not be loaded.")

elif page == "Test API":
    st.title("🧪 API Test Console")
    st.caption("Test the ML service endpoints directly")

    col1, col2 = st.columns(2)
    with col1:
        if st.button("🏓 Health Check"):
            try:
                r = requests.get(f"{API_BASE}/health", timeout=3)
                st.json(r.json())
            except Exception as e:
                st.error(f"Connection failed: {e}")

    with col2:
        if st.button("🔄 Trigger Retrain"):
            try:
                r = requests.post(f"{API_BASE}/api/v1/retrain", timeout=5)
                st.json(r.json())
            except Exception as e:
                st.error(f"Retrain failed: {e}")

    st.subheader("Send Test Behavior Record")
    with st.form("test_form"):
        c1, c2 = st.columns(2)
        with c1:
            typing_speed = st.number_input("Typing Speed", value=55.0)
            key_latency = st.number_input("Key Latency", value=0.12, format="%.4f")
            avg_hold_time = st.number_input("Avg Hold Time", value=0.08, format="%.4f")
            mouse_speed = st.number_input("Mouse Speed", value=350.0)
            click_freq = st.number_input("Click Frequency", value=1.2)
            app_switch = st.number_input("App Switch Count", value=1, step=1)
        with c2:
            idle_time = st.number_input("Idle Time (s)", value=1.0)
            time_of_day = st.number_input("Time of Day (0-23)", value=14.0)
            active_app = st.text_input("Active App", value="VSCode")
            city = st.text_input("City", value="Cyber City")
            country = st.text_input("Country", value="Digital Land")
            is_new_loc = st.checkbox("Is New Location")

        sent = st.form_submit_button("🚀 Send to API")
        if sent:
            payload = {
                "typing_speed": typing_speed,
                "key_latency": key_latency,
                "avg_hold_time": avg_hold_time,
                "latency_jitter": 0.03,
                "mouse_speed": mouse_speed,
                "mouse_acceleration": 25.0,
                "direction_change_freq": 3.0,
                "click_frequency": click_freq,
                "active_app": active_app,
                "app_switch_count": app_switch,
                "idle_time": idle_time,
                "time_of_day": time_of_day,
                "user_id": selected_user,
                "ip_address": "127.0.0.1",
                "city": city,
                "country": country,
                "is_new_location": is_new_loc
            }
            try:
                r = requests.post(f"{API_BASE}/api/v1/analyze", json=payload, timeout=5)
                result = r.json()
                risk = result.get("risk_level", "UNKNOWN")
                risk_c = "risk-low" if risk == "LOW" else ("risk-medium" if risk == "MEDIUM" else "risk-high")
                st.markdown(f"<h2 class='{risk_c}'>Risk: {risk} | Score: {result.get('risk_score', 0)}</h2>", unsafe_allow_html=True)
                st.markdown(f"**Action:** {result.get('action', 'N/A')}")
                st.markdown(f"**Reason:** {result.get('reason', 'N/A')}")
                st.markdown(f"**Confidence:** {result.get('confidence', 0.0)}")
                st.markdown(f"**Stage:** {result.get('lifecycle_stage', 'N/A')}")

                re = result.get("response_engine", {})
                if re:
                    st.subheader("Response Engine Output")
                    c1, c2, c3, c4, c5 = st.columns(5)
                    c1.metric("Risk Level", re.get("risk_level", "N/A"))
                    c2.metric("System State", re.get("system_state", "N/A"))
                    c3.metric("Evidence Score", re.get("evidence_score", 0))
                    c4.metric("Consecutive Anomalies", re.get("consecutive_anomalies", 0))
                    c5.metric("Response Level", re.get("response_level", 0))
                    st.json(re)
            except Exception as e:
                st.error(f"Request failed: {e}")
