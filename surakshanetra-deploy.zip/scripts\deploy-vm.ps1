<#
.SYNOPSIS
    Package SurakshaNetra for VM transfer
.DESCRIPTION
    Creates a deployment archive (.zip) excluding development/irrelevant files.
    Transfer the .zip to the target VM and run scripts\install.ps1.
.EXAMPLE
    .\scripts\deploy-vm.ps1
    .\scripts\deploy-vm.ps1 -OutputPath "D:\surakshanetra-deploy.zip"
#>

param(
    [string]$OutputPath = ""
)

$ProjectRoot = Split-Path -Parent (Split-Path -Parent $PSCommandPath)
if (-not $OutputPath) {
    $OutputPath = Join-Path $ProjectRoot "surakshanetra-deploy.zip"
}

Write-Host "Packaging SurakshaNetra for VM deployment..." -ForegroundColor Cyan
Write-Host "Output: $OutputPath`n" -ForegroundColor Gray

# Files/dirs to include
$include = @(
    "agent",
    "backend",
    "central_server",
    "dashboard",
    "docs",
    "evidence",
    "forensics",
    "hunter",
    "ml_service",
    "remote_commands",
    "rules",
    "scripts",
    "surakshanetra",
    "threat_intelligence",
    "central_server\dashboard-static",
    "Dockerfile",
    "docker-compose.yml",
    "pyproject.toml",
    "requirements.txt",
    "README.md",
    ".gitignore",
    ".dockerignore"
)

# Compress
$items = $include | ForEach-Object { Join-Path $ProjectRoot $_ } | Where-Object { Test-Path $_ }
Compress-Archive -Path $items -DestinationPath $OutputPath -Force

# Show size
$size = (Get-Item $OutputPath).Length
if ($size -gt 1GB) { $sizeStr = "{0:N1} GB" -f ($size / 1GB) }
elseif ($size -gt 1MB) { $sizeStr = "{0:N1} MB" -f ($size / 1MB) }
else { $sizeStr = "{0:N0} KB" -f ($size / 1KB) }

Write-Host "Done. Archive: $sizeStr" -ForegroundColor Green
Write-Host "To deploy on VM:" -ForegroundColor Cyan
Write-Host "  1. Copy surakshanetra-deploy.zip to the VM" -ForegroundColor White
Write-Host "  2. Extract to C:\surakshanetra" -ForegroundColor White
Write-Host "  3. Open PowerShell as Admin and run:" -ForegroundColor White
Write-Host "     cd C:\surakshanetra; .\scripts\install.ps1" -ForegroundColor Yellow
Write-Host "  4. Start the server:" -ForegroundColor White
Write-Host "     .\scripts\run.ps1" -ForegroundColor Yellow
Write-Host "  5. Test:" -ForegroundColor White
Write-Host "     curl http://localhost:9000/health" -ForegroundColor Yellow
