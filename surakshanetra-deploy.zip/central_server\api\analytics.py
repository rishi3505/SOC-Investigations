"""
Analytics — cross-endpoint metrics, trends, MTTD, MTTR, and statistics
"""
import time
from fastapi import APIRouter, Depends, Query
from ..database import get_connection
from ..auth import authenticate_request

router = APIRouter(prefix="/api/v1/analytics", tags=["Analytics"])


@router.get("/overview")
async def overview(user: dict = Depends(authenticate_request)):
    conn = get_connection()
    cursor = conn.cursor()
    now = int(time.time())

    cursor.execute("SELECT COUNT(*) FROM endpoints")
    total_endpoints = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM endpoints WHERE health_status = 'ONLINE'")
    online = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM endpoints WHERE health_status = 'OFFLINE'")
    offline = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM endpoints WHERE health_status IN ('DEGRADED','RECOVERING','UPDATING')")
    degraded = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM incidents WHERE status NOT IN ('RESOLVED','CLOSED')")
    active_incidents = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM incidents WHERE severity = 'CRITICAL' AND status NOT IN ('RESOLVED','CLOSED')")
    critical_incidents = cursor.fetchone()[0]

    cursor.execute("SELECT COALESCE(AVG(risk_score), 0) FROM incidents WHERE created_at > ?", (now - 86400,))
    avg_risk = round(cursor.fetchone()[0], 2)

    cursor.execute("SELECT COUNT(*) FROM incidents WHERE created_at > ?", (now - 86400,))
    incidents_24h = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM incidents WHERE created_at > ?", (now - 604800,))
    incidents_7d = cursor.fetchone()[0]

    conn.close()
    return {
        "endpoints": {
            "total": total_endpoints,
            "online": online,
            "offline": offline,
            "degraded": degraded,
        },
        "incidents": {
            "active": active_incidents,
            "critical": critical_incidents,
            "last_24h": incidents_24h,
            "last_7d": incidents_7d,
        },
        "average_risk": avg_risk,
    }


@router.get("/trends")
async def trends(days: int = Query(7, ge=1, le=90), user: dict = Depends(authenticate_request)):
    conn = get_connection()
    cursor = conn.cursor()
    now = int(time.time())
    since = now - (days * 86400)

    cursor.execute("""
        SELECT DATE(created_at, 'unixepoch') as day, COUNT(*) as cnt
        FROM incidents WHERE created_at > ?
        GROUP BY day ORDER BY day
    """, (since,))
    incident_trends = [{"date": r["day"], "count": r["cnt"]} for r in cursor.fetchall()]

    cursor.execute("""
        SELECT DATE(timestamp, 'unixepoch') as day, AVG(risk_score) as avg_risk
        FROM behavior_data WHERE timestamp > ?
        GROUP BY day ORDER BY day
    """, (since,))
    risk_trends = [{"date": r["day"], "avg_risk": round(r["avg_risk"], 2)} for r in cursor.fetchall()]

    conn.close()
    return {"incident_trends": incident_trends, "risk_trends": risk_trends}


@router.get("/mttd")
async def mean_time_to_detect(days: int = Query(30, ge=1, le=365), user: dict = Depends(authenticate_request)):
    conn = get_connection()
    cursor = conn.cursor()
    since = int(time.time()) - (days * 86400)
    cursor.execute("""
        SELECT AVG(created_at - (SELECT MIN(timestamp) FROM behavior_data
            WHERE endpoint_id = i.endpoint_id AND timestamp > ? AND timestamp < i.created_at)) as mttd
        FROM incidents i WHERE i.created_at > ?
    """, (since - 86400, since))
    row = cursor.fetchone()
    avg_seconds = row[0] if row and row[0] else 0
    conn.close()
    return {
        "mttd_seconds": round(avg_seconds, 1),
        "mttd_hours": round(avg_seconds / 3600, 2),
        "period_days": days,
    }


@router.get("/mttr")
async def mean_time_to_respond(days: int = Query(30, ge=1, le=365), user: dict = Depends(authenticate_request)):
    conn = get_connection()
    cursor = conn.cursor()
    since = int(time.time()) - (days * 86400)
    cursor.execute("""
        SELECT AVG(resolved_at - created_at) as mttr
        FROM incidents WHERE resolved_at IS NOT NULL AND created_at > ?
    """, (since,))
    row = cursor.fetchone()
    avg_seconds = row[0] if row and row[0] else 0
    conn.close()
    return {
        "mttr_seconds": round(avg_seconds, 1),
        "mttr_hours": round(avg_seconds / 3600, 2),
        "period_days": days,
    }


@router.get("/policy-triggers")
async def policy_trigger_stats(limit: int = Query(20, ge=1, le=100), user: dict = Depends(authenticate_request)):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT severity, COUNT(*) as cnt FROM incidents
        WHERE severity IN ('CRITICAL','HIGH','MEDIUM','LOW')
        GROUP BY severity ORDER BY cnt DESC
    """)
    severity_counts = {r["severity"]: r["cnt"] for r in cursor.fetchall()}
    cursor.execute("""
        SELECT COALESCE(NULLIF(i.mitre_technique, ''), 'UNKNOWN') as technique, COUNT(*) as cnt
        FROM incidents i GROUP BY technique ORDER BY cnt DESC LIMIT ?
    """, (limit,))
    top_techniques = [{"technique": r["technique"], "count": r["cnt"]} for r in cursor.fetchall()]
    conn.close()
    return {"severity_distribution": severity_counts, "top_techniques": top_techniques}


@router.get("/endpoint-health-trends")
async def endpoint_health_trends(days: int = Query(7, ge=1, le=90), user: dict = Depends(authenticate_request)):
    conn = get_connection()
    cursor = conn.cursor()
    since = int(time.time()) - (days * 86400)
    cursor.execute("""
        SELECT DATE(timestamp, 'unixepoch') as day,
               health_status, COUNT(*) as cnt
        FROM heartbeats WHERE timestamp > ?
        GROUP BY day, health_status ORDER BY day
    """, (since,))
    rows = cursor.fetchall()
    conn.close()
    trends = {}
    for r in rows:
        day = r["day"]
        if day not in trends:
            trends[day] = {}
        trends[day][r["health_status"]] = r["cnt"]
    return {"health_trends": [{"date": d, **s} for d, s in trends.items()]}


@router.get("/false-positive-rate")
async def false_positive_rate(days: int = Query(30, ge=1, le=365), user: dict = Depends(authenticate_request)):
    conn = get_connection()
    cursor = conn.cursor()
    since = int(time.time()) - (days * 86400)
    cursor.execute("""
        SELECT COUNT(*) as total FROM incidents WHERE created_at > ?
    """, (since,))
    total = cursor.fetchone()[0]
    cursor.execute("""
        SELECT COUNT(*) as resolved FROM incidents
        WHERE status = 'RESOLVED' AND resolution_notes LIKE '%false%' AND created_at > ?
    """, (since,))
    false_positives = cursor.fetchone()[0]
    conn.close()
    rate = round((false_positives / max(total, 1)) * 100, 2)
    return {
        "total_incidents": total,
        "false_positives": false_positives,
        "false_positive_rate_percent": rate,
        "period_days": days,
    }
