param(
    [int]$Port = 9000,
    [switch]$Wait
)

$env:CMS_PORT = $Port
$env:DISABLE_HTTPS = "1"

Write-Host "Starting CMS on port $Port..."
$psi = New-Object System.Diagnostics.ProcessStartInfo
$psi.FileName = "python"
$psi.Arguments = "-m central_server.main"
$psi.WorkingDirectory = "C:\Users\rushi\ai-continuous-authentication"
$psi.UseShellExecute = $false
$psi.RedirectStandardOutput = $true
$psi.RedirectStandardError = $true
$psi.CreateNoWindow = $true

$p = [System.Diagnostics.Process]::Start($psi)

if ($Wait) {
    Start-Sleep -Seconds 5
    Write-Host "CMS started with PID $($p.Id)"
}
