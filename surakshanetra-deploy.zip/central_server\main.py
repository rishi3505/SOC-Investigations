"""
Central Management Server — Main FastAPI Application

Serves as the unified API gateway for:
- Endpoint agents (backward-compatible with /api/v1/analyze, /api/v1/agent/heartbeat)
- SOC Dashboard (multi-endpoint views)
- Centralized policy, device, and incident management

Runs on port 9000 by default.
"""
import json
import os
import sys
import time
from contextlib import asynccontextmanager

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from fastapi import FastAPI, Depends, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles

from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded

from central_server.config import HOST, PORT, ENABLE_HTTPS, SSL_CERT, SSL_KEY
from central_server.database import init_database, get_connection
from central_server.auth import authenticate_request, create_token, generate_api_key, hash_password, verify_password
from central_server.models import LoginRequest, AnalyzeRequest

from central_server.api.agent_registry import router as agent_registry_router
from central_server.api.endpoint_manager import router as endpoint_manager_router
from central_server.api.heartbeat_manager import router as heartbeat_manager_router
from central_server.api.incident_router import router as incident_router_router
from central_server.api.policy_manager import router as policy_manager_router
from central_server.api.device_registry import router as device_registry_router
from central_server.api.notification_service import router as notification_router
from central_server.api.analytics import router as analytics_router
from central_server.api.threat_intel_router import router as threat_intel_router
from central_server.api.lifecycle_manager import router as lifecycle_router
from central_server.api.remote_command_router import router as remote_command_router
from central_server.api.config_manager import router as config_manager_router
from central_server.api.update_manager import router as update_manager_router
from central_server.api.health_manager import router as health_manager_router
from central_server.api.inventory_manager import router as inventory_manager_router
from central_server.api.group_manager import router as group_manager_router
from central_server.api.audit_manager import router as audit_manager_router
from central_server.api.metrics import router as metrics_router


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_database()
    _seed_default_data()
    try:
        from threat_intelligence.ioc_manager import init_ioc_db
        init_ioc_db()
    except Exception as e:
        print(f"Warning: IOC DB init failed: {e}")
    try:
        from threat_intelligence.feed_manager import init_feeds_table, register_feeds
        init_feeds_table()
        register_feeds()
    except Exception as e:
        print(f"Warning: Feeds init failed: {e}")
    try:
        from hunter.engine import init_hunter
        init_hunter()
    except Exception as e:
        print(f"Warning: Hunter DB init failed: {e}")
    print(f"CMS started on {HOST}:{PORT} — Threat Intel loaded")
    yield
    print("CMS shutting down.")


app = FastAPI(
    title="Central Management Server — AI Continuous Auth",
    description="Enterprise multi-endpoint security management platform",
    version="2.0.0",
    lifespan=lifespan,
)

CORS_ORIGINS = os.environ.get("CORS_ORIGINS", "http://localhost:5173,http://localhost:3000,http://127.0.0.1:5173").split(",")
app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

limiter = Limiter(key_func=get_remote_address, default_limits=[os.environ.get("RATE_LIMIT", "100/minute")])
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)


def _seed_default_data():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM organizations")
    if cursor.fetchone()[0] == 0:
        cursor.execute("INSERT INTO organizations (name, created_at) VALUES (?, ?)", ("Default Organization", int(time.time())))
        org_id = cursor.lastrowid
        api_key = generate_api_key()
        password = os.environ.get("ADMIN_PASSWORD", "admin123")
        cursor.execute(
            "INSERT INTO users (username, password_hash, role, org_id, api_key, created_at) VALUES (?, ?, ?, ?, ?, ?)",
            ("admin", hash_password(password), "admin", org_id, api_key, int(time.time())),
        )
        cursor.execute("INSERT INTO policies (org_id, name, enabled, policy_json, version, created_at) VALUES (?, ?, 1, ?, '1.0.0', ?)",
                       (org_id, "Default Security Policy", json.dumps({"risk_threshold": 60, "sampling_interval": 2, "containment": True}), int(time.time())))
        print(f"Seeded default org (id={org_id})")
    conn.commit()
    conn.close()


@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    return JSONResponse(status_code=500, content={"detail": str(exc)})


@app.get("/health")
async def health():
    return {
        "status": "online",
        "service": "central-management-server",
        "version": "2.0.0",
        "timestamp": int(time.time()),
    }


@app.post("/api/v1/auth/login")
async def login(payload: LoginRequest):
    username = payload.username
    password = payload.password
    api_key = payload.api_key
    if api_key:
        try:
            from central_server.auth import verify_api_key
            user = verify_api_key(api_key)
            token = create_token(user["user_id"], user["username"], user["role"], user["org_id"])
            return {"token": token, "user": user}
        except HTTPException:
            pass
    if not username or not password:
        raise HTTPException(status_code=401, detail="Username and password required")
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id, username, password_hash, role, org_id FROM users WHERE username = ?", (username,))
    row = cursor.fetchone()
    conn.close()
    if not row:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    if not verify_password(password, row["password_hash"]):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    user = {"user_id": row["id"], "username": row["username"], "role": row["role"], "org_id": row["org_id"]}
    token = create_token(user["user_id"], user["username"], user["role"], user["org_id"])
    return {"token": token, "user": user}


@app.post("/api/v1/analyze")
async def analyze(payload: AnalyzeRequest, user: dict = Depends(authenticate_request)):
    try:
        from ml_service.anomaly_model import get_model_instance
        from backend.response_engine import evaluate as response_evaluate
        from backend.db import check_trusted_session, check_location_trust, get_user_thresholds
    except ImportError as e:
        raise HTTPException(status_code=503, detail=f"ML service not available: {e}")

    user_id = payload.user_id or "default_user"
    endpoint_id = payload.device_hash or payload.endpoint_id or "unknown"

    model = get_model_instance()
    thresholds = get_user_thresholds(user_id)
    raw_result = model.predict(payload.model_dump(), user_id=user_id, thresholds=thresholds)

    try:
        from backend.db import add_session_risk
        add_session_risk(user_id, raw_result["risk_score"], raw_result["is_anomalous"])
    except Exception:
        pass

    final_score = raw_result.get("risk_score", 0)

    threat_intel_score = 0
    ioc_matches = []
    detection_rule_matches = []
    try:
        from threat_intelligence.ioc_matcher import match_payload
        ioc_matches = match_payload(payload.model_dump())
        if ioc_matches:
            sev_scores = {"LOW": 10, "MEDIUM": 30, "HIGH": 60, "CRITICAL": 90}
            threat_intel_score = max(sev_scores.get(m.get("severity", "LOW"), 0) for m in ioc_matches)
    except Exception:
        pass

    try:
        from rules.rule_engine import evaluate_all_rules
        detection_rule_matches = evaluate_all_rules(payload.model_dump(), ioc_matches)
    except Exception:
        pass

    try:
        from threat_intelligence.threat_scoring import ThreatScoreComponents, get_threat_scoring
        components = ThreatScoreComponents(
            behavior_score=final_score,
            threat_intel_score=threat_intel_score,
            device_trust_score=50 if (payload.device_trust_status or "trusted") == "trusted" else 20,
            location_trust_score=50 if not payload.is_new_location else 20,
            baseline_deviation=raw_result.get("significance", {}).get("deviation_score", 0),
            detection_rule_matches=len(detection_rule_matches),
            detection_rule_avg_severity=_avg_rule_severity(detection_rule_matches),
        )
        scoring_result = get_threat_scoring().compute(components)
        final_score = scoring_result["final_score"]
    except Exception:
        scoring_result = None

    response_result = response_evaluate(
        risk_score=final_score,
        confidence=raw_result.get("confidence_score", 0.5),
        deviating_features=raw_result.get("significance", {}).get("deviating_features", []),
        significance=raw_result.get("significance", {}),
        is_new_location=payload.is_new_location,
        is_trusted_location=check_location_trust(user_id, payload.city or "", payload.country or ""),
        is_trusted_session=check_trusted_session(user_id),
        consecutive_anomalies=0,
        has_positive_feedback=False,
        has_recent_mfa=False,
        has_failed_mfa=False,
        device_mismatch=False,
        unknown_device=False,
        device_fingerprint_changed=False,
        device_hardware_change_score=payload.device_change_score,
        trusted_device=False,
        user_id=user_id,
    )

    incident_id = None
    org_id = user.get("org_id")
    severity = response_result.get("risk_level", "MEDIUM")
    if severity in ("HIGH", "CRITICAL") or response_result.get("action") in ("STEP_UP_AUTH", "LOCK_SESSION", "RESTRICT"):
        incident_id = _create_cms_incident(endpoint_id, org_id, user_id, response_result, final_score, raw_result)

    evidence_score = response_result.get("evidence_score", 0)
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO behavior_data
            (endpoint_id, user_id, typing_speed, key_latency, avg_hold_time,
             latency_jitter, mouse_speed, mouse_acceleration, direction_change_freq,
             click_frequency, active_app, app_switch_count, idle_time, time_of_day,
             session_duration, ip_address, city, country, is_new_location,
             risk_score, is_anomalous, timestamp)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        endpoint_id, user_id,
        payload.typing_speed, payload.key_latency,
        payload.avg_hold_time, payload.latency_jitter,
        payload.mouse_speed, payload.mouse_acceleration,
        payload.direction_change_freq, payload.click_frequency,
        payload.active_app, payload.app_switch_count,
        payload.idle_time, payload.time_of_day,
        payload.session_duration, payload.ip_address,
        payload.city, payload.country,
        1 if payload.is_new_location else 0,
        final_score, 1 if raw_result.get("is_anomalous") else 0,
        int(time.time()),
    ))
    conn.commit()
    conn.close()

    if incident_id and severity in ("HIGH", "CRITICAL"):
        try:
            from backend.containment_engine import execute_containment
            import asyncio
            asyncio.create_task(execute_containment(
                incident={"incident_id": incident_id, "severity": severity, "user_id": user_id, "risk_score": final_score, "evidence_score": evidence_score},
                risk_score=final_score, evidence_score=evidence_score,
                confidence=raw_result.get("confidence_score", 0),
                policy_decision=response_result,
            ))
        except Exception:
            pass

    incident_count = 0
    if incident_id:
        conn2 = get_connection()
        try:
            cursor2 = conn2.cursor()
            cursor2.execute("SELECT COUNT(*) FROM incidents WHERE endpoint_id = ? AND status NOT IN ('RESOLVED','CLOSED')", (endpoint_id,))
            incident_count = cursor2.fetchone()[0]
        finally:
            conn2.close()

    return {
        "risk_score": final_score,
        "risk_level": response_result.get("risk_level", "LOW"),
        "action": response_result.get("action", "ALLOW"),
        "reason": response_result.get("recommendation", {}).get("reasons", []),
        "confidence": raw_result.get("confidence_score"),
        "incident_id": incident_id,
        "incident_count": incident_count,
        "threat_intel": {
            "ioc_matches": len(ioc_matches),
            "threat_intel_score": threat_intel_score,
            "detection_rules_triggered": len(detection_rule_matches),
            "threat_score": scoring_result["final_score"] if scoring_result else None,
            "threat_level": scoring_result["threat_level"] if scoring_result else None,
        } if ioc_matches or detection_rule_matches else None,
        "response_engine": {
            "risk_level": response_result["risk_level"],
            "system_state": response_result["system_state"],
            "evidence_score": evidence_score,
            "evidence_breakdown": response_result["evidence_breakdown"],
            "action": response_result["action"],
            "response_level": response_result["response_level"],
            "mitre_technique": response_result["mitre_technique"],
            "recommendation": response_result["recommendation"],
            "policy_matched": response_result.get("policy_matched"),
        },
    }


def _avg_rule_severity(rules: list[dict]) -> float:
    sev_map = {"LOW": 1, "MEDIUM": 2, "HIGH": 3, "CRITICAL": 4}
    if not rules:
        return 0
    return sum(sev_map.get(r.get("severity", "MEDIUM"), 2) for r in rules) / len(rules)


def _create_cms_incident(endpoint_id: str, org_id: int, user_id: str, response_result: dict, final_score: float, raw_result: dict) -> str:
    from central_server.api.incident_router import create_incident
    return create_incident(endpoint_id, org_id or 1, {
        "user_id": user_id,
        "severity": response_result.get("risk_level", "MEDIUM"),
        "risk_score": final_score,
        "confidence": raw_result.get("confidence_score", 0),
        "evidence_score": response_result.get("evidence_score", 0),
        "mitre_technique": response_result.get("mitre_technique", {}).get("technique_id", ""),
        "mitre_technique_name": response_result.get("mitre_technique", {}).get("technique_name", ""),
        "mitre_tactic": response_result.get("mitre_technique", {}).get("tactic", ""),
        "recommended_action": response_result.get("action", ""),
        "recommendation": response_result.get("recommendation", {}),
        "response_level": response_result.get("response_level", 0),
        "system_state": response_result.get("system_state", "NORMAL"),
    })


app.include_router(agent_registry_router)
app.include_router(endpoint_manager_router)
app.include_router(heartbeat_manager_router)
app.include_router(incident_router_router)
app.include_router(policy_manager_router)
app.include_router(device_registry_router)
app.include_router(notification_router)
app.include_router(analytics_router)
app.include_router(threat_intel_router)
app.include_router(lifecycle_router)
app.include_router(remote_command_router)
app.include_router(config_manager_router)
app.include_router(update_manager_router)
app.include_router(health_manager_router)
app.include_router(inventory_manager_router)
app.include_router(group_manager_router)
app.include_router(audit_manager_router)
app.include_router(metrics_router)


@app.get("/api/v1/dashboard/search")
async def global_search(q: str = "", user: dict = Depends(authenticate_request)):
    if not q:
        return {"results": []}
    conn = get_connection()
    cursor = conn.cursor()
    results = []
    s = f"%{q}%"
    cursor.execute("SELECT endpoint_id as id, hostname as name, 'endpoint' as type FROM endpoints WHERE endpoint_id LIKE ? OR hostname LIKE ? LIMIT 20", (s, s))
    results.extend([dict(r) for r in cursor.fetchall()])
    cursor.execute("SELECT incident_id as id, severity as name, 'incident' as type FROM incidents WHERE incident_id LIKE ? OR user_id LIKE ? OR mitre_technique LIKE ? LIMIT 20", (s, s, s))
    results.extend([dict(r) for r in cursor.fetchall()])
    cursor.execute("SELECT device_hash as id, hostname as name, 'device' as type FROM device_fingerprints WHERE device_hash LIKE ? OR hostname LIKE ? LIMIT 10", (s, s))
    results.extend([dict(r) for r in cursor.fetchall()])
    conn.close()
    try:
        from threat_intelligence.ioc_manager import search_iocs
        ioc_page = search_iocs(search=q, page=1, limit=10)
        for ioc in ioc_page.get("iocs", []):
            results.append({"id": ioc["id"], "name": ioc["value"], "type": f"ioc_{ioc['type'].lower()}"})
    except Exception:
        pass
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT e.endpoint_id as id, e.hostname as name, 'lifecycle' as type FROM endpoints WHERE lifecycle_status LIKE ? OR endpoint_id LIKE ? LIMIT 10", (s, s))
    results.extend([dict(r) for r in cursor.fetchall()])
    cursor.execute("SELECT g.id, g.name, 'group' as type FROM endpoint_groups g WHERE g.name LIKE ? LIMIT 10", (s,))
    results.extend([dict(r) for r in cursor.fetchall()])
    conn.close()
    return {"results": results, "query": q}


dashboard_dir = os.path.join(os.path.dirname(__file__), "..", "soc-dashboard", "dist")
if os.path.isdir(dashboard_dir):
    app.mount("/", StaticFiles(directory=dashboard_dir, html=True), name="dashboard")
    print(f"SOC Dashboard mounted from {dashboard_dir}")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "central_server.main:app",
        host=HOST,
        port=PORT,
        reload=os.environ.get("CMS_RELOAD", "false").lower() == "true",
        ssl_keyfile=SSL_KEY if ENABLE_HTTPS else None,
        ssl_certfile=SSL_CERT if ENABLE_HTTPS else None,
    )
