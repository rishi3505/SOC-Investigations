"""
Command Engine — Issues, signs, verifies, and tracks remote commands with
replay protection, expiration, and acknowledgment management.
"""
import hashlib
import hmac
import json
import os
import time
import uuid
from typing import Optional

from .command_types import COMMAND_REGISTRY, RemoteCommand

COMMAND_SIGNING_KEY = os.environ.get("COMMAND_SIGNING_KEY")
if not COMMAND_SIGNING_KEY:
    import secrets as _secrets
    COMMAND_SIGNING_KEY = _secrets.token_hex(32)


def _sign(payload: str, key: str = COMMAND_SIGNING_KEY) -> str:
    return hmac.new(key.encode(), payload.encode(), hashlib.sha256).hexdigest()


def _verify(payload: str, signature: str, key: str = COMMAND_SIGNING_KEY) -> bool:
    expected = _sign(payload, key)
    return hmac.compare_digest(expected, signature)


def _generate_nonce() -> str:
    return uuid.uuid4().hex


class CommandEngine:
    def __init__(self, db_conn_callable):
        self._db = db_conn_callable
        self._used_nonces = set()

    def issue(
        self,
        command_type: str,
        target_type: str = "endpoint",
        target_ids: Optional[list] = None,
        payload: Optional[dict] = None,
        priority: int = 0,
        issued_by: str = "admin",
        expires_in_seconds: Optional[int] = None,
    ) -> dict:
        cmd = RemoteCommand(
            command_type=command_type,
            target_type=target_type,
            target_ids=target_ids or [],
            payload=payload or {},
            priority=priority,
            issued_by=issued_by,
            expires_in_seconds=expires_in_seconds or COMMAND_REGISTRY.get(command_type, {}).get("timeout_seconds", 120),
        )
        err = cmd.validate()
        if err:
            return {"status": "error", "detail": err}

        now = int(time.time())
        command_id = f"CMD-{uuid.uuid4().hex[:8].upper()}-{now}"
        nonce = _generate_nonce()
        expires_at = now + (cmd.expires_in_seconds or 120)

        signing_payload = json.dumps({
            "id": command_id, "type": command_type, "target_ids": cmd.target_ids,
            "nonce": nonce, "expires_at": expires_at, "issued_at": now,
        }, sort_keys=True)
        signature = _sign(signing_payload)

        conn = self._db()
        conn.execute("""
            INSERT INTO remote_commands
                (id, command_type, target_type, target_ids, payload, status,
                 priority, issued_by, issued_at, expires_at, signature)
            VALUES (?, ?, ?, ?, ?, 'PENDING', ?, ?, ?, ?, ?)
        """, (
            command_id, command_type, target_type,
            json.dumps(cmd.target_ids), json.dumps(cmd.payload),
            priority, issued_by, now, expires_at, signature,
        ))
        conn.commit()
        conn.close()

        self._used_nonces.add(nonce)
        return {
            "status": "issued",
            "command_id": command_id,
            "command_type": command_type,
            "target_type": target_type,
            "target_count": len(cmd.target_ids or []),
            "expires_at": expires_at,
            "signature": signature,
            "nonce": nonce,
        }

    def acknowledge(self, command_id: str, endpoint_id: str, output: Optional[dict] = None) -> dict:
        conn = self._db()
        now = int(time.time())
        row = conn.execute(
            "SELECT * FROM remote_commands WHERE id = ?", (command_id,)
        ).fetchone()
        if not row:
            conn.close()
            return {"status": "error", "detail": "Command not found"}
        cmd = dict(row)

        if cmd["expires_at"] and now > cmd["expires_at"]:
            conn.close()
            return {"status": "error", "detail": "Command expired"}

        conn.execute("""
            INSERT INTO command_acknowledgments
                (command_id, endpoint_id, status, output, acknowledged_at)
            VALUES (?, ?, 'ACKNOWLEDGED', ?, ?)
        """, (command_id, endpoint_id, json.dumps(output or {}), now))

        target_ids = json.loads(cmd["target_ids"])
        conn.execute(
            "UPDATE remote_commands SET acknowledged_count = acknowledged_count + 1 WHERE id = ?",
            (command_id,),
        )
        conn.commit()
        conn.close()
        return {"status": "acknowledged", "command_id": command_id, "endpoint_id": endpoint_id}

    def complete(self, command_id: str, endpoint_id: str, success: bool, output: Optional[dict] = None) -> dict:
        conn = self._db()
        now = int(time.time())
        status = "COMPLETED" if success else "FAILED"

        conn.execute("""
            UPDATE command_acknowledgments SET status = ?, output = ?, completed_at = ?
            WHERE command_id = ? AND endpoint_id = ?
        """, (status, json.dumps(output or {}), now, command_id, endpoint_id))

        if success:
            conn.execute("UPDATE remote_commands SET completed_count = completed_count + 1 WHERE id = ?", (command_id,))
        else:
            conn.execute("UPDATE remote_commands SET failed_count = failed_count + 1 WHERE id = ?", (command_id,))

        row = conn.execute("SELECT * FROM remote_commands WHERE id = ?", (command_id,)).fetchone()
        cmd = dict(row)
        target_ids = json.loads(cmd["target_ids"])
        total = len(target_ids) if cmd["target_type"] != "all" else 1
        if cmd["completed_count"] + cmd["failed_count"] >= total:
            conn.execute(
                "UPDATE remote_commands SET status = 'COMPLETED' WHERE id = ? AND status = 'PENDING'",
                (command_id,),
            )
        conn.commit()
        conn.close()
        return {"status": status, "command_id": command_id, "endpoint_id": endpoint_id}

    def get_pending(self, endpoint_id: str) -> list[dict]:
        conn = self._db()
        now = int(time.time())
        rows = conn.execute("""
            SELECT * FROM remote_commands
            WHERE status = 'PENDING'
              AND (expires_at IS NULL OR expires_at > ?)
              AND (target_type = 'all'
                   OR (target_type = 'endpoint' AND target_ids LIKE ?)
                   OR (target_type = 'group' AND target_ids LIKE ?))
            ORDER BY priority DESC, issued_at ASC
        """, (now, f"%{endpoint_id}%", f"%{endpoint_id}%")).fetchall()
        conn.close()
        return [dict(r) for r in rows]

    def get_pending_for_agent(self, endpoint_id: str) -> list[dict]:
        pending = self.get_pending(endpoint_id)
        # Exclude already-acknowledged commands
        conn = self._db()
        acked = set(
            row[0] for row in conn.execute(
                "SELECT command_id FROM command_acknowledgments WHERE endpoint_id = ?",
                (endpoint_id,)
            ).fetchall()
        )
        conn.close()
        return [c for c in pending if c["id"] not in acked]

    def verify_command(self, command: dict) -> bool:
        signing_payload = json.dumps({
            "id": command["id"], "type": command["command_type"],
            "target_ids": json.loads(command["target_ids"]),
            "nonce": command.get("nonce", ""),
            "expires_at": command["expires_at"], "issued_at": command["issued_at"],
        }, sort_keys=True)
        return _verify(signing_payload, command.get("signature", ""))

    def get_command(self, command_id: str) -> Optional[dict]:
        conn = self._db()
        row = conn.execute("SELECT * FROM remote_commands WHERE id = ?", (command_id,)).fetchone()
        conn.close()
        return dict(row) if row else None

    def list_commands(self, status: Optional[str] = None, command_type: Optional[str] = None, page: int = 1, limit: int = 50) -> dict:
        conn = self._db()
        conditions = []
        params = []
        if status:
            conditions.append("status = ?"); params.append(status)
        if command_type:
            conditions.append("command_type = ?"); params.append(command_type)
        where = "WHERE " + " AND ".join(conditions) if conditions else ""
        offset = (page - 1) * limit
        total = conn.execute(f"SELECT COUNT(*) FROM remote_commands {where}", params).fetchone()[0]
        rows = conn.execute(
            f"SELECT * FROM remote_commands {where} ORDER BY issued_at DESC LIMIT ? OFFSET ?",
            (*params, limit, offset)
        ).fetchall()
        conn.close()
        return {"commands": [dict(r) for r in rows], "total": total, "page": page, "limit": limit}

    def get_acknowledgments(self, command_id: str) -> list[dict]:
        conn = self._db()
        rows = conn.execute(
            "SELECT * FROM command_acknowledgments WHERE command_id = ? ORDER BY acknowledged_at",
            (command_id,)
        ).fetchall()
        conn.close()
        return [dict(r) for r in rows]


_command_engine = None


def get_command_engine(db_conn_callable) -> CommandEngine:
    global _command_engine
    if _command_engine is None:
        _command_engine = CommandEngine(db_conn_callable)
    return _command_engine
