import sqlite3, os
db_path = os.path.join(os.getcwd(), 'data', 'central.db')
conn = sqlite3.connect(db_path)
c = conn.cursor()
c.execute("SELECT name FROM sqlite_master WHERE type='table'")
tables = c.fetchall()
print('Tables in central.db:')
for t in tables:
    c.execute("PRAGMA table_info(%s)" % t[0])
    cols = c.fetchall()
    print("  %s:" % t[0])
    for col in cols:
        print("    ", col)
conn.close()
