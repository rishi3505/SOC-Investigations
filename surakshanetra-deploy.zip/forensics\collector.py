import asyncio
import platform
import subprocess
import time
import logging

from .system_collector import (
    collect_system_info,
    collect_device_fingerprint,
    collect_ip_addresses,
    collect_windows_version,
    collect_logged_in_users,
)
from .process_collector import collect_processes, collect_active_services
from .network_collector import (
    collect_network_connections,
    collect_listening_ports,
    collect_established_connections,
    collect_dns_cache,
    collect_arp_cache,
    collect_routing_table,
)
from .event_collector import collect_windows_events, collect_relevant_events

logger = logging.getLogger(__name__)


class ForensicCollector:
    def __init__(self, evidence_dir: str = None):
        self.evidence_dir = evidence_dir

    async def collect_all(self, incident_id: str = None) -> dict:
        start = time.time()
        logger.info("Starting forensic collection for incident=%s", incident_id)

        tasks = {
            "system": self._collect_system(),
            "processes": self._collect_processes(),
            "network": self._collect_network(),
            "windows_events": self._collect_events(),
            "startup_scheduled": self._collect_startup_and_scheduled(),
            "installed_software": self._collect_installed_software(),
            "usb_history": self._collect_usb_history(),
        }

        results = {}
        for key, coro in tasks.items():
            try:
                results[key] = await coro
            except Exception as e:
                logger.error("Failed to collect %s: %s", key, e)
                results[key] = {"error": str(e)}

        results["collection_metadata"] = {
            "incident_id": incident_id,
            "collection_start": start,
            "collection_end": time.time(),
            "collection_duration_ms": round((time.time() - start) * 1000, 2),
            "collector_version": "1.0.0",
        }

        logger.info(
            "Forensic collection completed in %.2fms for incident=%s",
            results["collection_metadata"]["collection_duration_ms"],
            incident_id,
        )
        return results

    async def _collect_system(self) -> dict:
        loop = asyncio.get_event_loop()
        system = await loop.run_in_executor(None, collect_system_info)
        fingerprint = await loop.run_in_executor(None, collect_device_fingerprint)
        ips = await loop.run_in_executor(None, collect_ip_addresses)
        winver = await loop.run_in_executor(None, collect_windows_version)
        users = await loop.run_in_executor(None, collect_logged_in_users)
        return {
            "info": system,
            "fingerprint": fingerprint,
            "ip_addresses": ips,
            "windows_version": winver,
            "logged_in_users": users,
        }

    async def _collect_processes(self) -> dict:
        loop = asyncio.get_event_loop()
        processes = await loop.run_in_executor(None, collect_processes)
        services = await loop.run_in_executor(None, collect_active_services)
        return {"processes": processes, "services": services}

    async def _collect_network(self) -> dict:
        loop = asyncio.get_event_loop()
        connections = await loop.run_in_executor(None, collect_network_connections)
        listening = await loop.run_in_executor(None, collect_listening_ports)
        established = await loop.run_in_executor(None, collect_established_connections)
        dns = await loop.run_in_executor(None, collect_dns_cache)
        arp = await loop.run_in_executor(None, collect_arp_cache)
        routing = await loop.run_in_executor(None, collect_routing_table)
        return {
            "connections": connections,
            "listening_ports": listening,
            "established_connections": established,
            "dns_cache": dns,
            "arp_cache": arp,
            "routing_table": routing,
        }

    async def _collect_events(self) -> dict:
        loop = asyncio.get_event_loop()
        application = await loop.run_in_executor(None, collect_windows_events, "Application", 100)
        system = await loop.run_in_executor(None, collect_windows_events, "System", 100)
        security = await loop.run_in_executor(None, collect_windows_events, "Security", 100)
        relevant = await loop.run_in_executor(None, collect_relevant_events, 50)
        return {
            "application": application,
            "system": system,
            "security": security,
            "relevant_events": relevant,
        }

    async def _collect_startup_and_scheduled(self) -> dict:
        loop = asyncio.get_event_loop()
        startup = []
        scheduled = []

        if platform.system() == "Windows":
            try:
                result = await loop.run_in_executor(
                    None,
                    lambda: subprocess.run(
                        ["wmic", "startup", "get", "caption,command,user", "/format:csv"],
                        capture_output=True, text=True, timeout=15,
                    ),
                )
                if result.returncode == 0:
                    for line in result.stdout.splitlines()[2:]:
                        parts = line.split(",")
                        if len(parts) >= 4:
                            startup.append({
                                "caption": parts[2].strip() if len(parts) > 2 else "",
                                "command": parts[3].strip() if len(parts) > 3 else "",
                                "user": parts[4].strip() if len(parts) > 4 else "",
                            })
            except (subprocess.TimeoutExpired, FileNotFoundError):
                pass

            try:
                result = await loop.run_in_executor(
                    None,
                    lambda: subprocess.run(
                        ["schtasks", "/query", "/fo", "CSV", "/v"],
                        capture_output=True, text=True, timeout=15,
                    ),
                )
                if result.returncode == 0:
                    for line in result.stdout.splitlines()[2:]:
                        parts = line.split(",")
                        if len(parts) >= 4:
                            scheduled.append({
                                "task_name": parts[0].strip('" ') if parts else "",
                                "next_run": parts[1].strip('" ') if len(parts) > 1 else "",
                                "status": parts[2].strip('" ') if len(parts) > 2 else "",
                                "author": parts[3].strip('" ') if len(parts) > 3 else "",
                            })
            except (subprocess.TimeoutExpired, FileNotFoundError):
                pass

        return {"startup_applications": startup, "scheduled_tasks": scheduled}

    async def _collect_installed_software(self) -> list:
        software = []
        if platform.system() != "Windows":
            return software
        try:
            import winreg
        except ImportError:
            return software

        loop = asyncio.get_event_loop()

        def _query_software():
            result = []
            paths = [
                (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"),
                (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"),
            ]
            for hkey, path in paths:
                try:
                    with winreg.OpenKey(hkey, path) as key:
                        for i in range(winreg.QueryInfoKey(key)[0]):
                            try:
                                subkey_name = winreg.EnumKey(key, i)
                                with winreg.OpenKey(key, subkey_name) as subkey:
                                    try:
                                        name = winreg.QueryValueEx(subkey, "DisplayName")[0]
                                        version = winreg.QueryValueEx(subkey, "DisplayVersion")[0] if "DisplayVersion" in [winreg.EnumValue(subkey, j)[0] for j in range(winreg.QueryInfoKey(subkey)[1])] else ""
                                        publisher = winreg.QueryValueEx(subkey, "Publisher")[0] if "Publisher" in [winreg.EnumValue(subkey, j)[0] for j in range(winreg.QueryInfoKey(subkey)[1])] else ""
                                        install_date = winreg.QueryValueEx(subkey, "InstallDate")[0] if "InstallDate" in [winreg.EnumValue(subkey, j)[0] for j in range(winreg.QueryInfoKey(subkey)[1])] else ""
                                        result.append({
                                            "name": name,
                                            "version": version,
                                            "publisher": publisher,
                                            "install_date": install_date,
                                        })
                                    except (OSError, FileNotFoundError):
                                        pass
                            except OSError:
                                pass
                except OSError:
                    pass
            return result

        software = await loop.run_in_executor(None, _query_software)
        return software

    async def _collect_usb_history(self) -> list:
        history = []
        if platform.system() != "Windows":
            return history
        try:
            import winreg
        except ImportError:
            return history

        loop = asyncio.get_event_loop()

        def _query_usb():
            result = []
            paths = [
                (winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Enum\USBSTOR"),
                (winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Enum\USB"),
            ]
            for hkey, path in paths:
                try:
                    with winreg.OpenKey(hkey, path) as key:
                        for i in range(winreg.QueryInfoKey(key)[0]):
                            try:
                                device = winreg.EnumKey(key, i)
                                with winreg.OpenKey(key, device) as subkey:
                                    for j in range(winreg.QueryInfoKey(subkey)[0]):
                                        try:
                                            instance = winreg.EnumKey(subkey, j)
                                            with winreg.OpenKey(subkey, instance) as inst_key:
                                                try:
                                                    friendly = winreg.QueryValueEx(inst_key, "FriendlyName")[0]
                                                    result.append({
                                                        "device": device,
                                                        "instance": instance,
                                                        "friendly_name": friendly,
                                                    })
                                                except (OSError, FileNotFoundError):
                                                    result.append({
                                                        "device": device,
                                                        "instance": instance,
                                                        "friendly_name": "",
                                                    })
                                        except OSError:
                                            pass
                            except OSError:
                                pass
                except OSError:
                    pass
            return result

        history = await loop.run_in_executor(None, _query_usb)
        return history
