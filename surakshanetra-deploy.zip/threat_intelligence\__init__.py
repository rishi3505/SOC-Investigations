"""
Threat Intelligence Package — IOC management, feed ingestion, reputation,
matching, threat scoring, and caching for XDR enrichment.
"""
