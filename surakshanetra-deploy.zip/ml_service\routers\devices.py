import json
import os
import sys

sys.path.append(os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.append(os.path.join(os.path.dirname(__file__), ".."))

from fastapi import APIRouter, HTTPException

router = APIRouter()


@router.get("/api/v1/devices")
def list_devices(limit: int = 100):
    from backend.db import get_all_devices
    df = get_all_devices(limit=limit)
    return {"devices": json.loads(df.to_json(orient="records")) if not df.empty else []}


@router.post("/api/v1/devices/approve")
def approve_device(payload: dict):
    from backend.db import approve_device as approve_device_db
    device_hash = payload.get("device_hash")
    notes = payload.get("notes")
    if not device_hash:
        raise HTTPException(status_code=400, detail="device_hash required")
    success = approve_device_db(device_hash, notes=notes)
    if not success:
        raise HTTPException(status_code=404, detail="Device not found")
    return {"status": "approved", "device_hash": device_hash}


@router.post("/api/v1/devices/revoke")
def revoke_device(payload: dict):
    from backend.db import revoke_device as revoke_device_db
    device_hash = payload.get("device_hash")
    if not device_hash:
        raise HTTPException(status_code=400, detail="device_hash required")
    success = revoke_device_db(device_hash)
    if not success:
        raise HTTPException(status_code=404, detail="Device not found")
    return {"status": "revoked", "device_hash": device_hash}


@router.get("/api/v1/devices/history")
def device_history(device_hash: str = None, limit: int = 100):
    from backend.db import get_device_history
    df = get_device_history(device_hash=device_hash, limit=limit)
    return {"history": json.loads(df.to_json(orient="records")) if not df.empty else []}
