"""
Device Registry — cross-endpoint device fingerprint tracking
"""
import json
import time
from fastapi import APIRouter, Depends, HTTPException, Query
from ..database import get_connection
from ..auth import authenticate_request
from ..models import RegisterDeviceRequest, ApproveDeviceRequest

router = APIRouter(prefix="/api/v1/devices", tags=["Device Registry"])


@router.get("")
async def list_devices(
    trust_status: str = None,
    search: str = None,
    page: int = Query(1, ge=1),
    limit: int = Query(50, ge=1, le=100),
    user: dict = Depends(authenticate_request),
):
    conn = get_connection()
    cursor = conn.cursor()
    conditions = []
    params = []
    if trust_status:
        conditions.append("d.trust_status = ?")
        params.append(trust_status.upper())
    if search:
        conditions.append("(d.device_hash LIKE ? OR d.hostname LIKE ?)")
        s = f"%{search}%"
        params.extend([s, s])
    where = "WHERE " + " AND ".join(conditions) if conditions else ""
    offset = (page - 1) * limit
    cursor.execute(f"SELECT d.*, e.hostname as endpoint_hostname FROM device_fingerprints d LEFT JOIN endpoints e ON d.endpoint_id = e.endpoint_id {where} ORDER BY d.last_seen DESC LIMIT ? OFFSET ?", (*params, limit, offset))
    rows = cursor.fetchall()
    cursor.execute(f"SELECT COUNT(*) FROM device_fingerprints d {where}", params)
    total = cursor.fetchone()[0]
    conn.close()
    return {"devices": [dict(r) for r in rows], "total": total, "page": page, "limit": limit}


@router.post("/register")
async def register_device(payload: RegisterDeviceRequest, user: dict = Depends(authenticate_request)):
    endpoint_id = payload.endpoint_id
    device_hash = payload.device_hash
    if not endpoint_id or not device_hash:
        raise HTTPException(status_code=400, detail="endpoint_id and device_hash required")
    conn = get_connection()
    cursor = conn.cursor()
    now = int(time.time())
    cursor.execute("""
        INSERT INTO device_fingerprints
            (endpoint_id, device_hash, hostname, os_version, windows_build,
             architecture, first_seen, last_seen, trust_status)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'PENDING_TRUST')
        ON CONFLICT(endpoint_id) DO UPDATE SET
            device_hash = excluded.device_hash,
            hostname = excluded.hostname,
            last_seen = excluded.last_seen,
            change_count = change_count + 1
    """, (
        endpoint_id, device_hash,
        payload.hostname,
        payload.os_version,
        payload.windows_build,
        payload.architecture or "",
        now, now,
    ))
    conn.commit()
    conn.close()
    return {"status": "registered", "endpoint_id": endpoint_id, "device_hash": device_hash}


@router.post("/{device_hash}/approve")
async def approve_device(device_hash: str, payload: ApproveDeviceRequest = None, user: dict = Depends(authenticate_request)):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE device_fingerprints SET trust_status = 'TRUSTED' WHERE device_hash = ?", (device_hash,))
    conn.commit()
    conn.close()
    return {"status": "approved", "device_hash": device_hash}


@router.post("/{device_hash}/revoke")
async def revoke_device(device_hash: str, user: dict = Depends(authenticate_request)):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE device_fingerprints SET trust_status = 'REVOKED' WHERE device_hash = ?", (device_hash,))
    conn.commit()
    conn.close()
    return {"status": "revoked", "device_hash": device_hash}
