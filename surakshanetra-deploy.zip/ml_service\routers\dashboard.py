import json
import os
import sys

sys.path.append(os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.append(os.path.join(os.path.dirname(__file__), ".."))

from fastapi import APIRouter

from backend.db import (
    get_total_record_count, get_user_profiles_all, get_session_history_all,
    get_behavior_by_user, get_trusted_locations_all, get_user_thresholds,
    get_sample_count, get_response_history, get_policy_audit,
)
from backend.mitre_mapping import get_all_techniques

router = APIRouter()


@router.get("/api/v1/dashboard/stats")
def dashboard_stats():
    total_records = get_total_record_count()
    profiles = get_user_profiles_all()
    return {"total_records": total_records, "total_users": len(profiles), "users": profiles.to_dict(orient="records") if not profiles.empty else []}


@router.get("/api/v1/dashboard/sessions/{user_id}")
def dashboard_sessions(user_id: str, limit: int = 50):
    history = get_session_history_all(user_id=user_id, limit=limit)
    return {"user_id": user_id, "sessions": history.to_dict(orient="records") if not history.empty else []}


@router.get("/api/v1/dashboard/behavior/{user_id}")
def dashboard_behavior(user_id: str, limit: int = 100):
    behavior = get_behavior_by_user(user_id, limit=limit)
    return {"user_id": user_id, "records": behavior.to_dict(orient="records") if not behavior.empty else []}


@router.get("/api/v1/dashboard/locations")
def dashboard_locations():
    locations = get_trusted_locations_all()
    return {"locations": locations.to_dict(orient="records") if not locations.empty else []}


@router.get("/api/v1/dashboard/thresholds/{user_id}")
def dashboard_thresholds(user_id: str):
    thresholds = get_user_thresholds(user_id)
    sample_count = get_sample_count(user_id)
    return {"user_id": user_id, "thresholds": thresholds, "samples_collected": sample_count}


@router.get("/api/v1/response-history")
def response_history(user_id: str = None, limit: int = 100):
    df = get_response_history(user_id=user_id, limit=limit)
    return {"history": json.loads(df.to_json(orient="records")) if not df.empty else []}


@router.get("/api/v1/policy-audit")
def policy_audit(limit: int = 100):
    df = get_policy_audit(limit=limit)
    return {"audit": json.loads(df.to_json(orient="records")) if not df.empty else []}


@router.get("/api/v1/mitre-techniques")
def mitre_techniques():
    return {"techniques": get_all_techniques()}
