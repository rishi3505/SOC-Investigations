import hashlib
import json
import os
import re
import shutil
import time
import zipfile

from .chain_of_custody import ChainOfCustody

EVIDENCE_BASE_DIR = os.path.join(os.path.dirname(__file__), "..", "evidence")


def _sanitize_incident_id(incident_id: str) -> str:
    safe = re.sub(r"[^a-zA-Z0-9_\-]", "", incident_id)
    if not safe:
        safe = "unknown"
    return safe


class EvidencePacker:
    def __init__(self, incident_id: str):
        self.incident_id = _sanitize_incident_id(incident_id)
        self.case_dir = os.path.join(EVIDENCE_BASE_DIR, self.incident_id)
        self.logs_dir = os.path.join(self.case_dir, "logs")
        self.chain = ChainOfCustody(incident_id=incident_id)

    def ensure_dirs(self):
        os.makedirs(self.case_dir, exist_ok=True)
        os.makedirs(self.logs_dir, exist_ok=True)

    def save_json(self, filename: str, data: dict) -> str:
        path = os.path.join(self.case_dir, filename)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, default=str)
        self.chain.add_hash(path, filename)
        return path

    def save_artifact(self, filename: str, data: dict) -> str:
        return self.save_json(filename, data)

    def write_metadata(self, incident: dict = None):
        metadata = {
            "incident_id": self.incident_id,
            "case_id": self.chain.case_id,
            "collection_time": int(time.time()),
            "collection_time_iso": time.strftime(
                "%Y-%m-%dT%H:%M:%SZ", time.gmtime()
            ),
            "collector": "ForensicCollector v1.0.0",
            "hostname": self.chain.hostname,
            "device_id": self.chain.device_id,
            "incident": incident,
        }
        if incident:
            metadata["incident_severity"] = incident.get("severity", "")
            metadata["incident_user"] = incident.get("user_id", "")
            metadata["incident_risk_score"] = incident.get("risk_score", 0)
        return self.save_json("metadata.json", metadata)

    def write_processes(self, process_data: dict):
        return self.save_json("processes.json", process_data)

    def write_network(self, network_data: dict):
        return self.save_json("network.json", network_data)

    def write_system(self, system_data: dict):
        return self.save_json("system.json", system_data)

    def write_windows_events(self, event_data: dict):
        return self.save_json("windows_events.json", event_data)

    def write_behavior(self, behavior_data: dict):
        return self.save_json("behavior.json", behavior_data)

    def write_policy(self, policy_data: dict):
        return self.save_json("policy.json", policy_data)

    def write_ml_results(self, ml_data: dict):
        return self.save_json("ml_results.json", ml_data)

    def write_device(self, device_data: dict):
        return self.save_json("device.json", device_data)

    def write_timeline(self, timeline_data: dict):
        return self.save_json("timeline.json", timeline_data)

    def _read_file_safe(self, path: str) -> str:
        try:
            with open(path, "r", encoding="utf-8") as f:
                return f.read()
        except (FileNotFoundError, IOError):
            return ""

    def generate_hash_manifest(self) -> dict:
        manifest = self.chain.generate_manifest()
        manifest_path = os.path.join(self.case_dir, "hash_manifest.json")
        with open(manifest_path, "w", encoding="utf-8") as f:
            json.dump(manifest, f, indent=2, default=str)
        return manifest

    def _get_files_for_zip(self) -> list:
        files = []
        for root, _, filenames in os.walk(self.case_dir):
            for fn in filenames:
                if fn.endswith(".zip"):
                    continue
                files.append(os.path.join(root, fn))
        return files

    def create_package(self, cleanup_after: bool = True) -> str:
        zip_path = os.path.join(EVIDENCE_BASE_DIR, f"{self.incident_id}.zip")
        files = self._get_files_for_zip()
        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
            for file_path in files:
                arcname = os.path.relpath(file_path, EVIDENCE_BASE_DIR)
                zf.write(file_path, arcname)
        zip_hash = hashlib.sha256()
        with open(zip_path, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                zip_hash.update(chunk)
        manifest = self.generate_hash_manifest()
        manifest["zip_file"] = {
            "path": zip_path,
            "sha256": zip_hash.hexdigest(),
            "size_bytes": os.path.getsize(zip_path),
        }
        with open(os.path.join(self.case_dir, "hash_manifest.json"), "w", encoding="utf-8") as f:
            json.dump(manifest, f, indent=2, default=str)
        return zip_path

    def cleanup_case_dir(self):
        if os.path.exists(self.case_dir):
            shutil.rmtree(self.case_dir)

    @staticmethod
    def get_package_path(incident_id: str) -> str:
        safe = _sanitize_incident_id(incident_id)
        return os.path.join(EVIDENCE_BASE_DIR, f"{safe}.zip")

    @staticmethod
    def package_exists(incident_id: str) -> bool:
        return os.path.exists(EvidencePacker.get_package_path(incident_id))

    @staticmethod
    def get_package_info(incident_id: str) -> dict:
        safe = _sanitize_incident_id(incident_id)
        zip_path = EvidencePacker.get_package_path(incident_id)
        if not os.path.exists(zip_path):
            return None
        manifest_path = os.path.join(EVIDENCE_BASE_DIR, safe, "hash_manifest.json")
        manifest = {}
        if os.path.exists(manifest_path):
            with open(manifest_path, "r", encoding="utf-8") as f:
                manifest = json.load(f)
        return {
            "incident_id": safe,
            "package_path": zip_path,
            "package_size_bytes": os.path.getsize(zip_path),
            "package_available": True,
            "manifest": manifest,
            "collected_at": os.path.getmtime(zip_path),
        }
