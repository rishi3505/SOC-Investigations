import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
import joblib
from pathlib import Path

MODELS_DIR = Path(__file__).resolve().parent / "models"

NUMERICAL_FEATURES = [
    "typing_speed", "key_latency", "avg_hold_time", "latency_jitter",
    "mouse_speed", "mouse_acceleration", "direction_change_freq",
    "click_frequency", "app_switch_count", "idle_time", "time_of_day"
]
CATEGORICAL_FEATURES = ["active_app"]

def get_preprocessor():
    """
    Creates and returns the ColumnTransformer for preprocessing.
    """
    preprocessor = ColumnTransformer(
        transformers=[
            ('num', StandardScaler(), NUMERICAL_FEATURES),
            ('cat', OneHotEncoder(handle_unknown='ignore'), CATEGORICAL_FEATURES)
        ])
    return preprocessor

def create_preprocessing_pipeline():
    """
    Creates a full preprocessing pipeline.
    """
    return Pipeline(steps=[('preprocessor', get_preprocessor())])

def save_preprocessing_artifacts(pipeline, X_train):
    """
    Saves the trained pipeline and historical means for XAI.
    """
    MODELS_DIR.mkdir(parents=True, exist_ok=True)
    joblib.dump(pipeline, MODELS_DIR / "preprocessing_pipeline.pkl")
    
    # Calculate historical means for normal data (X_train is assumed to be mostly normal)
    historical_means = X_train[NUMERICAL_FEATURES].mean().to_dict()
    import json
    with (MODELS_DIR / "historical_means.json").open("w", encoding="utf-8") as f:
        json.dump(historical_means, f)
    
    print(f"Preprocessing artifacts saved to {MODELS_DIR}")

def load_preprocessing_pipeline():
    """
    Loads the saved preprocessing pipeline.
    """
    path = MODELS_DIR / "preprocessing_pipeline.pkl"
    if path.exists():
        return joblib.load(path)
    return None

def load_historical_means():
    """
    Loads the historical means for explainability.
    """
    path = MODELS_DIR / "historical_means.json"
    if path.exists():
        import json
        with path.open("r", encoding="utf-8") as f:
            return json.load(f)
    return None
