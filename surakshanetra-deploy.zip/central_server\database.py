"""
Central Management Server — Database Schema & Connection
SQLite with multi-endpoint schema designed for future PostgreSQL migration.
"""
import json
import os
import sqlite3
import time

from .config import SQLITE_DB_PATH


def get_connection() -> sqlite3.Connection:
    os.makedirs(os.path.dirname(SQLITE_DB_PATH), exist_ok=True)
    conn = sqlite3.connect(SQLITE_DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init_database():
    conn = get_connection()
    cursor = conn.cursor()

    cursor.executescript("""
        CREATE TABLE IF NOT EXISTS organizations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            created_at INTEGER NOT NULL
        );

        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            password_hash TEXT,
            role TEXT DEFAULT 'analyst',
            org_id INTEGER,
            api_key TEXT UNIQUE,
            created_at INTEGER NOT NULL,
            FOREIGN KEY(org_id) REFERENCES organizations(id)
        );

        CREATE TABLE IF NOT EXISTS endpoints (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            org_id INTEGER,
            endpoint_id TEXT NOT NULL UNIQUE,
            device_id TEXT,
            hostname TEXT,
            agent_version TEXT,
            build_number INTEGER DEFAULT 0,
            os TEXT,
            os_version TEXT,
            architecture TEXT,
            ip_address TEXT,
            install_date TEXT,
            last_update TEXT,
            first_seen INTEGER NOT NULL,
            last_seen INTEGER,
            health_status TEXT DEFAULT 'UNKNOWN',
            session_state TEXT DEFAULT 'NORMAL',
            risk_level TEXT DEFAULT 'LOW',
            policy_version TEXT DEFAULT '0',
            tags TEXT DEFAULT '[]',
            metadata TEXT DEFAULT '{}',
            FOREIGN KEY(org_id) REFERENCES organizations(id)
        );

        CREATE TABLE IF NOT EXISTS heartbeats (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            endpoint_id TEXT NOT NULL,
            cpu_percent REAL DEFAULT 0,
            memory_mb REAL DEFAULT 0,
            current_user TEXT,
            risk_level TEXT DEFAULT 'LOW',
            agent_version TEXT,
            health_status TEXT DEFAULT 'ONLINE',
            session_state TEXT DEFAULT 'NORMAL',
            incident_count INTEGER DEFAULT 0,
            policy_version TEXT DEFAULT '0',
            timestamp INTEGER NOT NULL,
            FOREIGN KEY(endpoint_id) REFERENCES endpoints(endpoint_id)
        );

        CREATE TABLE IF NOT EXISTS incidents (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            endpoint_id TEXT,
            incident_id TEXT NOT NULL UNIQUE,
            org_id INTEGER,
            user_id TEXT,
            severity TEXT DEFAULT 'MEDIUM',
            status TEXT DEFAULT 'OPEN',
            risk_score REAL DEFAULT 0,
            confidence REAL DEFAULT 0,
            evidence_score REAL DEFAULT 0,
            mitre_technique TEXT,
            mitre_technique_name TEXT,
            mitre_tactic TEXT,
            recommended_action TEXT,
            reason_json TEXT DEFAULT '{}',
            response_level INTEGER DEFAULT 0,
            system_state TEXT DEFAULT 'NORMAL',
            evidence_package_path TEXT,
            assigned_analyst TEXT,
            created_at INTEGER NOT NULL,
            resolved_at INTEGER,
            resolution_notes TEXT,
            FOREIGN KEY(endpoint_id) REFERENCES endpoints(endpoint_id)
        );

        CREATE TABLE IF NOT EXISTS policies (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            org_id INTEGER,
            name TEXT NOT NULL,
            enabled INTEGER DEFAULT 1,
            policy_json TEXT NOT NULL,
            version TEXT DEFAULT '1.0.0',
            created_at INTEGER NOT NULL,
            updated_at INTEGER,
            FOREIGN KEY(org_id) REFERENCES organizations(id)
        );

        CREATE TABLE IF NOT EXISTS notifications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            endpoint_id TEXT,
            org_id INTEGER,
            type TEXT NOT NULL,
            severity TEXT DEFAULT 'INFO',
            message TEXT,
            read INTEGER DEFAULT 0,
            created_at INTEGER NOT NULL,
            FOREIGN KEY(endpoint_id) REFERENCES endpoints(endpoint_id)
        );

        CREATE TABLE IF NOT EXISTS audit_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            endpoint_id TEXT,
            org_id INTEGER,
            action TEXT NOT NULL,
            details TEXT DEFAULT '{}',
            timestamp INTEGER NOT NULL,
            FOREIGN KEY(endpoint_id) REFERENCES endpoints(endpoint_id)
        );

        CREATE TABLE IF NOT EXISTS device_fingerprints (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            endpoint_id TEXT NOT NULL,
            device_hash TEXT,
            hostname TEXT,
            os_version TEXT,
            windows_build TEXT,
            architecture TEXT,
            first_seen INTEGER NOT NULL,
            last_seen INTEGER,
            change_count INTEGER DEFAULT 0,
            trust_status TEXT DEFAULT 'PENDING_TRUST',
            FOREIGN KEY(endpoint_id) REFERENCES endpoints(endpoint_id)
        );

        CREATE TABLE IF NOT EXISTS behavior_data (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            endpoint_id TEXT,
            user_id TEXT,
            typing_speed REAL,
            key_latency REAL,
            avg_hold_time REAL,
            latency_jitter REAL,
            mouse_speed REAL,
            mouse_acceleration REAL,
            direction_change_freq REAL,
            click_frequency REAL,
            active_app TEXT,
            app_switch_count INTEGER,
            idle_time REAL,
            time_of_day INTEGER,
            session_duration REAL,
            ip_address TEXT,
            city TEXT,
            country TEXT,
            is_new_location INTEGER,
            risk_score REAL,
            is_anomalous INTEGER,
            timestamp INTEGER NOT NULL,
            FOREIGN KEY(endpoint_id) REFERENCES endpoints(endpoint_id)
        );
    """)

    # Enterprise endpoint management tables
    _create_enterprise_tables(conn)
    _create_indexes(conn)
    conn.commit()
    conn.close()
    print(f"Central database initialized at {SQLITE_DB_PATH}")


def _create_enterprise_tables(conn):
    conn.executescript("""
        -- Endpoint lifecycle columns (added via migration)
        CREATE TABLE IF NOT EXISTS endpoint_lifecycle_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            endpoint_id TEXT NOT NULL,
            from_status TEXT,
            to_status TEXT NOT NULL,
            triggered_by TEXT DEFAULT 'system',
            reason TEXT DEFAULT '',
            timestamp INTEGER NOT NULL
        );

        -- Remote commands
        CREATE TABLE IF NOT EXISTS remote_commands (
            id TEXT PRIMARY KEY,
            command_type TEXT NOT NULL,
            target_type TEXT NOT NULL DEFAULT 'endpoint',
            target_ids TEXT NOT NULL DEFAULT '[]',
            payload TEXT DEFAULT '{}',
            status TEXT DEFAULT 'PENDING',
            priority INTEGER DEFAULT 0,
            issued_by TEXT NOT NULL,
            issued_at INTEGER NOT NULL,
            expires_at INTEGER,
            signature TEXT DEFAULT '',
            acknowledged_count INTEGER DEFAULT 0,
            completed_count INTEGER DEFAULT 0,
            failed_count INTEGER DEFAULT 0,
            result_summary TEXT DEFAULT '{}'
        );

        CREATE TABLE IF NOT EXISTS command_acknowledgments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            command_id TEXT NOT NULL,
            endpoint_id TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'ACKNOWLEDGED',
            output TEXT DEFAULT '{}',
            acknowledged_at INTEGER NOT NULL,
            completed_at INTEGER
        );

        -- Configuration profiles
        CREATE TABLE IF NOT EXISTS config_profiles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            description TEXT DEFAULT '',
            config_json TEXT NOT NULL DEFAULT '{}',
            version TEXT DEFAULT '1.0.0',
            created_by TEXT DEFAULT 'admin',
            created_at INTEGER NOT NULL,
            updated_at INTEGER,
            active INTEGER DEFAULT 1
        );

        CREATE TABLE IF NOT EXISTS config_assignments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            profile_id INTEGER NOT NULL,
            target_type TEXT NOT NULL,
            target_id TEXT NOT NULL,
            assigned_at INTEGER NOT NULL,
            status TEXT DEFAULT 'PENDING',
            applied_at INTEGER,
            UNIQUE(profile_id, target_type, target_id)
        );

        -- Agent updates
        CREATE TABLE IF NOT EXISTS agent_updates (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            version TEXT NOT NULL UNIQUE,
            build_number INTEGER DEFAULT 0,
            release_notes TEXT DEFAULT '',
            package_url TEXT DEFAULT '',
            package_hash TEXT DEFAULT '',
            min_supported_version TEXT DEFAULT '0',
            mandatory INTEGER DEFAULT 0,
            status TEXT DEFAULT 'DRAFT',
            created_by TEXT DEFAULT 'admin',
            created_at INTEGER NOT NULL,
            released_at INTEGER
        );

        CREATE TABLE IF NOT EXISTS update_deployments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            update_id INTEGER NOT NULL,
            target_type TEXT NOT NULL,
            target_id TEXT NOT NULL,
            schedule_type TEXT DEFAULT 'IMMEDIATE',
            scheduled_at INTEGER,
            status TEXT DEFAULT 'PENDING',
            completed_at INTEGER,
            result TEXT DEFAULT '{}'
        );

        -- Health snapshots
        CREATE TABLE IF NOT EXISTS endpoint_health_snapshots (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            endpoint_id TEXT NOT NULL,
            health_score REAL DEFAULT 100.0,
            cpu_percent REAL DEFAULT 0,
            memory_percent REAL DEFAULT 0,
            disk_percent REAL DEFAULT 0,
            queue_size INTEGER DEFAULT 0,
            heartbeat_delay INTEGER DEFAULT 0,
            last_incident_age INTEGER DEFAULT 0,
            ml_health TEXT DEFAULT 'OK',
            db_health TEXT DEFAULT 'OK',
            service_status TEXT DEFAULT 'RUNNING',
            metrics_json TEXT DEFAULT '{}',
            timestamp INTEGER NOT NULL
        );

        -- Inventory
        CREATE TABLE IF NOT EXISTS inventories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            endpoint_id TEXT NOT NULL UNIQUE,
            hostname TEXT,
            os TEXT,
            os_version TEXT,
            os_build TEXT,
            architecture TEXT,
            cpu_brand TEXT,
            cpu_cores INTEGER,
            cpu_threads INTEGER,
            total_ram_mb INTEGER,
            disk_count INTEGER,
            total_disk_gb REAL,
            free_disk_gb REAL,
            gpu_info TEXT DEFAULT '[]',
            network_interfaces TEXT DEFAULT '[]',
            installed_software TEXT DEFAULT '[]',
            security_software TEXT DEFAULT '[]',
            python_version TEXT,
            agent_version TEXT,
            agent_build INTEGER,
            device_fingerprint TEXT DEFAULT '{}',
            windows_edition TEXT,
            windows_install_date TEXT,
            last_boot TEXT,
            collected_at INTEGER NOT NULL
        );

        CREATE TABLE IF NOT EXISTS inventory_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            endpoint_id TEXT NOT NULL,
            snapshot TEXT NOT NULL,
            changed_fields TEXT DEFAULT '[]',
            collected_at INTEGER NOT NULL
        );

        -- Endpoint groups
        CREATE TABLE IF NOT EXISTS endpoint_groups (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            description TEXT DEFAULT '',
            parent_id INTEGER,
            created_by TEXT DEFAULT 'admin',
            created_at INTEGER NOT NULL,
            updated_at INTEGER
        );

        CREATE TABLE IF NOT EXISTS group_members (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            group_id INTEGER NOT NULL,
            endpoint_id TEXT NOT NULL,
            added_at INTEGER NOT NULL,
            UNIQUE(group_id, endpoint_id)
        );

        -- Extended audit log
        CREATE TABLE IF NOT EXISTS audit_logs_extended (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            action TEXT NOT NULL,
            category TEXT DEFAULT 'admin',
            target_type TEXT DEFAULT '',
            target_id TEXT DEFAULT '',
            actor TEXT DEFAULT 'system',
            actor_role TEXT DEFAULT '',
            details TEXT DEFAULT '{}',
            ip_address TEXT DEFAULT '',
            user_agent TEXT DEFAULT '',
            timestamp INTEGER NOT NULL
        );

        -- Config drift tracking
        CREATE TABLE IF NOT EXISTS config_drift_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            endpoint_id TEXT NOT NULL,
            profile_id INTEGER,
            expected_version TEXT,
            actual_version TEXT,
            drift_details TEXT DEFAULT '{}',
            detected_at INTEGER NOT NULL,
            resolved_at INTEGER
        );
    """)

    # Add lifecycle columns to endpoints table if they don't exist
    _add_column_safe(conn, "endpoints", "lifecycle_status", "TEXT DEFAULT 'PENDING_REGISTRATION'")
    _add_column_safe(conn, "endpoints", "lifecycle_updated_at", "INTEGER")
    _add_column_safe(conn, "endpoints", "group_id", "INTEGER")
    _add_column_safe(conn, "endpoints", "current_config_id", "INTEGER")
    _add_column_safe(conn, "endpoints", "current_config_version", "TEXT DEFAULT '0'")
    _add_column_safe(conn, "endpoints", "latest_agent_version", "TEXT")
    _add_column_safe(conn, "endpoints", "latest_agent_build", "INTEGER")
    _add_column_safe(conn, "endpoints", "update_status", "TEXT DEFAULT 'UP_TO_DATE'")
    _add_column_safe(conn, "endpoints", "update_scheduled_at", "INTEGER")
    _add_column_safe(conn, "endpoints", "health_score", "REAL DEFAULT 100.0")
    _add_column_safe(conn, "endpoints", "health_updated_at", "INTEGER")
    _add_column_safe(conn, "endpoints", "inventory_hash", "TEXT")
    _add_column_safe(conn, "endpoints", "inventory_updated_at", "INTEGER")


def _create_indexes(conn):
    conn.executescript("""
        CREATE INDEX IF NOT EXISTS idx_endpoints_org ON endpoints(org_id);
        CREATE INDEX IF NOT EXISTS idx_endpoints_lifecycle ON endpoints(lifecycle_status);
        CREATE INDEX IF NOT EXISTS idx_endpoints_health ON endpoints(health_status);
        CREATE INDEX IF NOT EXISTS idx_endpoints_group ON endpoints(group_id);
        CREATE INDEX IF NOT EXISTS idx_heartbeats_endpoint_ts ON heartbeats(endpoint_id, timestamp DESC);
        CREATE INDEX IF NOT EXISTS idx_incidents_endpoint ON incidents(endpoint_id);
        CREATE INDEX IF NOT EXISTS idx_incidents_status ON incidents(status);
        CREATE INDEX IF NOT EXISTS idx_incidents_severity ON incidents(severity);
        CREATE INDEX IF NOT EXISTS idx_incidents_org ON incidents(org_id);
        CREATE INDEX IF NOT EXISTS idx_behavior_endpoint_ts ON behavior_data(endpoint_id, timestamp DESC);
        CREATE INDEX IF NOT EXISTS idx_notifications_org_read ON notifications(org_id, read);
        CREATE INDEX IF NOT EXISTS idx_audit_endpoint ON audit_logs(endpoint_id, timestamp DESC);
        CREATE INDEX IF NOT EXISTS idx_device_fp_endpoint ON device_fingerprints(endpoint_id);
        CREATE INDEX IF NOT EXISTS idx_lifecycle_log_endpoint ON endpoint_lifecycle_log(endpoint_id, timestamp DESC);
        CREATE INDEX IF NOT EXISTS idx_remote_commands_status ON remote_commands(status);
        CREATE INDEX IF NOT EXISTS idx_acknowledgments_command ON command_acknowledgments(command_id);
        CREATE INDEX IF NOT EXISTS idx_config_assignments_target ON config_assignments(target_type, target_id);
        CREATE INDEX IF NOT EXISTS idx_health_snapshots_endpoint ON endpoint_health_snapshots(endpoint_id, timestamp DESC);
        CREATE INDEX IF NOT EXISTS idx_inventory_history_endpoint ON inventory_history(endpoint_id, collected_at DESC);
        CREATE INDEX IF NOT EXISTS idx_group_members_group ON group_members(group_id);
        CREATE INDEX IF NOT EXISTS idx_group_members_endpoint ON group_members(endpoint_id);
        CREATE INDEX IF NOT EXISTS idx_audit_extended_category ON audit_logs_extended(category, timestamp DESC);
        CREATE INDEX IF NOT EXISTS idx_audit_extended_actor ON audit_logs_extended(actor);
        CREATE INDEX IF NOT EXISTS idx_config_drift_endpoint ON config_drift_log(endpoint_id);
        CREATE INDEX IF NOT EXISTS idx_update_deployments_update ON update_deployments(update_id);
        CREATE INDEX IF NOT EXISTS idx_config_assignments_profile ON config_assignments(profile_id);
    """)


def _add_column_safe(conn, table, column, col_def):
    try:
        conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {col_def}")
    except Exception:
        pass
