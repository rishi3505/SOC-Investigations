"""
Rule Engine — Loads, validates, and evaluates Sigma-inspired detection rules
against behavioral payloads and IOC match results.
"""
import glob
import json
import os
import re
import time
from typing import Optional

RULES_DIR = os.path.dirname(os.path.abspath(__file__))

RULE_FIELDS = frozenset({
    "title", "id", "description", "references", "author", "date", "modified",
    "mitre_attack", "severity", "status", "detection", "false_positives", "tags",
})

REQUIRED_RULE_FIELDS = {"title", "id", "description", "mitre_attack", "severity", "detection"}


def _validate_rule(rule: dict) -> Optional[str]:
    missing = REQUIRED_RULE_FIELDS - set(rule.keys())
    if missing:
        return f"Missing required fields: {missing}"
    if rule.get("status") == "disabled":
        return None
    extra = set(rule.keys()) - RULE_FIELDS
    if extra:
        return f"Unknown fields: {extra}"
    return None


def load_rules() -> list[dict]:
    rules = []
    for fp in sorted(glob.glob(os.path.join(RULES_DIR, "*.json"))):
        try:
            with open(fp, "r", encoding="utf-8") as f:
                rule = json.load(f)
            err = _validate_rule(rule)
            if err:
                continue
            if rule.get("status") == "disabled":
                continue
            rule["_filepath"] = fp
            rules.append(rule)
        except (json.JSONDecodeError, IOError):
            continue
    return rules


def get_rule_by_id(rule_id: str) -> Optional[dict]:
    for rule in load_rules():
        if rule["id"] == rule_id:
            return rule
    return None


def evaluate_rule(rule: dict, payload: dict, ioc_matches: list[dict]) -> Optional[dict]:
    detection = rule.get("detection", {})
    condition = detection.get("condition", "")
    thresholds = detection.get("thresholds", {})
    fields = detection.get("fields", [])

    risk_score = payload.get("risk_score", 0)
    is_anomalous = payload.get("is_anomalous", False)
    is_new_location = payload.get("is_new_location", False)
    confidence = payload.get("confidence_score", 0)
    unknown_device = payload.get("device_trust_status", "trusted") != "trusted"
    device_change_score = payload.get("device_change_score", 0)
    has_failed_mfa = payload.get("has_failed_mfa", False)

    matched_iocs = {}
    for ioc in ioc_matches:
        ioc_type = ioc.get("type", "")
        sev = ioc.get("severity", "LOW")
        matched_iocs[ioc_type] = sev

    matches = False
    match_reasons = []

    score_threshold = thresholds.get("risk_score", 0)
    anomaly_threshold = thresholds.get("anomaly_score", 0)
    conf_threshold = thresholds.get("confidence", 0)

    if condition == "anomaly_score > threshold":
        iscore = risk_score / 100.0 if risk_score > 1 else risk_score
        if iscore > anomaly_threshold and confidence >= conf_threshold:
            matches = True
            match_reasons.append(f"Anomaly score {iscore:.2f} exceeds threshold {anomaly_threshold}")

    elif condition == "ip_match_severity >= MEDIUM":
        sev = matched_iocs.get("IP", "")
        if sev in ("MEDIUM", "HIGH", "CRITICAL"):
            matches = True
            match_reasons.append(f"Known malicious IP (severity: {sev})")

    elif condition == "unknown_device AND risk_score >= threshold":
        if unknown_device and risk_score >= score_threshold:
            matches = True
            match_reasons.append(f"Unknown device with risk score {risk_score}")

    elif condition == "new_location AND (risk_score >= threshold OR speed_anomaly)":
        if is_new_location and risk_score >= score_threshold:
            matches = True
            match_reasons.append(f"New location with elevated risk {risk_score}")

    elif condition == "failed_attempts >= threshold AND typing_latency_jitter > max_expected":
        jitter = payload.get("latency_jitter", 0)
        jitter_threshold = thresholds.get("latency_jitter_threshold", 0.15)
        if has_failed_mfa and jitter > jitter_threshold:
            matches = True
            match_reasons.append(f"Failed MFA with high latency jitter {jitter:.3f}")

    elif condition == "process_match_found AND severity >= HIGH":
        if matched_iocs.get("PROCESS_NAME") in ("HIGH", "CRITICAL"):
            matches = True
            match_reasons.append("Known malicious process name detected")

    elif condition == "registry_match_found OR scheduled_task_match_found":
        if matched_iocs.get("REGISTRY_KEY") or matched_iocs.get("SCHEDULED_TASK") or matched_iocs.get("SERVICE_NAME"):
            matches = True
            match_reasons.append("Persistence indicator matched in IOC database")

    elif condition == "mouse_speed_anomaly AND app_switch_high AND session_duration_extreme":
        m = payload.get("mouse_speed", 0)
        asc = payload.get("app_switch_count", 0)
        sd = payload.get("session_duration", 0)
        if m > thresholds.get("mouse_speed_threshold", 800) and \
           asc > thresholds.get("app_switch_threshold", 20) and \
           sd > thresholds.get("session_duration_minutes", 480) * 60:
            matches = True
            match_reasons.append("Exfiltration pattern detected: high mouse speed, frequent app switching, long session")

    elif condition == "user_agent_match_found OR email_match_found":
        if matched_iocs.get("USER_AGENT") or matched_iocs.get("EMAIL"):
            matches = True
            match_reasons.append("Phishing-related IOC matched")

    elif condition == "service_match_found OR pipe_match_found OR mutex_match_found":
        if matched_iocs.get("SERVICE_NAME") or matched_iocs.get("NAMED_PIPE") or matched_iocs.get("MUTEX"):
            matches = True
            match_reasons.append("Lateral movement IOC matched")

    if matches:
        return {
            "rule_id": rule["id"],
            "rule_title": rule["title"],
            "severity": rule["severity"],
            "mitre_technique_id": rule["mitre_attack"]["technique_id"],
            "mitre_technique_name": rule["mitre_attack"]["technique_name"],
            "mitre_tactic": rule["mitre_attack"]["tactic"],
            "match_reasons": match_reasons,
            "matched_at": int(time.time()),
        }
    return None


def evaluate_all_rules(payload: dict, ioc_matches: list[dict]) -> list[dict]:
    triggered = []
    for rule in load_rules():
        result = evaluate_rule(rule, payload, ioc_matches)
        if result:
            triggered.append(result)
    return triggered
