import logging
from typing import Dict, Optional

logger = logging.getLogger(__name__)

MITRE_ATTACK_MAP: Dict[str, dict] = {
    "typing_anomaly": {
        "technique_id": "T1078",
        "technique_name": "Valid Accounts",
        "tactic": "Defense Evasion",
        "description": "Typing pattern deviation suggests possible credential misuse or session hijacking."
    },
    "mouse_anomaly": {
        "technique_id": "T1563",
        "technique_name": "Remote Service Session Hijacking",
        "tactic": "Lateral Movement",
        "description": "Mouse movement deviation indicates possible remote session hijacking."
    },
    "location_anomaly": {
        "technique_id": "T1078.001",
        "technique_name": "Default Accounts or Unknown Location",
        "tactic": "Initial Access",
        "description": "User activity from an unfamiliar geographic location."
    },
    "device_mismatch": {
        "technique_id": "T1090",
        "technique_name": "Proxy or Device Mismatch",
        "tactic": "Command and Control",
        "description": "Device fingerprint mismatch suggests possible proxy usage or device spoofing."
    },
    "unknown_application": {
        "technique_id": "T1204",
        "technique_name": "User Execution",
        "tactic": "Execution",
        "description": "Unknown or suspicious application detected in user session."
    },
    "behavior_anomaly": {
        "technique_id": "T1529",
        "technique_name": "System Shutdown/Reboot",
        "tactic": "Impact",
        "description": "General behavioral anomaly detected — possible user impersonation."
    },
    "time_anomaly": {
        "technique_id": "T1078.003",
        "technique_name": "Local Accounts at Unusual Time",
        "tactic": "Persistence",
        "description": "Activity detected outside normal working hours for this user."
    },
    "frequency_anomaly": {
        "technique_id": "T1021",
        "technique_name": "Remote Services — Abnormal Frequency",
        "tactic": "Lateral Movement",
        "description": "Abnormal action frequency suggests automated or scripted behavior."
    },
    "idle_anomaly": {
        "technique_id": "T1059",
        "technique_name": "Command and Scripting Interpreter",
        "tactic": "Execution",
        "description": "Unusual idle pattern — possible scripted interaction."
    },
    "generic_anomaly": {
        "technique_id": "T1078",
        "technique_name": "Valid Accounts — Anomalous Behavior",
        "tactic": "Defense Evasion",
        "description": "Multiple anomalous signals detected. Possible account compromise."
    },
    "device_spoofing": {
        "technique_id": "T1557.001",
        "technique_name": "Device Spoofing",
        "tactic": "Credential Access",
        "description": "Device fingerprint hash does not match any known trusted device for this user."
    },
    "hardware_tampering": {
        "technique_id": "T1557.002",
        "technique_name": "Hardware Tampering",
        "tactic": "Defense Evasion",
        "description": "Critical hardware identifiers (motherboard/BIOS) have changed — possible physical tampering."
    }
}

FEATURE_TO_MITRE: Dict[str, str] = {
    "typing_speed": "typing_anomaly",
    "key_latency": "typing_anomaly",
    "avg_hold_time": "typing_anomaly",
    "latency_jitter": "typing_anomaly",
    "mouse_speed": "mouse_anomaly",
    "mouse_acceleration": "mouse_anomaly",
    "direction_change_freq": "mouse_anomaly",
    "click_frequency": "frequency_anomaly",
    "active_app": "unknown_application",
    "app_switch_count": "behavior_anomaly",
    "idle_time": "idle_anomaly",
    "time_of_day": "time_anomaly",
    "ip_address": "location_anomaly",
    "city": "location_anomaly",
    "country": "location_anomaly"
}

SEVERITY_MITRE_MAP: Dict[str, str] = {
    "TRUSTED": "none",
    "LOW": "none",
    "MEDIUM": "behavior_anomaly",
    "SUSPICIOUS": "typing_anomaly",
    "HIGH": "location_anomaly",
    "CRITICAL": "generic_anomaly"
}


def map_mitre_technique(
    risk_level: str,
    deviating_features: list,
    is_new_location: bool = False,
    device_mismatch: bool = False,
    unknown_device: bool = False,
    device_fingerprint_changed: bool = False
) -> dict:
    if is_new_location:
        return dict(MITRE_ATTACK_MAP["location_anomaly"])

    if device_mismatch:
        return dict(MITRE_ATTACK_MAP["device_mismatch"])

    if device_fingerprint_changed:
        return dict(MITRE_ATTACK_MAP["hardware_tampering"])

    if unknown_device:
        return dict(MITRE_ATTACK_MAP["device_spoofing"])

    if deviating_features:
        for feature in deviating_features:
            key = FEATURE_TO_MITRE.get(feature)
            if key and key in MITRE_ATTACK_MAP:
                return dict(MITRE_ATTACK_MAP[key])
        return dict(MITRE_ATTACK_MAP["behavior_anomaly"])

    severity_key = SEVERITY_MITRE_MAP.get(risk_level, "generic_anomaly")
    if severity_key in MITRE_ATTACK_MAP:
        return dict(MITRE_ATTACK_MAP[severity_key])

    return dict(MITRE_ATTACK_MAP["generic_anomaly"])


def get_all_techniques() -> Dict[str, dict]:
    return {k: dict(v) for k, v in MITRE_ATTACK_MAP.items()}
