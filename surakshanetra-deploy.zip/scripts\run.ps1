<#
.SYNOPSIS
    Start SurakshaNetra CMS on Windows
.DESCRIPTION
    Activates venv, loads .env, and starts the CMS on port 9000.
.EXAMPLE
    .\scripts\run.ps1
    .\scripts\run.ps1 -Port 8080
#>

param(
    [int]$Port = 9000,
    [string]$Host = "0.0.0.0"
)

$ProjectRoot = Split-Path -Parent (Split-Path -Parent $PSCommandPath)
$venvPython = Join-Path $ProjectRoot ".venv\Scripts\python.exe"

if (-not (Test-Path $venvPython)) {
    Write-Host "Virtual environment not found. Run scripts\install.ps1 first." -ForegroundColor Red
    exit 1
}

# Load .env if exists
$envFile = Join-Path $ProjectRoot ".env"
if (Test-Path $envFile) {
    Get-Content $envFile | ForEach-Object {
        if ($_ -match "^\s*([^#=]+)=(.*)\s*$") {
            [Environment]::SetEnvironmentVariable($matches[1].Trim(), $matches[2].Trim(), "Process")
        }
    }
    Write-Host "Loaded .env file" -ForegroundColor Gray
}

Write-Host "=== SurakshaNetra CMS ===" -ForegroundColor Cyan
Write-Host "Starting on http://$Host`:$Port" -ForegroundColor Green
Write-Host "Health: http://localhost:$Port/health" -ForegroundColor Green
Write-Host "Press Ctrl+C to stop`n" -ForegroundColor Gray

& $venvPython -m central_server.main
