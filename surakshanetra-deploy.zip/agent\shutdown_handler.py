import ctypes
import ctypes.wintypes
import threading
import time
from typing import Callable, List

from .logging_setup import get_logger

logger = get_logger("service")

_handlers: List[Callable] = []
_shutdown_in_progress = False

PHANDLER_ROUTINE = ctypes.WINFUNCTYPE(None, ctypes.wintypes.DWORD)


def _console_ctrl_handler(dwCtrlType: int) -> int:
    global _shutdown_in_progress
    if _shutdown_in_progress:
        return 1
    _shutdown_in_progress = True

    logger.warning("Shutdown signal received (type=%d)", dwCtrlType)
    _execute_handlers()
    return 1


def register_shutdown_handler(handler: Callable):
    if handler not in _handlers:
        _handlers.append(handler)
        logger.debug("Registered shutdown handler: %s", getattr(handler, "__name__", str(handler)))


def unregister_shutdown_handler(handler: Callable):
    if handler in _handlers:
        _handlers.remove(handler)


def _execute_handlers():
    for handler in reversed(_handlers):
        try:
            handler()
        except Exception as e:
            logger.error("Shutdown handler error: %s", e)


def install_console_handler():
    kernel32 = ctypes.windll.kernel32
    handler_func = PHANDLER_ROUTINE(_console_ctrl_handler)
    result = kernel32.SetConsoleCtrlHandler(handler_func, True)
    if result:
        logger.debug("Console control handler installed")
    else:
        logger.warning("Failed to install console control handler (error %d)", kernel32.GetLastError())


def wait_for_shutdown(timeout: float = None):
    if timeout:
        time.sleep(timeout)
    else:
        while True:
            time.sleep(1)
