import sys
import os
import random
import time
import pandas as pd

# Add parent directory to path to import backend.db
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
from backend.db import insert_behavior, init_db

def generate_data(num_records=600):
    init_db()
    
    apps = ["Visual Studio Code", "Chrome", "Slack", "Termainal", "Spotify"]
    
    print(f"Generating {num_records} behavioral records...")
    
    for i in range(num_records):
        data = {
            "typing_speed": random.uniform(40, 70),
            "key_latency": random.uniform(0.08, 0.15),
            "avg_hold_time": random.uniform(0.05, 0.12),
            "latency_jitter": random.uniform(0.01, 0.05),
            "mouse_speed": random.uniform(200, 500),
            "mouse_acceleration": random.uniform(10, 50),
            "direction_change_freq": random.randint(1, 10),
            "click_frequency": random.uniform(0.5, 2.0),
            "active_app": random.choice(apps),
            "app_switch_count": random.randint(0, 3),
            "idle_time": random.uniform(0, 10),
            "time_of_day": random.randint(0, 23),
            "user_id": "default_user",
            "ip_address": "127.0.0.1",
            "city": "Cyber City",
            "country": "Digital Land",
            "is_new_location": False
        }
        insert_behavior(data)
        
    print("Data generation complete.")

if __name__ == "__main__":
    generate_data()
