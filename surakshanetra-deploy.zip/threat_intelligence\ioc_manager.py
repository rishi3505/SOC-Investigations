"""
IOC Database Manager — CRUD operations for indicator storage and lifecycle management.
"""
import json
import os
import sqlite3
import time
import uuid
from typing import Optional


IOC_DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ioc_store.db")

IOC_TYPES = frozenset({
    "IP", "DOMAIN", "URL", "SHA256", "MD5", "PROCESS_NAME",
    "REGISTRY_KEY", "SCHEDULED_TASK", "SERVICE_NAME", "USER_AGENT",
    "EMAIL", "MUTEX", "NAMED_PIPE",
})

VALID_SEVERITIES = frozenset({"LOW", "MEDIUM", "HIGH", "CRITICAL"})
VALID_CONFIDENCE = frozenset({"LOW", "MEDIUM", "HIGH", "VERY_HIGH"})


def _get_conn() -> sqlite3.Connection:
    conn = sqlite3.connect(IOC_DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    return conn


def init_ioc_db():
    conn = _get_conn()
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS iocs (
            id TEXT PRIMARY KEY,
            type TEXT NOT NULL CHECK(type IN ('IP','DOMAIN','URL','SHA256','MD5','PROCESS_NAME',
                'REGISTRY_KEY','SCHEDULED_TASK','SERVICE_NAME','USER_AGENT','EMAIL','MUTEX','NAMED_PIPE')),
            value TEXT NOT NULL UNIQUE,
            threat_family TEXT DEFAULT 'UNKNOWN',
            severity TEXT DEFAULT 'MEDIUM' CHECK(severity IN ('LOW','MEDIUM','HIGH','CRITICAL')),
            confidence TEXT DEFAULT 'MEDIUM' CHECK(confidence IN ('LOW','MEDIUM','HIGH','VERY_HIGH')),
            source TEXT DEFAULT 'manual',
            description TEXT DEFAULT '',
            mitre_technique_id TEXT DEFAULT '',
            mitre_technique_name TEXT DEFAULT '',
            mitre_tactic TEXT DEFAULT '',
            first_seen INTEGER NOT NULL,
            last_updated INTEGER NOT NULL,
            expiration INTEGER,
            active INTEGER DEFAULT 1,
            tags TEXT DEFAULT '[]',
            reference_url TEXT DEFAULT ''
        );
        CREATE INDEX IF NOT EXISTS idx_iocs_type ON iocs(type);
        CREATE INDEX IF NOT EXISTS idx_iocs_value ON iocs(value);
        CREATE INDEX IF NOT EXISTS idx_iocs_active ON iocs(active);
        CREATE INDEX IF NOT EXISTS idx_iocs_severity ON iocs(severity);
    """)
    conn.commit()
    conn.close()


def add_ioc(
    ioc_type: str,
    value: str,
    threat_family: str = "UNKNOWN",
    severity: str = "MEDIUM",
    confidence: str = "MEDIUM",
    source: str = "manual",
    description: str = "",
    mitre_technique_id: str = "",
    mitre_technique_name: str = "",
    mitre_tactic: str = "",
    expiration: Optional[int] = None,
    tags: Optional[list] = None,
    reference_url: str = "",
) -> str:
    ioc_type = ioc_type.upper()
    severity = severity.upper()
    confidence = confidence.upper().replace(" ", "_")
    if ioc_type not in IOC_TYPES:
        raise ValueError(f"Invalid IOC type: {ioc_type}. Must be one of {sorted(IOC_TYPES)}")
    if severity not in VALID_SEVERITIES:
        raise ValueError(f"Invalid severity: {severity}")
    if confidence not in VALID_CONFIDENCE:
        raise ValueError(f"Invalid confidence: {confidence}")

    now = int(time.time())
    ioc_id = f"IOC-{uuid.uuid4().hex[:8].upper()}-{now}"
    conn = _get_conn()
    try:
        conn.execute("""
            INSERT INTO iocs (id, type, value, threat_family, severity, confidence, source,
                description, mitre_technique_id, mitre_technique_name, mitre_tactic,
                first_seen, last_updated, expiration, tags, reference_url)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (ioc_id, ioc_type, value, threat_family, severity, confidence, source,
              description, mitre_technique_id, mitre_technique_name, mitre_tactic,
              now, now, expiration, json.dumps(tags or []), reference_url))
        conn.commit()
        return ioc_id
    except sqlite3.IntegrityError:
        cursor = conn.execute("SELECT id, last_updated FROM iocs WHERE value = ?", (value,))
        existing = cursor.fetchone()
        if existing:
            conn.execute("""
                UPDATE iocs SET last_updated=?, threat_family=?, severity=?, confidence=?,
                    source=?, description=?, mitre_technique_id=?, mitre_technique_name=?,
                    mitre_tactic=?, expiration=?, tags=?, reference_url=?, active=1
                WHERE value=?
            """, (now, threat_family, severity, confidence, source, description,
                  mitre_technique_id, mitre_technique_name, mitre_tactic,
                  expiration, json.dumps(tags or []), reference_url, value))
            conn.commit()
            return existing["id"]
        raise
    finally:
        conn.close()


def bulk_add_iocs(iocs: list[dict]) -> int:
    count = 0
    for ioc in iocs:
        try:
            add_ioc(**ioc)
            count += 1
        except (ValueError, sqlite3.IntegrityError):
            continue
    return count


def search_iocs(
    search: str = "",
    ioc_type: Optional[str] = None,
    severity: Optional[str] = None,
    active_only: bool = True,
    page: int = 1,
    limit: int = 50,
) -> dict:
    conn = _get_conn()
    conditions = []
    params = []
    if active_only:
        conditions.append("active = 1")
    if ioc_type:
        conditions.append("type = ?")
        params.append(ioc_type.upper())
    if severity:
        conditions.append("severity = ?")
        params.append(severity.upper())
    if search:
        conditions.append("(value LIKE ? OR threat_family LIKE ? OR description LIKE ? OR mitre_technique_id LIKE ?)")
        s = f"%{search}%"
        params.extend([s, s, s, s])
    where = "WHERE " + " AND ".join(conditions) if conditions else ""
    offset = (page - 1) * limit
    total = conn.execute("SELECT COUNT(*) FROM iocs " + where, params).fetchone()[0]
    rows = conn.execute(
        f"SELECT * FROM iocs {where} ORDER BY last_updated DESC LIMIT ? OFFSET ?",
        (*params, limit, offset)
    ).fetchall()
    conn.close()
    return {"iocs": [dict(r) for r in rows], "total": total, "page": page, "limit": limit}


def get_ioc_by_id(ioc_id: str) -> Optional[dict]:
    conn = _get_conn()
    row = conn.execute("SELECT * FROM iocs WHERE id = ?", (ioc_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def get_ioc_by_value(value: str) -> Optional[dict]:
    conn = _get_conn()
    row = conn.execute("SELECT * FROM iocs WHERE value = ? AND active = 1", (value,)).fetchone()
    conn.close()
    return dict(row) if row else None


def update_ioc(ioc_id: str, **kwargs) -> bool:
    allowed = {"threat_family", "severity", "confidence", "description",
               "mitre_technique_id", "mitre_technique_name", "mitre_tactic",
               "expiration", "tags", "reference_url", "active"}
    updates = {k: v for k, v in kwargs.items() if k in allowed}
    if not updates:
        return False
    updates["last_updated"] = int(time.time())
    set_clause = ", ".join(f"{k} = ?" for k in updates)
    conn = _get_conn()
    conn.execute(f"UPDATE iocs SET {set_clause} WHERE id = ?", (*updates.values(), ioc_id))
    conn.commit()
    conn.close()
    return True


def deactivate_expired_iocs() -> int:
    now = int(time.time())
    conn = _get_conn()
    cursor = conn.execute("UPDATE iocs SET active = 0, last_updated = ? WHERE expiration IS NOT NULL AND expiration < ? AND active = 1", (now, now))
    count = cursor.rowcount
    conn.commit()
    conn.close()
    return count


def get_ioc_stats() -> dict:
    conn = _get_conn()
    total = conn.execute("SELECT COUNT(*) FROM iocs WHERE active = 1").fetchone()[0]
    by_type = dict(conn.execute(
        "SELECT type, COUNT(*) as cnt FROM iocs WHERE active = 1 GROUP BY type ORDER BY cnt DESC"
    ).fetchall())
    by_severity = dict(conn.execute(
        "SELECT severity, COUNT(*) as cnt FROM iocs WHERE active = 1 GROUP BY severity ORDER BY cnt DESC"
    ).fetchall())
    by_source = dict(conn.execute(
        "SELECT COALESCE(NULLIF(source,''),'manual') as src, COUNT(*) as cnt FROM iocs WHERE active = 1 GROUP BY src ORDER BY cnt DESC"
    ).fetchall())
    expired = conn.execute("SELECT COUNT(*) FROM iocs WHERE active = 0").fetchone()[0]
    top_families = [dict(r) for r in conn.execute(
        "SELECT threat_family, COUNT(*) as cnt FROM iocs WHERE active = 1 AND threat_family != 'UNKNOWN' GROUP BY threat_family ORDER BY cnt DESC LIMIT 10"
    ).fetchall()]
    conn.close()
    return {
        "total_active": total,
        "expired": expired,
        "by_type": by_type,
        "by_severity": by_severity,
        "by_source": by_source,
        "top_threat_families": top_families,
    }
