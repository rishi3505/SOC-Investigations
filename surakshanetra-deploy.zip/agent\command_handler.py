"""
Command Handler — Polls CMS for pending remote commands, executes them locally,
and reports acknowledgment/completion.
"""
import json
import threading
import time
from typing import Callable, Optional

import requests

from .logging_setup import get_logger

logger = get_logger("communication")


COMMAND_HANDLERS = {}


def register_handler(command_type: str, handler: Callable):
    COMMAND_HANDLERS[command_type] = handler


def get_handler(command_type: str) -> Optional[Callable]:
    return COMMAND_HANDLERS.get(command_type)


class CommandPoller:
    def __init__(self, cms_url: str, device_id: str, poll_interval: float = 30.0):
        self._cms_url = cms_url.rstrip("/")
        self._device_id = device_id
        self._poll_interval = poll_interval
        self._thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()

    def start(self):
        if self._thread and self._thread.is_alive():
            return
        self._stop_event.clear()
        self._thread = threading.Thread(target=self._run, name="cmd-poller", daemon=True)
        self._thread.start()
        logger.info("Command poller started (interval=%ds)", self._poll_interval)

    def stop(self):
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=5)
        logger.info("Command poller stopped")

    def _run(self):
        while not self._stop_event.wait(self._poll_interval):
            try:
                self._poll_and_execute()
            except Exception as e:
                logger.error("Command poll error: %s", e)

    def _poll_and_execute(self):
        resp = requests.post(
            f"{self._cms_url}/api/v1/commands/agent/poll",
            json={"endpoint_id": self._device_id},
            timeout=10,
        )
        if resp.status_code != 200:
            return
        data = resp.json()
        for cmd in data.get("commands", []):
            self._execute_command(cmd)

    def _execute_command(self, cmd: dict):
        cmd_id = cmd["id"]
        cmd_type = cmd["command_type"]
        payload = json.loads(cmd.get("payload", "{}"))
        logger.info("Executing command: %s (%s)", cmd_id, cmd_type)

        requests.post(
            f"{self._cms_url}/api/v1/commands/agent/acknowledge",
            json={"command_id": cmd_id, "endpoint_id": self._device_id},
            timeout=10,
        )

        handler = get_handler(cmd_type)
        success = False
        output = {"error": "No handler registered"}
        if handler:
            try:
                result = handler(self._device_id, payload)
                success = result.get("success", True)
                output = result
            except Exception as e:
                output = {"error": str(e)}
                logger.error("Command %s failed: %s", cmd_id, e)
        else:
            logger.warning("No handler for command type: %s", cmd_type)

        requests.post(
            f"{self._cms_url}/api/v1/commands/agent/complete",
            json={
                "command_id": cmd_id,
                "endpoint_id": self._device_id,
                "success": success,
                "output": output,
            },
            timeout=10,
        )
        logger.info("Command %s completed (success=%s)", cmd_id, success)
