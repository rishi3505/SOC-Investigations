import json
import os
import threading
import time
from collections import deque, Counter
from typing import Optional

import requests

from .logging_setup import setup_logging, get_logger, reconfigure_logging
from .version import get_version_info, get_device_id
from .backend_queue import enqueue, flush, get_queue_stats, cleanup_old_entries
from .health_monitor import HealthMonitor
from .heartbeat import HeartbeatSender
from .single_instance import try_acquire, release as release_mutex
from .shutdown_handler import register_shutdown_handler, install_console_handler

_CONFIG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config.json")

logger = get_logger("agent")


class BackgroundAgent:
    def __init__(self):
        self._config = self._load_config()
        self._running = False
        self._stop_event = threading.Event()

        self._collector_thread: Optional[threading.Thread] = None
        self._heartbeat: Optional[HeartbeatSender] = None
        self._health_monitor: Optional[HealthMonitor] = None
        self._queue_flush_thread: Optional[threading.Thread] = None

        self._kb_monitor = None
        self._mouse_monitor = None
        self._sys_monitor = None
        self._loc_tracker = None
        self._device_fp = None

    @staticmethod
    def _deep_merge(base: dict, override: dict) -> dict:
        result = base.copy()
        for key, val in override.items():
            if key in result and isinstance(result[key], dict) and isinstance(val, dict):
                result[key] = {**result[key], **val}
            else:
                result[key] = val
        return result

    def _load_config(self) -> dict:
        default = {
            "backend": {"url": "http://localhost:8000", "heartbeat_interval_seconds": 60, "retry_interval_seconds": 30, "connection_timeout_seconds": 5, "max_queue_size": 10000},
            "sampling": {"interval_seconds": 2, "sliding_window_size": 5, "idle_interval_seconds": 5, "idle_threshold_seconds": 10, "aggregation_interval_seconds": 5},
            "logging": {"level": "INFO", "directory": "logs", "max_file_size_mb": 10, "backup_count": 5},
            "health": {"check_interval_seconds": 15, "max_consecutive_failures": 3, "restart_delay_seconds": 2},
            "offline": {"enabled": True, "sync_batch_size": 50, "max_buffer_size": 5000, "max_retry_count": 10},
            "monitoring": {"enabled": True, "keyboard": True, "mouse": True, "system": True, "location": True, "device_fingerprint": True},
            "resource_limits": {"max_cpu_percent": 2.0, "max_memory_mb": 100, "min_collector_idle_sleep_ms": 500},
        }
        if os.path.exists(_CONFIG_PATH):
            try:
                with open(_CONFIG_PATH, "r", encoding="utf-8") as f:
                    loaded = json.load(f)
                    return self._deep_merge(default, loaded)
            except (json.JSONDecodeError, OSError) as e:
                logger.error("Failed to load config: %s. Using defaults.", e)
        return default

    def _save_config(self):
        os.makedirs(os.path.dirname(_CONFIG_PATH), exist_ok=True)
        with open(_CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(self._config, f, indent=4)

    def reload_config(self):
        self._config = self._load_config()
        reconfigure_logging(self._config)
        logger.info("Configuration reloaded")

    def _get_backend_url(self) -> str:
        return self._config.get("backend", {}).get("url", "http://localhost:8000").rstrip("/")

    def _get_interval(self) -> int:
        return int(self._config.get("sampling", {}).get("interval_seconds", 2))

    def _get_idle_interval(self) -> int:
        return int(self._config.get("sampling", {}).get("idle_interval_seconds", 5))

    def _get_idle_threshold(self) -> int:
        return int(self._config.get("sampling", {}).get("idle_threshold_seconds", 10))

    def _get_window_size(self) -> int:
        return int(self._config.get("sampling", {}).get("sliding_window_size", 5))

    def _get_aggregation_interval(self) -> int:
        return int(self._config.get("sampling", {}).get("aggregation_interval_seconds", 5))

    def start(self):
        if self._running:
            logger.warning("Agent is already running")
            return

        setup_logging(self._config)
        logger.info("=" * 60)
        logger.info("SurakshaNetra Agent starting...")
        logger.info("Version: %s | Device: %s", get_version_info()["agent_version"], get_device_id())
        logger.info("=" * 60)

        self._stop_event.clear()
        self._start_time = time.time()

        self._start_collector()
        self._start_health_monitor()
        self._start_heartbeat()
        self._start_queue_flusher()

        self._running = True
        logger.info("Agent started successfully")

    def stop(self):
        logger.info("Agent shutting down...")
        self._stop_event.set()
        self._running = False

        if self._health_monitor:
            self._health_monitor.stop()

        if self._heartbeat:
            self._heartbeat.stop()

        self._stop_monitors()

        self._flush_queue()
        logger.info("Agent shutdown complete")

    def _start_collector(self):
        if self._collector_thread and self._collector_thread.is_alive():
            return

        self._stop_monitors()

        from .keyboard import KeyboardMonitor
        from .mouse_tracker import MouseMonitor
        from .system_monitor import SystemMonitor
        from .location_utils import LocationTracker
        from .device_fingerprint import get_device_fingerprint

        self._kb_monitor = KeyboardMonitor()
        self._mouse_monitor = MouseMonitor()
        self._sys_monitor = SystemMonitor()
        self._loc_tracker = LocationTracker()
        self._device_fp = get_device_fingerprint(cache=True)

        self._kb_monitor.start()
        self._mouse_monitor.start()

        self._collector_thread = threading.Thread(target=self._collector_loop, name="collector", daemon=True)
        self._collector_thread.start()
        logger.info("Collector thread started")

    def _stop_monitors(self):
        if self._kb_monitor:
            try:
                self._kb_monitor.stop()
            except Exception:
                pass
            self._kb_monitor = None
        if self._mouse_monitor:
            try:
                self._mouse_monitor.stop()
            except Exception:
                pass
            self._mouse_monitor = None

    def _collector_loop(self):
        window = deque()
        last_agg_time = time.time()
        backend_url = self._get_backend_url()
        device_fp = self._device_fp or {}

        while not self._stop_event.is_set():
            try:
                current_time = time.time()
                kb_metrics = self._kb_monitor.get_metrics_and_reset()
                mouse_metrics = self._mouse_monitor.get_metrics_and_reset()
                sys_metrics = self._sys_monitor.get_metrics_and_reset()

                last_activity = max(kb_metrics["last_activity"], mouse_metrics["last_activity"])
                idle_time = max(0.0, current_time - last_activity)

                active_interval = self._get_interval()
                if idle_time > self._get_idle_threshold():
                    active_interval = self._get_idle_interval()

                typing_speed = kb_metrics["press_count"] / float(active_interval) if active_interval > 0 else 0
                mouse_speed = mouse_metrics["mouse_distance"] / float(active_interval) if active_interval > 0 else 0
                click_frequency = mouse_metrics["click_count"] / float(active_interval) if active_interval > 0 else 0

                loc_info = self._loc_tracker.get_location()

                if not hasattr(self._collector_loop, "_sma_buffer"):
                    self._collector_loop._sma_buffer = deque(maxlen=3)

                m_accel = min(50.0, mouse_metrics["mouse_acceleration"])
                m_dfreq = mouse_metrics["direction_change_freq"]

                if m_accel < 0.01:
                    m_accel = 0.0
                if m_dfreq < 0.01:
                    m_dfreq = 0.0

                self._collector_loop._sma_buffer.append({
                    "mouse_acceleration": m_accel,
                    "direction_change_freq": m_dfreq,
                    "latency_jitter": kb_metrics["latency_jitter"]
                })

                def get_sma(key):
                    vals = [d[key] for d in self._collector_loop._sma_buffer]
                    return sum(vals) / len(vals) if vals else 0.0

                raw_data = {
                    "typing_speed": typing_speed,
                    "key_latency": kb_metrics["avg_key_latency"],
                    "avg_hold_time": kb_metrics["avg_hold_time"],
                    "latency_jitter": get_sma("latency_jitter"),
                    "mouse_speed": min(1000.0, mouse_speed),
                    "mouse_acceleration": get_sma("mouse_acceleration"),
                    "direction_change_freq": get_sma("direction_change_freq"),
                    "click_frequency": click_frequency,
                    "active_app": sys_metrics["active_app"],
                    "app_switch_count": sys_metrics["app_switch_count"],
                    "idle_time": idle_time,
                    "time_of_day": sys_metrics["time_of_day"],
                    "session_duration": round(sys_metrics["session_duration"], 2),
                    **loc_info
                }

                window.append(raw_data)
                if len(window) > self._get_window_size():
                    window.popleft()

                if current_time - last_agg_time >= self._get_aggregation_interval():
                    if len(window) >= (self._get_window_size() // 2):
                        aggregated = self._aggregate_data(window)
                        payload = {
                            **aggregated,
                            "user_id": "default_user",
                            "device_hash": device_fp.get("fingerprint", ""),
                            "device_hostname": device_fp.get("hostname", ""),
                            "device_os_version": device_fp.get("os_version", ""),
                            "device_windows_build": device_fp.get("windows_build", ""),
                            "device_architecture": device_fp.get("system_architecture", "")
                        }
                        self._send_or_queue(payload, backend_url)
                        window.clear()
                        last_agg_time = current_time

                sleep_time = max(0.1, active_interval)
                self._stop_event.wait(sleep_time)

            except Exception as e:
                logger.error("Collector loop error: %s", e)
                self._stop_event.wait(2)

    def _aggregate_data(self, window):
        def mean(lst):
            return sum(lst) / len(lst) if lst else 0.0

        latencies = [d["key_latency"] for d in window if d["key_latency"] > 0]
        holds = [d["avg_hold_time"] for d in window if d["avg_hold_time"] > 0]
        apps = [d["active_app"] for d in window]
        most_common_app = Counter(apps).most_common(1)[0][0] if apps else "Unknown"
        latest = window[-1]

        return {
            "typing_speed": round(mean([d["typing_speed"] for d in window]), 4),
            "key_latency": round(mean(latencies), 4),
            "avg_hold_time": round(mean(holds), 4),
            "latency_jitter": round(mean([d["latency_jitter"] for d in window if d["latency_jitter"] > 0]), 4),
            "mouse_speed": round(mean([d["mouse_speed"] for d in window]), 4),
            "mouse_acceleration": round(mean([d["mouse_acceleration"] for d in window]), 4),
            "direction_change_freq": round(sum(d["direction_change_freq"] for d in window), 4),
            "click_frequency": round(mean([d["click_frequency"] for d in window]), 4),
            "active_app": most_common_app,
            "app_switch_count": sum(d["app_switch_count"] for d in window),
            "idle_time": latest["idle_time"],
            "time_of_day": latest["time_of_day"],
            "session_duration": latest["session_duration"],
            "ip_address": latest.get("ip_address", "Unknown"),
            "city": latest.get("city", "Unknown"),
            "country": latest.get("country", "Unknown"),
            "is_new_location": latest.get("is_new_location", False)
        }

    def _send_or_queue(self, payload: dict, backend_url: str):
        try:
            resp = requests.post(
                f"{backend_url}/api/v1/analyze",
                json=payload,
                timeout=5
            )
            if resp.status_code == 200:
                logger.debug("Payload sent successfully")
            else:
                logger.warning("Backend returned HTTP %d, queuing", resp.status_code)
                if self._config.get("offline", {}).get("enabled", True):
                    enqueue(payload)
        except requests.ConnectionError:
            logger.debug("Backend unreachable, queuing payload")
            if self._config.get("offline", {}).get("enabled", True):
                enqueue(payload)
        except Exception as e:
            logger.error("Failed to send payload: %s. Queuing.", e)
            if self._config.get("offline", {}).get("enabled", True):
                enqueue(payload)

    def _start_health_monitor(self):
        self._health_monitor = HealthMonitor(
            check_interval=self._config.get("health", {}).get("check_interval_seconds", 15),
            max_consecutive_failures=self._config.get("health", {}).get("max_consecutive_failures", 3),
            restart_delay=self._config.get("health", {}).get("restart_delay_seconds", 2)
        )

        self._health_monitor.register_module(
            "collector",
            alive_checker=lambda: self._collector_thread is not None and self._collector_thread.is_alive(),
            restart_callback=self._start_collector
        )

        self._health_monitor.start()
        logger.info("Health monitor started")

    def _start_heartbeat(self):
        self._heartbeat = HeartbeatSender(
            backend_url=self._get_backend_url(),
            interval=float(self._config.get("backend", {}).get("heartbeat_interval_seconds", 60))
        )
        self._heartbeat.start()

    def _start_queue_flusher(self):
        self._queue_flush_thread = threading.Thread(target=self._queue_flush_loop, name="queue-flusher", daemon=True)
        self._queue_flush_thread.start()

    def _queue_flush_loop(self):
        while not self._stop_event.is_set():
            try:
                if self._config.get("offline", {}).get("enabled", True):
                    batch_size = int(self._config.get("offline", {}).get("sync_batch_size", 50))
                    timeout = int(self._config.get("backend", {}).get("connection_timeout_seconds", 5))
                    sent, failed = flush(self._get_backend_url(), batch_size=batch_size, timeout=timeout)
                    if sent > 0:
                        logger.info("Queue flush: %d sent, %d failed", sent, failed)
                    cleanup_old_entries(older_than_hours=24)
            except Exception as e:
                logger.error("Queue flush error: %s", e)

            self._stop_event.wait(30)

    def _flush_queue(self):
        try:
            sent, failed = flush(self._get_backend_url(), batch_size=200, timeout=10)
            if sent > 0 or failed > 0:
                logger.info("Final queue flush: %d sent, %d failed", sent, failed)
        except Exception as e:
            logger.error("Final queue flush error: %s", e)

    def get_status(self) -> dict:
        queue_stats = {}
        try:
            queue_stats = get_queue_stats()
        except Exception:
            pass

        health = {}
        if self._health_monitor:
            health = self._health_monitor.get_all_module_states()

        return {
            "running": self._running,
            "device_id": get_device_id(),
            "version": get_version_info(),
            "queue": queue_stats,
            "health": health,
            "backend_url": self._get_backend_url(),
            "uptime_seconds": int(time.time() - self._start_time) if hasattr(self, "_start_time") else 0
        }

    def is_running(self) -> bool:
        return self._running


_agent_instance: Optional[BackgroundAgent] = None


def get_agent() -> BackgroundAgent:
    global _agent_instance
    if _agent_instance is None:
        _agent_instance = BackgroundAgent()
    return _agent_instance


def start_agent():
    if not try_acquire():
        logger.error("Cannot start: another instance is running")
        return False

    agent = get_agent()
    agent.start()
    return True


def stop_agent():
    agent = get_agent()
    agent.stop()
    release_mutex()
