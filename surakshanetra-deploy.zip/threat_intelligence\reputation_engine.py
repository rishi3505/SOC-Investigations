"""
Reputation Engine — Assigns reputation scores to observed artifacts
by combining IOC matches, behavioral data, device trust, and location trust.
"""
import time
from typing import Optional

from threat_intelligence.ioc_manager import get_ioc_by_value

REPUTATION_LEVELS = {
    "KNOWN_SAFE": 0, "LIKELY_SAFE": 1, "UNKNOWN": 2,
    "SUSPICIOUS": 3, "MALICIOUS": 4, "KNOWN_MALICIOUS": 5,
}
REPUTATION_LABELS = {v: k for k, v in REPUTATION_LEVELS.items()}


class ReputationEngine:
    def __init__(self, cache_size: int = 10000):
        self._cache: dict[str, dict] = {}
        self._cache_size = cache_size

    def _cached_or_lookup(self, artifact: str, artifact_type: str = "IP") -> Optional[dict]:
        key = f"{artifact_type}:{artifact}"
        cached = self._cache.get(key)
        if cached and cached.get("_cached_at", 0) > time.time() - 300:
            return cached
        ioc = get_ioc_by_value(artifact)
        if ioc:
            result = {
                "ioc_id": ioc["id"], "type": ioc["type"], "value": ioc["value"],
                "threat_family": ioc["threat_family"], "severity": ioc["severity"],
                "confidence": ioc["confidence"], "source": ioc["source"],
                "mitre_technique_id": ioc["mitre_technique_id"],
                "mitre_technique_name": ioc["mitre_technique_name"],
                "mitre_tactic": ioc["mitre_tactic"],
                "_cached_at": time.time(),
            }
        else:
            result = None
        if len(self._cache) > self._cache_size:
            self._cache.clear()
        self._cache[key] = result
        return result

    def get_reputation(self, artifact: str, artifact_type: str = "IP") -> dict:
        match = self._cached_or_lookup(artifact, artifact_type)
        if not match:
            return {"artifact": artifact, "artifact_type": artifact_type,
                    "reputation": "UNKNOWN", "reputation_score": REPUTATION_LEVELS["UNKNOWN"],
                    "source": "no_match", "details": {}}
        severity_score = {"LOW": 3, "MEDIUM": 4, "HIGH": 5, "CRITICAL": 6}
        confidence_score = {"LOW": 0.5, "MEDIUM": 0.7, "HIGH": 0.9, "VERY_HIGH": 1.0}
        base = severity_score.get(match["severity"], 3)
        conf = confidence_score.get(match["confidence"], 0.7)
        rep_score = min(5, round(base * conf))
        rep_label = REPUTATION_LABELS.get(rep_score, "UNKNOWN")
        return {
            "artifact": artifact, "artifact_type": artifact_type,
            "reputation": rep_label, "reputation_score": rep_score,
            "source": match["source"], "threat_family": match["threat_family"],
            "mitre_technique_id": match["mitre_technique_id"],
            "mitre_technique_name": match["mitre_technique_name"],
            "mitre_tactic": match["mitre_tactic"],
            "details": {"ioc_id": match["ioc_id"], "ioc_severity": match["severity"],
                        "ioc_confidence": match["confidence"], "calculated_score": rep_score},
        }

    def bulk_reputation(self, artifacts: list[tuple[str, str]]) -> list[dict]:
        return [self.get_reputation(artifact, atype) for artifact, atype in artifacts]

    def clear_cache(self):
        self._cache.clear()


_reputation_engine = ReputationEngine()


def get_reputation_engine() -> ReputationEngine:
    return _reputation_engine


def get_reputation(artifact: str, artifact_type: str = "IP") -> dict:
    return _reputation_engine.get_reputation(artifact, artifact_type)
