import sqlite3
import os
import time
import pandas as pd

DB_PATH = os.path.join(os.path.dirname(__file__), '..', 'data', 'behavior.db')

def init_db():
    """
    Initializes the SQLite database and creates the behavior_data table if it doesn't exist.
    """
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA journal_mode=WAL")
    cursor = conn.cursor()
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS behavior_data (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            typing_speed REAL,
            key_latency REAL,
            avg_hold_time REAL,
            latency_jitter REAL,
            mouse_speed REAL,
            mouse_acceleration REAL,
            direction_change_freq REAL,
            click_frequency REAL,
            active_app TEXT,
            app_switch_count INTEGER,
            idle_time REAL,
            time_of_day INTEGER,
            session_duration REAL,
            user_id TEXT,
            ip_address TEXT,
            city TEXT,
            country TEXT,
            is_new_location BOOLEAN,
            timestamp INTEGER
        )
    ''')

    # Migration for existing databases
    cursor.execute("PRAGMA table_info(behavior_data)")
    existing_columns = [col[1] for col in cursor.fetchall()]
    new_columns = [
        ("latency_jitter", "REAL"),
        ("mouse_acceleration", "REAL"),
        ("direction_change_freq", "REAL"),
        ("ip_address", "TEXT"),
        ("city", "TEXT"),
        ("country", "TEXT"),
        ("is_new_location", "BOOLEAN")
    ]
    for col_name, col_type in new_columns:
        if col_name not in existing_columns:
            cursor.execute(f"ALTER TABLE behavior_data ADD COLUMN {col_name} {col_type}")
            print(f"Added column {col_name} to behavior_data.")

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS user_profiles (
            user_id TEXT PRIMARY KEY,
            samples_collected INTEGER DEFAULT 0,
            low_threshold REAL DEFAULT 30.0,
            med_threshold REAL DEFAULT 60.0,
            high_threshold REAL DEFAULT 85.0
        )
    ''')

    # Migration for samples_collected
    cursor.execute("PRAGMA table_info(user_profiles)")
    if 'samples_collected' not in [col[1] for col in cursor.fetchall()]:
        cursor.execute("ALTER TABLE user_profiles ADD COLUMN samples_collected INTEGER DEFAULT 0")

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS session_risk_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT,
            risk_score REAL,
            is_anomalous BOOLEAN,
            timestamp INTEGER
        )
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS trusted_sessions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT,
            start_time INTEGER,
            expiry_time INTEGER
        )
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS feedback_data (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            behavior_id INTEGER,
            label TEXT,
            timestamp INTEGER,
            FOREIGN KEY(behavior_id) REFERENCES behavior_data(id)
        )
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS trusted_locations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT,
            city TEXT,
            country TEXT,
            ip_address TEXT,
            trust_score INTEGER DEFAULT 0,
            last_seen INTEGER,
            UNIQUE(user_id, city, country)
        )
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS agent_heartbeats (
            device_id TEXT PRIMARY KEY,
            hostname TEXT,
            agent_version TEXT,
            build_number INTEGER DEFAULT 0,
            status TEXT DEFAULT 'OFFLINE',
            memory_usage_mb REAL DEFAULT 0,
            cpu_usage_percent REAL DEFAULT 0,
            current_user TEXT,
            last_seen INTEGER,
            install_date TEXT,
            last_update TEXT
        )
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS trusted_devices (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            device_hash TEXT UNIQUE,
            hostname TEXT,
            os_version TEXT,
            windows_build TEXT,
            first_seen INTEGER,
            last_seen INTEGER,
            trusted INTEGER DEFAULT 0,
            trust_status TEXT DEFAULT 'PENDING_TRUST',
            notes TEXT,
            user_id TEXT
        )
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS device_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            device_hash TEXT,
            timestamp INTEGER,
            event_type TEXT,
            details TEXT
        )
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS incidents (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            incident_id TEXT UNIQUE,
            user_id TEXT,
            session_id TEXT,
            timestamp INTEGER,
            risk_score REAL,
            confidence REAL,
            evidence_score REAL,
            severity TEXT,
            status TEXT DEFAULT 'OPEN',
            mitre_technique TEXT,
            mitre_technique_name TEXT,
            mitre_tactic TEXT,
            recommended_action TEXT,
            reason_json TEXT,
            response_level INTEGER DEFAULT 0,
            system_state TEXT DEFAULT 'NORMAL',
            resolved_at INTEGER,
            resolution_notes TEXT
        )
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS response_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT,
            session_id TEXT,
            timestamp INTEGER,
            risk_score REAL,
            confidence REAL,
            evidence_score REAL,
            action_taken TEXT,
            response_level INTEGER,
            system_state TEXT,
            policy_id TEXT,
            incident_id TEXT,
            reasoning TEXT
        )
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS policy_audit (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp INTEGER,
            policy_id TEXT,
            policy_name TEXT,
            user_id TEXT,
            risk_score REAL,
            confidence REAL,
            matched BOOLEAN,
            action_taken TEXT,
            details TEXT
        )
    ''')

    cursor.execute("PRAGMA table_info(incidents)")
    inc_cols = [col[1] for col in cursor.fetchall()]
    inc_additions = [
        ("response_level", "INTEGER DEFAULT 0"),
        ("system_state", "TEXT DEFAULT 'NORMAL'"),
        ("mitre_technique_name", "TEXT"),
        ("mitre_tactic", "TEXT"),
    ]
    for col_name, col_type in inc_additions:
        if col_name not in inc_cols:
            cursor.execute(f"ALTER TABLE incidents ADD COLUMN {col_name} {col_type}")

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS containment_actions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            incident_id TEXT,
            action TEXT,
            status TEXT DEFAULT 'PENDING',
            details TEXT,
            timestamp INTEGER,
            completed_at INTEGER,
            reverted_at INTEGER,
            collected_at INTEGER,
            FOREIGN KEY(incident_id) REFERENCES incidents(incident_id)
        )
    ''')

    cursor.execute("PRAGMA table_info(containment_actions)")
    ca_cols = [col[1] for col in cursor.fetchall()]
    if "collected_at" not in ca_cols:
        cursor.execute("ALTER TABLE containment_actions ADD COLUMN collected_at INTEGER")

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS evidence_packages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            incident_id TEXT,
            case_id TEXT,
            package_path TEXT,
            hash_manifest TEXT,
            collected_at INTEGER,
            status TEXT DEFAULT 'COLLECTING',
            collector_hostname TEXT,
            chain_of_custody TEXT,
            FOREIGN KEY(incident_id) REFERENCES incidents(incident_id)
        )
    ''')
    
    # Performance indexes
    conn.executescript("""
        CREATE INDEX IF NOT EXISTS idx_behavior_user_ts ON behavior_data(user_id, timestamp DESC);
        CREATE INDEX IF NOT EXISTS idx_behavior_time_of_day ON behavior_data(time_of_day);
        CREATE INDEX IF NOT EXISTS idx_risk_user_ts ON session_risk_history(user_id, timestamp DESC);
        CREATE INDEX IF NOT EXISTS idx_trusted_sessions_user ON trusted_sessions(user_id);
        CREATE INDEX IF NOT EXISTS idx_device_history_hash ON device_history(device_hash, timestamp DESC);
        CREATE INDEX IF NOT EXISTS idx_incidents_user_status ON incidents(user_id, status);
        CREATE INDEX IF NOT EXISTS idx_incidents_status ON incidents(status);
        CREATE INDEX IF NOT EXISTS idx_response_user_ts ON response_history(user_id, timestamp DESC);
        CREATE INDEX IF NOT EXISTS idx_containment_incident ON containment_actions(incident_id, collected_at DESC);
        CREATE INDEX IF NOT EXISTS idx_evidence_incident ON evidence_packages(incident_id, collected_at DESC);
        CREATE INDEX IF NOT EXISTS idx_feedback_behavior ON feedback_data(behavior_id);
        CREATE INDEX IF NOT EXISTS idx_agent_heartbeat_device ON agent_heartbeats(device_id);
    """)
    conn.commit()
    conn.close()
    print(f"Database initialized at {DB_PATH}")

def insert_behavior(data):
    """
    Inserts a single behavior record into the database.
    :param data: Dictionary containing the behavior metrics.
    """
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    # Ensure timestamp is present
    if 'timestamp' not in data:
        import time
        data['timestamp'] = int(time.time())
        
    columns = ', '.join(data.keys())
    placeholders = ', '.join(['?' for _ in data])
    query = f"INSERT INTO behavior_data ({columns}) VALUES ({placeholders})"
    
    cursor.execute(query, list(data.values()))
    
    conn.commit()
    conn.close()

def fetch_training_data(limit=None):
    """
    Fetches behavior data from the database for training.
    :param limit: Maximum number of records to fetch.
    :return: Pandas DataFrame containing the training data.
    """
    conn = sqlite3.connect(DB_PATH)
    query = "SELECT * FROM behavior_data ORDER BY timestamp DESC LIMIT 1000"
        
    df = pd.read_sql_query(query, conn)
    conn.close()
    
    # Drop the 'id' column as it's not needed for training
    if not df.empty and 'id' in df.columns:
        # Keep id if we need to link feedback later, but for model training we usually drop it.
        # Let's keep it for now and drop in the training script instead.
        pass
        
    return df

def check_trusted_session(user_id):
    """
    Checks if there is an active trusted session for the user.
    """
    import time
    now = int(time.time())
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute(
        "SELECT id FROM trusted_sessions WHERE user_id = ? AND start_time <= ? AND expiry_time >= ?",
        (user_id, now, now)
    )
    result = cursor.fetchone()
    conn.close()
    return result is not None

def get_user_thresholds(user_id):
    """
    Fetches adaptive thresholds for a user.
    """
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute(
        "SELECT low_threshold, med_threshold, high_threshold FROM user_profiles WHERE user_id = ?",
        (user_id,)
    )
    result = cursor.fetchone()
    conn.close()
    
    if result:
        return {
            "low": result[0],
            "med": result[1],
            "high": result[2]
        }
    return {"low": 30.0, "med": 60.0, "high": 85.0} # Default thresholds

def update_user_thresholds(user_id, low, med, high):
    """
    Updates or creates thresholds for a user.
    """
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO user_profiles (user_id, low_threshold, med_threshold, high_threshold)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(user_id) DO UPDATE SET
            low_threshold=excluded.low_threshold,
            med_threshold=excluded.med_threshold,
            high_threshold=excluded.high_threshold
    ''', (user_id, low, med, high))
    conn.commit()
    conn.close()

def insert_feedback(behavior_id, label):
    """
    Stores user feedback for a behavior record.
    """
    import time
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO feedback_data (behavior_id, label, timestamp) VALUES (?, ?, ?)",
        (behavior_id, label, int(time.time()))
    )
    conn.commit()
    conn.close()

def fetch_feedback_labeled_data():
    """
    Fetches data joined with user feedback labels.
    """
    conn = sqlite3.connect(DB_PATH)
    query = """
        SELECT b.*, f.label as feedback_label
        FROM behavior_data b
        JOIN feedback_data f ON b.id = f.behavior_id
    """
    df = pd.read_sql_query(query, conn)
    conn.close()
    return df

def check_location_trust(user_id, city, country):
    """
    Checks if a location is trusted for the user.
    """
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute(
        "SELECT trust_score FROM trusted_locations WHERE user_id = ? AND city = ? AND country = ?",
        (user_id, city, country)
    )
    result = cursor.fetchone()
    conn.close()
    # Consider trusted if it exists and has a positive trust score
    return result is not None and result[0] >= 1

def add_trusted_location(user_id, city, country, ip=None):
    """
    Adds or updates a trusted location.
    """
    import time
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO trusted_locations (user_id, city, country, ip_address, trust_score, last_seen)
        VALUES (?, ?, ?, ?, 1, ?)
        ON CONFLICT(user_id, city, country) DO UPDATE SET
            trust_score = trust_score + 1,
            last_seen = excluded.last_seen
    ''', (user_id, city, country, ip, int(time.time())))
    conn.commit()
    conn.close()

def fetch_time_bucket_means(user_id, hour_bucket):
    """
    Fetches historical feature means for a specific time bucket (4-hour windows).
    """
    conn = sqlite3.connect(DB_PATH)
    # Buckets: 0(0-3), 1(4-7), 2(8-11), 3(12-15), 4(16-19), 5(20-23)
    start_h = hour_bucket * 4
    end_h = start_h + 3
    
    query = f"""
        SELECT 
            AVG(typing_speed) as typing_speed,
            AVG(key_latency) as key_latency,
            AVG(avg_hold_time) as avg_hold_time,
            AVG(mouse_speed) as mouse_speed,
            AVG(click_frequency) as click_frequency
        FROM behavior_data
        WHERE user_id = ? AND time_of_day BETWEEN {start_h} AND {end_h}
    """
    df = pd.read_sql_query(query, conn, params=(user_id,))
    conn.close()
    
    if not df.empty and not df.iloc[0].isnull().all():
        return df.iloc[0].to_dict()
    return None

def get_sample_count(user_id):
    """
    Returns the number of samples collected for a user.
    """
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT samples_collected FROM user_profiles WHERE user_id = ?", (user_id,))
    result = cursor.fetchone()
    conn.close()
    return result[0] if result else 0

def increment_sample_count(user_id):
    """
    Increments the samples_collected count for a user.
    """
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO user_profiles (user_id, samples_collected)
        VALUES (?, 1)
        ON CONFLICT(user_id) DO UPDATE SET samples_collected = samples_collected + 1
    ''', (user_id,))
    conn.commit()
    conn.close()

def add_session_risk(user_id, score, is_anomalous):
    """
    Stores a risk result in session history.
    """
    import time
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO session_risk_history (user_id, risk_score, is_anomalous, timestamp) VALUES (?, ?, ?, ?)",
        (user_id, score, is_anomalous, int(time.time()))
    )
    # Keep only the last 50 samples in history per user to save space
    cursor.execute('''
        DELETE FROM session_risk_history WHERE id NOT IN (
            SELECT id FROM session_risk_history WHERE user_id = ? ORDER BY timestamp DESC LIMIT 50
        ) AND user_id = ?
    ''', (user_id, user_id))
    conn.commit()
    conn.close()

def get_session_history(user_id, limit=20):
    """
    Fetches the rolling risk history for a session.
    """
    conn = sqlite3.connect(DB_PATH)
    # Using id DESC to ensure strict order even if timestamps match within the same second
    query = "SELECT risk_score, is_anomalous FROM session_risk_history WHERE user_id = ? ORDER BY id DESC LIMIT ?"
    df = pd.read_sql_query(query, conn, params=(user_id, limit))
    conn.close()
    return df

def get_user_profiles_all():
    conn = sqlite3.connect(DB_PATH)
    query = "SELECT * FROM user_profiles"
    df = pd.read_sql_query(query, conn)
    conn.close()
    return df

def get_trusted_locations_all():
    conn = sqlite3.connect(DB_PATH)
    query = "SELECT * FROM trusted_locations ORDER BY trust_score DESC"
    df = pd.read_sql_query(query, conn)
    conn.close()
    return df

def get_behavior_by_user(user_id, limit=100):
    conn = sqlite3.connect(DB_PATH)
    query = "SELECT * FROM behavior_data WHERE user_id = ? ORDER BY timestamp DESC LIMIT ?"
    df = pd.read_sql_query(query, conn, params=(user_id, limit))
    conn.close()
    return df

def get_session_history_all(user_id=None, limit=100):
    conn = sqlite3.connect(DB_PATH)
    if user_id:
        query = "SELECT * FROM session_risk_history WHERE user_id = ? ORDER BY timestamp DESC LIMIT ?"
        df = pd.read_sql_query(query, conn, params=(user_id, limit))
    else:
        query = "SELECT * FROM session_risk_history ORDER BY timestamp DESC LIMIT ?"
        df = pd.read_sql_query(query, conn, params=(limit,))
    conn.close()
    return df

def get_total_record_count():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM behavior_data")
    count = cursor.fetchone()[0]
    conn.close()
    return count

def register_device(device_info: dict) -> bool:
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    try:
        cursor.execute('''
            INSERT OR IGNORE INTO trusted_devices (
                device_hash, hostname, os_version, windows_build,
                first_seen, last_seen, trusted, trust_status, user_id
            ) VALUES (?, ?, ?, ?, ?, ?, 0, 'PENDING_TRUST', ?)
        ''', (
            device_info.get("device_hash"),
            device_info.get("hostname", ""),
            device_info.get("os_version", ""),
            device_info.get("windows_build", ""),
            int(time.time()),
            int(time.time()),
            device_info.get("user_id", "default_user")
        ))
        conn.commit()
        return True
    except Exception as e:
        print(f"Error registering device: {e}")
        return False
    finally:
        conn.close()

def update_device_last_seen(device_hash: str):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    try:
        cursor.execute(
            "UPDATE trusted_devices SET last_seen = ? WHERE device_hash = ?",
            (int(time.time()), device_hash)
        )
        conn.commit()
    except Exception as e:
        print(f"Error updating device last_seen: {e}")
    finally:
        conn.close()

def approve_device(device_hash: str, notes: str = None) -> bool:
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    try:
        cursor.execute(
            "UPDATE trusted_devices SET trusted = 1, trust_status = 'TRUSTED', notes = ? WHERE device_hash = ?",
            (notes, device_hash)
        )
        conn.commit()
        return cursor.rowcount > 0
    except Exception as e:
        print(f"Error approving device: {e}")
        return False
    finally:
        conn.close()

def revoke_device(device_hash: str) -> bool:
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    try:
        cursor.execute(
            "UPDATE trusted_devices SET trusted = 0, trust_status = 'REVOKED' WHERE device_hash = ?",
            (device_hash,)
        )
        conn.commit()
        return cursor.rowcount > 0
    except Exception as e:
        print(f"Error revoking device: {e}")
        return False
    finally:
        conn.close()

def check_device_trust(device_hash: str) -> dict:
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    try:
        cursor.execute(
            "SELECT device_hash, trusted, trust_status, first_seen, last_seen, hostname, user_id FROM trusted_devices WHERE device_hash = ?",
            (device_hash,)
        )
        row = cursor.fetchone()
        if row:
            device_age = int(time.time()) - row[3] if row[3] else 0
            return {
                "device_hash": row[0],
                "trusted": bool(row[1]),
                "trust_status": row[2],
                "first_seen": row[3],
                "last_seen": row[4],
                "hostname": row[5],
                "user_id": row[6],
                "device_age_hours": round(device_age / 3600, 1)
            }
        return None
    finally:
        conn.close()

def get_all_devices(limit: int = 100) -> pd.DataFrame:
    conn = sqlite3.connect(DB_PATH)
    try:
        query = "SELECT * FROM trusted_devices ORDER BY last_seen DESC LIMIT ?"
        df = pd.read_sql_query(query, conn, params=(limit,))
        return df
    finally:
        conn.close()

def insert_device_history(entry: dict):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    try:
        cursor.execute('''
            INSERT INTO device_history (device_hash, timestamp, event_type, details)
            VALUES (?, ?, ?, ?)
        ''', (
            entry.get("device_hash"),
            entry.get("timestamp", int(time.time())),
            entry.get("event_type", ""),
            entry.get("details", "{}")
        ))
        conn.commit()
    except Exception as e:
        print(f"Error inserting device history: {e}")
    finally:
        conn.close()

def get_device_history(device_hash: str = None, limit: int = 100) -> pd.DataFrame:
    conn = sqlite3.connect(DB_PATH)
    try:
        if device_hash:
            query = "SELECT * FROM device_history WHERE device_hash = ? ORDER BY timestamp DESC LIMIT ?"
            df = pd.read_sql_query(query, conn, params=(device_hash, limit))
        else:
            query = "SELECT * FROM device_history ORDER BY timestamp DESC LIMIT ?"
            df = pd.read_sql_query(query, conn, params=(limit,))
        return df
    finally:
        conn.close()

def upsert_agent_heartbeat(data: dict):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    try:
        cursor.execute("""
            INSERT OR REPLACE INTO agent_heartbeats
                (device_id, hostname, agent_version, build_number, status,
                 memory_usage_mb, cpu_usage_percent, current_user, last_seen)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            data.get("device_id", ""),
            data.get("hostname", ""),
            data.get("agent_version", ""),
            data.get("build_number", 0),
            data.get("status", "OFFLINE"),
            data.get("memory_usage_mb", 0.0),
            data.get("cpu_usage_percent", 0.0),
            data.get("current_user", ""),
            int(time.time())
        ))
        conn.commit()
    except Exception as e:
        print(f"Error upserting heartbeat: {e}")
    finally:
        conn.close()

def get_agent_heartbeat(device_id: str) -> dict:
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT * FROM agent_heartbeats WHERE device_id = ?", (device_id,))
        row = cursor.fetchone()
        if row:
            columns = [desc[0] for desc in cursor.description]
            return dict(zip(columns, row))
        return None
    except Exception as e:
        print(f"Error getting heartbeat: {e}")
        return None
    finally:
        conn.close()

def insert_incident(incident: dict) -> bool:
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    try:
        cursor.execute('''
            INSERT INTO incidents (
                incident_id, user_id, session_id, timestamp,
                risk_score, confidence, evidence_score, severity,
                status, mitre_technique, mitre_technique_name, mitre_tactic,
                recommended_action, reason_json, response_level, system_state
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            incident.get("incident_id"),
            incident.get("user_id"),
            incident.get("session_id"),
            incident.get("timestamp", int(time.time())),
            incident.get("risk_score", 0),
            incident.get("confidence", 0),
            incident.get("evidence_score", 0),
            incident.get("severity", "MEDIUM"),
            incident.get("status", "OPEN"),
            incident.get("mitre_technique", ""),
            incident.get("mitre_technique_name", ""),
            incident.get("mitre_tactic", ""),
            incident.get("recommended_action", ""),
            incident.get("reason_json", "{}"),
            incident.get("response_level", 0),
            incident.get("system_state", "NORMAL")
        ))
        conn.commit()
        return True
    except Exception as e:
        print(f"Error inserting incident: {e}")
        return False
    finally:
        conn.close()

def update_incident_status(incident_id: str, new_status: str, resolution_notes: str = None):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    try:
        if new_status in ("RESOLVED", "CLOSED"):
            cursor.execute('''
                UPDATE incidents SET status = ?, resolved_at = ?, resolution_notes = ?
                WHERE incident_id = ?
            ''', (new_status, int(time.time()), resolution_notes, incident_id))
        else:
            cursor.execute('''
                UPDATE incidents SET status = ? WHERE incident_id = ?
            ''', (new_status, incident_id))
        conn.commit()
    except Exception as e:
        print(f"Error updating incident: {e}")
    finally:
        conn.close()

def get_incident_by_id(incident_id: str) -> dict:
    conn = sqlite3.connect(DB_PATH)
    try:
        query = "SELECT * FROM incidents WHERE incident_id = ?"
        df = pd.read_sql_query(query, conn, params=(incident_id,))
        if not df.empty:
            return df.iloc[0].to_dict()
        return None
    finally:
        conn.close()

def get_incidents(user_id: str = None, status: str = None, limit: int = 50) -> pd.DataFrame:
    conn = sqlite3.connect(DB_PATH)
    try:
        conditions = []
        params = []
        if user_id:
            conditions.append("user_id = ?")
            params.append(user_id)
        if status:
            conditions.append("status = ?")
            params.append(status)
        where = "WHERE " + " AND ".join(conditions) if conditions else ""
        query = f"SELECT * FROM incidents {where} ORDER BY timestamp DESC LIMIT ?"
        params.append(limit)
        df = pd.read_sql_query(query, conn, params=params)
        return df
    finally:
        conn.close()

def insert_response_history(entry: dict):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    try:
        cursor.execute('''
            INSERT INTO response_history (
                user_id, session_id, timestamp, risk_score,
                confidence, evidence_score, action_taken,
                response_level, system_state, policy_id,
                incident_id, reasoning
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            entry.get("user_id"),
            entry.get("session_id"),
            entry.get("timestamp", int(time.time())),
            entry.get("risk_score", 0),
            entry.get("confidence", 0),
            entry.get("evidence_score", 0),
            entry.get("action_taken", ""),
            entry.get("response_level", 0),
            entry.get("system_state", "NORMAL"),
            entry.get("policy_id"),
            entry.get("incident_id"),
            entry.get("reasoning", "{}")
        ))
        conn.commit()
    except Exception as e:
        print(f"Error inserting response history: {e}")
    finally:
        conn.close()

def get_response_history(user_id: str = None, limit: int = 100) -> pd.DataFrame:
    conn = sqlite3.connect(DB_PATH)
    try:
        if user_id:
            query = "SELECT * FROM response_history WHERE user_id = ? ORDER BY timestamp DESC LIMIT ?"
            df = pd.read_sql_query(query, conn, params=(user_id, limit))
        else:
            query = "SELECT * FROM response_history ORDER BY timestamp DESC LIMIT ?"
            df = pd.read_sql_query(query, conn, params=(limit,))
        return df
    finally:
        conn.close()

def insert_policy_audit(entry: dict):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    try:
        cursor.execute('''
            INSERT INTO policy_audit (
                timestamp, policy_id, policy_name, user_id,
                risk_score, confidence, matched, action_taken, details
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            entry.get("timestamp", int(time.time())),
            entry.get("policy_id"),
            entry.get("policy_name"),
            entry.get("user_id"),
            entry.get("risk_score", 0),
            entry.get("confidence", 0),
            entry.get("matched", False),
            entry.get("action_taken", ""),
            entry.get("details", "{}")
        ))
        conn.commit()
    except Exception as e:
        print(f"Error inserting policy audit: {e}")
    finally:
        conn.close()

def get_policy_audit(limit: int = 100) -> pd.DataFrame:
    conn = sqlite3.connect(DB_PATH)
    try:
        query = "SELECT * FROM policy_audit ORDER BY timestamp DESC LIMIT ?"
        df = pd.read_sql_query(query, conn, params=(limit,))
        return df
    finally:
        conn.close()

def insert_containment_action(entry: dict):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    try:
        cursor.execute('''
            INSERT INTO containment_actions (
                incident_id, action, status, details, timestamp,
                completed_at, reverted_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (
            entry.get("incident_id"),
            entry.get("action"),
            entry.get("status", "PENDING"),
            entry.get("details", "{}"),
            entry.get("timestamp", int(time.time())),
            entry.get("completed_at"),
            entry.get("reverted_at"),
        ))
        conn.commit()
    except Exception as e:
        print(f"Error inserting containment action: {e}")
    finally:
        conn.close()

def get_containment_actions(incident_id: str = None, limit: int = 100) -> pd.DataFrame:
    conn = sqlite3.connect(DB_PATH)
    try:
        if incident_id:
            query = "SELECT * FROM containment_actions WHERE incident_id = ? ORDER BY timestamp DESC LIMIT ?"
            df = pd.read_sql_query(query, conn, params=(incident_id, limit))
        else:
            query = "SELECT * FROM containment_actions ORDER BY timestamp DESC LIMIT ?"
            df = pd.read_sql_query(query, conn, params=(limit,))
        return df
    finally:
        conn.close()

def insert_evidence_package(entry: dict):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    try:
        cursor.execute('''
            INSERT INTO evidence_packages (
                incident_id, case_id, package_path, hash_manifest,
                collected_at, status, collector_hostname, chain_of_custody
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            entry.get("incident_id"),
            entry.get("case_id"),
            entry.get("package_path"),
            entry.get("hash_manifest", "{}"),
            entry.get("collected_at", int(time.time())),
            entry.get("status", "COLLECTING"),
            entry.get("collector_hostname", ""),
            entry.get("chain_of_custody", "{}"),
        ))
        conn.commit()
    except Exception as e:
        print(f"Error inserting evidence package: {e}")
    finally:
        conn.close()

def get_evidence_packages(incident_id: str = None, limit: int = 100) -> pd.DataFrame:
    conn = sqlite3.connect(DB_PATH)
    try:
        if incident_id:
            query = "SELECT * FROM evidence_packages WHERE incident_id = ? ORDER BY collected_at DESC LIMIT ?"
            df = pd.read_sql_query(query, conn, params=(incident_id, limit))
        else:
            query = "SELECT * FROM evidence_packages ORDER BY collected_at DESC LIMIT ?"
            df = pd.read_sql_query(query, conn, params=(limit,))
        return df
    finally:
        conn.close()

def get_evidence_package_by_incident(incident_id: str) -> dict:
    conn = sqlite3.connect(DB_PATH)
    try:
        query = "SELECT * FROM evidence_packages WHERE incident_id = ? ORDER BY collected_at DESC LIMIT 1"
        df = pd.read_sql_query(query, conn, params=(incident_id,))
        if not df.empty:
            return df.iloc[0].to_dict()
        return None
    finally:
        conn.close()

if __name__ == "__main__":
    init_db()
