from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field


class LoginRequest(BaseModel):
    username: str = ""
    password: str = ""
    api_key: str = ""


class AnalyzeRequest(BaseModel):
    user_id: str = "default_user"
    device_hash: Optional[str] = None
    endpoint_id: Optional[str] = None
    typing_speed: Optional[float] = None
    key_latency: Optional[float] = None
    avg_hold_time: Optional[float] = None
    latency_jitter: Optional[float] = None
    mouse_speed: Optional[float] = None
    mouse_acceleration: Optional[float] = None
    direction_change_freq: Optional[float] = None
    click_frequency: Optional[float] = None
    active_app: Optional[str] = None
    app_switch_count: Optional[int] = None
    idle_time: Optional[float] = None
    time_of_day: Optional[int] = None
    session_duration: Optional[float] = None
    ip_address: Optional[str] = None
    city: Optional[str] = None
    country: Optional[str] = None
    device_trust_status: Optional[str] = None
    is_new_location: bool = False
    device_change_score: float = 0.0


class RegisterEndpointRequest(BaseModel):
    endpoint_id: str
    device_id: Optional[str] = None
    hostname: str = ""
    agent_version: str = ""
    build_number: int = 0
    os: Optional[str] = None
    os_version: Optional[str] = None
    architecture: Optional[str] = None
    ip_address: Optional[str] = None
    install_date: Optional[str] = None
    last_update: Optional[int] = None


class HeartbeatRequest(BaseModel):
    endpoint_id: str = "unknown"
    device_id: Optional[str] = None
    cpu_percent: float = 0.0
    memory_mb: float = 0.0
    current_user: str = ""
    risk_level: str = "LOW"
    agent_version: str = ""
    health_status: str = "ONLINE"
    session_state: str = "NORMAL"
    incident_count: int = 0
    policy_version: str = "0"
    hostname: Optional[str] = None
    ip_address: Optional[str] = None
    os: Optional[str] = None


class UpdateTagsRequest(BaseModel):
    tags: List[str] = Field(default_factory=list)


class UpdateMetadataRequest(BaseModel):
    metadata: Dict[str, Any] = Field(default_factory=dict)


class UpdateIncidentStatusRequest(BaseModel):
    status: str
    resolution_notes: Optional[str] = None
    analyst: Optional[str] = ""


class CreatePolicyRequest(BaseModel):
    name: str
    org_id: int
    policy_json: str = "{}"
    enabled: bool = True
    version: str = "1.0.0"


class UpdatePolicyRequest(BaseModel):
    name: Optional[str] = None
    policy_json: Optional[str] = None
    enabled: Optional[bool] = None


class RegisterDeviceRequest(BaseModel):
    device_hash: str
    endpoint_id: str = ""
    hostname: str = ""
    os_version: str = ""
    windows_build: str = ""
    architecture: Optional[str] = None
    user_id: str = "default_user"


class ApproveDeviceRequest(BaseModel):
    notes: Optional[str] = None


class CreateIOCRequest(BaseModel):
    ioc_id: Optional[str] = None
    ioc_type: str
    value: str
    severity: str = "MEDIUM"
    description: str = ""
    source: str = "manual"
    threat_family: str = "UNKNOWN"
    confidence: str = "MEDIUM"
    mitre_technique_id: Optional[str] = None
    mitre_technique_name: Optional[str] = None
    mitre_tactic: Optional[str] = None
    mitre_technique: Optional[str] = None
    expires_at: Optional[int] = None
    expiration: Optional[int] = None
    tags: Optional[list] = None
    reference_url: str = ""


class UpdateIOCRequest(BaseModel):
    severity: Optional[str] = None
    description: Optional[str] = None
    mitre_technique: Optional[str] = None
    mitre_tactic: Optional[str] = None
    expires_at: Optional[int] = None


class BulkIOCRequest(BaseModel):
    iocs: List[CreateIOCRequest]


class ThreatMatchRequest(BaseModel):
    indicators: List[str] = Field(default_factory=list)
    ioc_types: Optional[List[str]] = None
    value: Optional[str] = None
    type: Optional[str] = None
    artifacts: Optional[List[str]] = None


class ReputationRequest(BaseModel):
    indicator: str = ""
    ioc_type: Optional[str] = None
    artifact: Optional[str] = None
    type: Optional[str] = "IP"


class ScoreRequest(BaseModel):
    indicator: str = ""
    behavior_score: float = 0
    threat_intel_score: float = 0
    device_trust_score: float = 50
    location_trust_score: float = 50
    baseline_deviation: float = 0
    detection_rule_matches: int = 0
    detection_rule_avg_severity: float = 0


class UpdateFeedRequest(BaseModel):
    enabled: Optional[bool] = None
    interval_minutes: Optional[int] = None


class TransitionRequest(BaseModel):
    to_state: str
    reason: str = ""
    triggered_by: str = "operator"


class BulkTransitionRequest(BaseModel):
    endpoint_ids: List[str]
    to_state: str
    reason: str = ""


class IssueCommandRequest(BaseModel):
    command_type: str
    target_ids: List[str] = Field(default_factory=list)
    target_type: str = "endpoint"
    payload: Dict[str, Any] = Field(default_factory=dict)
    priority: int = 0
    expires_in_seconds: Optional[int] = None


class AgentPollRequest(BaseModel):
    endpoint_id: str
    supported_commands: List[str] = Field(default_factory=list)


class AgentAckRequest(BaseModel):
    command_id: str
    endpoint_id: str
    output: Dict[str, Any] = Field(default_factory=dict)


class AgentCompleteRequest(BaseModel):
    command_id: str
    endpoint_id: str
    status: str = "COMPLETED"
    output: Dict[str, Any] = Field(default_factory=dict)


class CreateProfileRequest(BaseModel):
    name: str
    org_id: Optional[int] = None
    config: Any = "{}"
    version: str = "1.0.0"
    active: bool = True
    description: str = ""


class UpdateProfileRequest(BaseModel):
    name: Optional[str] = None
    config_json: Optional[Any] = None
    config: Optional[Any] = None
    version: Optional[str] = None
    active: Optional[bool] = None
    description: Optional[str] = None


class AssignConfigRequest(BaseModel):
    profile_id: int
    target_type: str
    target_ids: List[str]


class SyncConfigRequest(BaseModel):
    profile_id: Optional[int] = None
    config_json: Optional[str] = None


class DriftReportRequest(BaseModel):
    endpoint_id: str
    profile_id: int
    drift_json: str = "{}"
    drift_score: float = 0.0


class CreateReleaseRequest(BaseModel):
    version: str
    build_number: int = 0
    release_notes: str = ""
    download_url: str = ""
    checksum: str = ""
    package_url: str = ""
    package_hash: str = ""
    min_supported_version: str = "0"
    mandatory: bool = False
    status: str = "DRAFT"


class UpdateReleaseRequest(BaseModel):
    release_notes: Optional[str] = None
    download_url: Optional[str] = None
    checksum: Optional[str] = None
    mandatory: Optional[bool] = None
    status: Optional[str] = None


class DeployUpdateRequest(BaseModel):
    update_id: int
    target_ids: List[str]
    target_type: str = "endpoint"
    scheduled_at: Optional[int] = None


class HealthSnapshotRequest(BaseModel):
    cpu_percent: float = 0.0
    memory_percent: float = 0.0
    memory_mb: float = 0.0
    disk_percent: float = 0.0
    queue_size: int = 0
    heartbeat_delay: int = 0
    uptime_hours: float = 0.0
    process_count: int = 0
    network_in_mbps: float = 0.0
    network_out_mbps: float = 0.0
    agent_version: str = ""
    build_number: int = 0
    additional_metrics: Dict[str, Any] = Field(default_factory=dict)


class InventoryReportRequest(BaseModel):
    software: List[Dict[str, Any]] = Field(default_factory=list)
    hardware: Dict[str, Any] = Field(default_factory=dict)
    services: List[Dict[str, Any]] = Field(default_factory=list)
    network_interfaces: List[Dict[str, Any]] = Field(default_factory=list)
    hostname: str = ""
    os: str = ""
    os_version: str = ""
    os_build: str = ""
    architecture: str = ""
    cpu_brand: str = ""
    cpu_cores: int = 0
    cpu_threads: int = 0
    total_ram_mb: int = 0
    disk_count: int = 0
    total_disk_gb: int = 0
    free_disk_gb: int = 0
    gpu_info: List[Dict[str, Any]] = Field(default_factory=list)
    installed_software: List[Dict[str, Any]] = Field(default_factory=list)
    security_software: List[Dict[str, Any]] = Field(default_factory=list)
    python_version: str = ""
    agent_version: str = ""
    agent_build: int = 0
    device_fingerprint: Dict[str, Any] = Field(default_factory=dict)
    windows_edition: str = ""
    windows_install_date: str = ""
    last_boot: str = ""


class CreateGroupRequest(BaseModel):
    name: str
    description: str = ""
    tags: List[str] = Field(default_factory=list)
    parent_id: Optional[int] = None


class UpdateGroupRequest(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    tags: Optional[List[str]] = None
    parent_id: Optional[int] = None


class AddMembersRequest(BaseModel):
    endpoint_ids: List[str] = Field(default_factory=list)
    endpoint_id: str = ""


class RunCycleRequest(BaseModel):
    rule_ids: Optional[List[str]] = None
    severity: Optional[str] = None
    records: Optional[List[Dict[str, Any]]] = None


class UpdateHuntRequest(BaseModel):
    status: Optional[str] = None
    severity: Optional[str] = None
    assigned_to: Optional[str] = None
    analyst_notes: Optional[str] = None
