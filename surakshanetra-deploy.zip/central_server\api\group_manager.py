"""
Group Manager — Endpoint grouping with hierarchical support.
Policies and configurations can be applied per group.
"""
import json
import time
from fastapi import APIRouter, Depends, HTTPException, Query
from ..database import get_connection
from ..auth import authenticate_request

router = APIRouter(prefix="/api/v1/groups", tags=["Endpoint Groups"])


def _write_audit(conn, action, category, target_type, target_id, actor, details):
    now = int(time.time())
    try:
        conn.execute(
            "INSERT INTO audit_logs_extended (action, category, target_type, target_id, actor, details, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (action, category, target_type, target_id, actor, json.dumps(details), now),
        )
    except Exception:
        pass


@router.post("")
async def create_group(payload: dict, user: dict = Depends(authenticate_request)):
    name = payload.get("name", "")
    if not name:
        raise HTTPException(status_code=400, detail="Group name required")
    description = payload.get("description", "")
    parent_id = payload.get("parent_id")
    conn = get_connection()
    now = int(time.time())
    try:
        cursor = conn.execute(
            "INSERT INTO endpoint_groups (name, description, parent_id, created_by, created_at) VALUES (?, ?, ?, ?, ?)",
            (name, description, parent_id, user.get("username", "admin"), now),
        )
        group_id = cursor.lastrowid
        _write_audit(conn, "group.create", "groups", "endpoint_group", str(group_id),
                     user.get("username", "admin"), {"name": name})
        conn.commit()
        conn.close()
        return {"status": "created", "group_id": group_id, "name": name}
    except Exception as e:
        conn.close()
        raise HTTPException(status_code=400, detail=str(e))


@router.get("")
async def list_groups(user: dict = Depends(authenticate_request)):
    conn = get_connection()
    groups = conn.execute("SELECT g.*, (SELECT COUNT(*) FROM group_members m WHERE m.group_id = g.id) as member_count FROM endpoint_groups g ORDER BY g.name").fetchall()
    conn.close()
    return {"groups": [dict(r) for r in groups]}


@router.get("/{group_id}")
async def get_group(group_id: int, user: dict = Depends(authenticate_request)):
    conn = get_connection()
    row = conn.execute("SELECT * FROM endpoint_groups WHERE id = ?", (group_id,)).fetchone()
    conn.close()
    if not row:
        raise HTTPException(status_code=404, detail="Group not found")
    return dict(row)


@router.put("/{group_id}")
async def update_group(group_id: int, payload: dict, user: dict = Depends(authenticate_request)):
    conn = get_connection()
    row = conn.execute("SELECT * FROM endpoint_groups WHERE id = ?", (group_id,)).fetchone()
    if not row:
        conn.close()
        raise HTTPException(status_code=404, detail="Group not found")
    now = int(time.time())
    if "name" in payload:
        conn.execute("UPDATE endpoint_groups SET name = ?, updated_at = ? WHERE id = ?", (payload["name"], now, group_id))
    if "description" in payload:
        conn.execute("UPDATE endpoint_groups SET description = ?, updated_at = ? WHERE id = ?", (payload["description"], now, group_id))
    if "parent_id" in payload:
        conn.execute("UPDATE endpoint_groups SET parent_id = ?, updated_at = ? WHERE id = ?", (payload["parent_id"], now, group_id))
    _write_audit(conn, "group.update", "groups", "endpoint_group", str(group_id),
                 user.get("username", "admin"), payload)
    conn.commit()
    conn.close()
    return {"status": "updated", "group_id": group_id}


@router.delete("/{group_id}")
async def delete_group(group_id: int, user: dict = Depends(authenticate_request)):
    conn = get_connection()
    row = conn.execute("SELECT name FROM endpoint_groups WHERE id = ?", (group_id,)).fetchone()
    if not row:
        conn.close()
        raise HTTPException(status_code=404, detail="Group not found")
    conn.execute("DELETE FROM group_members WHERE group_id = ?", (group_id,))
    conn.execute("DELETE FROM endpoint_groups WHERE id = ?", (group_id,))
    _write_audit(conn, "group.delete", "groups", "endpoint_group", str(group_id),
                 user.get("username", "admin"), {"name": row["name"]})
    conn.commit()
    conn.close()
    return {"status": "deleted"}


@router.post("/{group_id}/members")
async def add_member(group_id: int, payload: dict, user: dict = Depends(authenticate_request)):
    endpoint_id = payload.get("endpoint_id", "")
    if not endpoint_id:
        raise HTTPException(status_code=400, detail="endpoint_id required")
    conn = get_connection()
    now = int(time.time())
    try:
        conn.execute(
            "INSERT OR IGNORE INTO group_members (group_id, endpoint_id, added_at) VALUES (?, ?, ?)",
            (group_id, endpoint_id, now),
        )
        conn.execute("UPDATE endpoints SET group_id = ? WHERE endpoint_id = ?", (group_id, endpoint_id))
        _write_audit(conn, "group.member.add", "groups", "endpoint", endpoint_id,
                     user.get("username", "admin"), {"group_id": group_id})
        conn.commit()
        conn.close()
        return {"status": "added", "group_id": group_id, "endpoint_id": endpoint_id}
    except Exception as e:
        conn.close()
        raise HTTPException(status_code=400, detail=str(e))


@router.delete("/{group_id}/members/{endpoint_id}")
async def remove_member(group_id: int, endpoint_id: str, user: dict = Depends(authenticate_request)):
    conn = get_connection()
    conn.execute("DELETE FROM group_members WHERE group_id = ? AND endpoint_id = ?", (group_id, endpoint_id))
    conn.execute("UPDATE endpoints SET group_id = NULL WHERE endpoint_id = ? AND group_id = ?", (endpoint_id, group_id))
    _write_audit(conn, "group.member.remove", "groups", "endpoint", endpoint_id,
                 user.get("username", "admin"), {"group_id": group_id})
    conn.commit()
    conn.close()
    return {"status": "removed"}


@router.get("/{group_id}/members")
async def list_members(group_id: int, user: dict = Depends(authenticate_request)):
    conn = get_connection()
    rows = conn.execute(
        "SELECT e.endpoint_id, e.hostname, e.lifecycle_status, e.health_status, e.health_score, e.last_seen FROM endpoints e JOIN group_members m ON e.endpoint_id = m.endpoint_id WHERE m.group_id = ?",
        (group_id,),
    ).fetchall()
    conn.close()
    return {"group_id": group_id, "members": [dict(r) for r in rows], "count": len(rows)}
