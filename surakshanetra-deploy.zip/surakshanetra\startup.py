"""
SurakshaNetra startup initialization, diagnostics, and health framework.
"""
from __future__ import annotations

import importlib
import logging
import os
import sqlite3
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

logger = logging.getLogger("surakshanetra.startup")

PROJECT_ROOT = Path(__file__).resolve().parent.parent
STARTUP_TIME = time.time()
SCHEMA_VERSION = "2.0.0-rc1"

REQUIRED_DIRECTORIES = (
    PROJECT_ROOT / "data",
    PROJECT_ROOT / "logs",
    PROJECT_ROOT / "models",
    PROJECT_ROOT / "reports",
    PROJECT_ROOT / "uploads",
    PROJECT_ROOT / "backups",
    PROJECT_ROOT / "forensics",
    PROJECT_ROOT / "temp",
    PROJECT_ROOT / "evidence",
    PROJECT_ROOT / "agent" / "data",
    PROJECT_ROOT / "agent" / "logs",
    PROJECT_ROOT / "central_server" / "data",
    PROJECT_ROOT / "ml_service" / "models",
    PROJECT_ROOT / "threat_intelligence",
    PROJECT_ROOT / "hunter",
)

CRITICAL_MODULES = (
    ("fastapi", "0.100.0"),
    ("uvicorn", "0.23.0"),
    ("sqlite3", "3.0.0"),
    ("sklearn", "1.3.0"),
    ("numpy", "1.26.0"),
    ("pandas", "2.2.0"),
    ("websockets", None),
)


@dataclass
class StepResult:
    name: str
    status: str
    detail: str = ""
    duration_ms: float = 0.0

    @property
    def ok(self) -> bool:
        return self.status in {"ok", "recovered", "warning"}


def configure_startup_logging() -> None:
    log_dir = PROJECT_ROOT / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    if not logging.getLogger().handlers:
        logging.basicConfig(
            level=os.environ.get("LOG_LEVEL", "INFO").upper(),
            format="%(asctime)s %(levelname)s %(name)s - %(message)s",
            handlers=[
                logging.StreamHandler(),
                logging.FileHandler(log_dir / "startup.log", encoding="utf-8"),
            ],
        )


def _run_step(name: str, func) -> StepResult:
    start = time.perf_counter()
    logger.info("Starting %s", name)
    try:
        detail = func() or ""
        duration = round((time.perf_counter() - start) * 1000, 2)
        logger.info("Completed %s in %.2f ms%s", name, duration, f": {detail}" if detail else "")
        return StepResult(name, "ok", str(detail), duration)
    except Exception as exc:
        duration = round((time.perf_counter() - start) * 1000, 2)
        detail = f"{exc}. Review configuration and filesystem permissions, then restart."
        logger.exception("Failed %s in %.2f ms: %s", name, duration, exc)
        return StepResult(name, "failed", detail, duration)


class DirectoryManager:
    @staticmethod
    def ensure_directories() -> list[dict[str, Any]]:
        results: list[dict[str, Any]] = []
        for directory in REQUIRED_DIRECTORIES:
            existed = directory.exists()
            directory.mkdir(parents=True, exist_ok=True)
            results.append(
                {
                    "path": str(directory.relative_to(PROJECT_ROOT)),
                    "status": "present" if existed else "created",
                }
            )
            if not existed:
                logger.warning("Recovered missing directory: %s", directory)
        return results


class DatabaseInitializer:
    @staticmethod
    def initialize_all() -> dict[str, Any]:
        initialized: dict[str, Any] = {}

        from central_server.database import init_database
        from backend.db import init_db as init_behavior_db
        from threat_intelligence.feed_manager import init_feeds_table, register_feeds
        from threat_intelligence.ioc_manager import init_ioc_db
        from hunter.engine import init_hunter
        from agent.backend_queue import _ensure_db as init_agent_queue

        init_database()
        initialized["central"] = str(PROJECT_ROOT / "central_server" / "data" / "central.db")

        init_behavior_db()
        initialized["behavior"] = str(PROJECT_ROOT / "data" / "behavior.db")

        init_ioc_db()
        init_feeds_table()
        register_feeds()
        initialized["ioc"] = str(PROJECT_ROOT / "threat_intelligence" / "ioc_store.db")

        init_hunter()
        initialized["hunter"] = str(PROJECT_ROOT / "hunter" / "hunt_store.db")

        init_agent_queue()
        initialized["agent_queue"] = str(PROJECT_ROOT / "agent" / "data" / "agent_queue.db")

        for db_path in DatabaseInitializer.database_paths():
            DatabaseInitializer._ensure_schema_metadata(db_path)
            DatabaseInitializer._validate_integrity(db_path)

        return initialized

    @staticmethod
    def database_paths() -> tuple[Path, ...]:
        return (
            PROJECT_ROOT / "central_server" / "data" / "central.db",
            PROJECT_ROOT / "data" / "behavior.db",
            PROJECT_ROOT / "threat_intelligence" / "ioc_store.db",
            PROJECT_ROOT / "hunter" / "hunt_store.db",
            PROJECT_ROOT / "agent" / "data" / "agent_queue.db",
        )

    @staticmethod
    def _ensure_schema_metadata(db_path: Path) -> None:
        db_path.parent.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(db_path) as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS schema_metadata (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL,
                    updated_at INTEGER NOT NULL
                )
                """
            )
            conn.execute(
                """
                INSERT INTO schema_metadata (key, value, updated_at)
                VALUES ('schema_version', ?, ?)
                ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at
                """,
                (SCHEMA_VERSION, int(time.time())),
            )

    @staticmethod
    def _validate_integrity(db_path: Path) -> str:
        with sqlite3.connect(db_path) as conn:
            result = conn.execute("PRAGMA integrity_check").fetchone()[0]
        if result != "ok":
            raise RuntimeError(f"SQLite integrity check failed for {db_path}: {result}")
        return result

    @classmethod
    def check_databases(cls) -> dict[str, Any]:
        details = {}
        ok = True
        for db_path in cls.database_paths():
            rel = str(db_path.relative_to(PROJECT_ROOT))
            if not db_path.exists():
                details[rel] = {"status": "missing", "schema_version": None}
                ok = False
                continue
            try:
                integrity = cls._validate_integrity(db_path)
                with sqlite3.connect(db_path) as conn:
                    row = conn.execute(
                        "SELECT value FROM schema_metadata WHERE key = 'schema_version'"
                    ).fetchone()
                details[rel] = {
                    "status": "ok",
                    "integrity": integrity,
                    "schema_version": row[0] if row else "unknown",
                }
            except Exception as exc:
                details[rel] = {"status": "error", "detail": str(exc)}
                ok = False
        return {"ok": ok, "details": details}


class ConfigValidator:
    @staticmethod
    def validate_config() -> dict[str, Any]:
        issues: list[str] = []
        warnings: list[str] = []

        if not os.environ.get("CMS_JWT_SECRET"):
            warnings.append("CMS_JWT_SECRET is not set; an in-memory fallback secret will be generated.")

        if os.environ.get("CMS_ENABLE_HTTPS", "false").lower() == "true":
            cert = Path(os.environ.get("CMS_SSL_CERT", ""))
            key = Path(os.environ.get("CMS_SSL_KEY", ""))
            if not cert.exists() or not key.exists():
                issues.append("HTTPS is enabled but CMS_SSL_CERT or CMS_SSL_KEY is missing.")

        paths = {
            "central_db": PROJECT_ROOT / "central_server" / "data" / "central.db",
            "behavior_db": PROJECT_ROOT / "data" / "behavior.db",
            "ioc_db": PROJECT_ROOT / "threat_intelligence" / "ioc_store.db",
            "model": PROJECT_ROOT / "ml_service" / "models" / "model.pkl",
            "logs": PROJECT_ROOT / "logs",
        }

        for name, path in paths.items():
            if name.endswith("_db"):
                path.parent.mkdir(parents=True, exist_ok=True)
            elif name == "logs":
                path.mkdir(parents=True, exist_ok=True)

        return {
            "valid": not issues,
            "issues": issues,
            "warnings": warnings,
            "paths": {name: str(path) for name, path in paths.items()},
            "api": {
                "host": os.environ.get("CMS_HOST", "0.0.0.0"),
                "port": int(os.environ.get("CMS_PORT", "9000")),
                "https": os.environ.get("CMS_ENABLE_HTTPS", "false").lower() == "true",
            },
        }


class DependencyValidator:
    @classmethod
    def validate_dependencies(cls) -> list[dict[str, Any]]:
        report: list[dict[str, Any]] = []
        report.append(
            {
                "name": "Python",
                "version": sys.version.split()[0],
                "status": "OK" if sys.version_info >= (3, 10) else "WARNING",
                "required": ">= 3.10",
            }
        )

        for module_name, required in CRITICAL_MODULES:
            try:
                module = importlib.import_module(module_name)
                version = getattr(module, "__version__", sqlite3.sqlite_version if module_name == "sqlite3" else "installed")
                status = "OK"
                if required and version != "installed" and _version_tuple(str(version)) < _version_tuple(required):
                    status = "WARNING"
                report.append({"name": module_name, "version": version, "status": status, "required": required or "installed"})
            except ImportError:
                status = "FAILED" if module_name in {"fastapi", "sqlite3"} else "WARNING"
                report.append({"name": module_name, "version": "missing", "status": status, "required": required or "installed"})
        return report


def _version_tuple(value: str) -> tuple[int, ...]:
    parts = []
    for raw in value.replace("-", ".").split("."):
        digits = "".join(ch for ch in raw if ch.isdigit())
        if digits:
            parts.append(int(digits))
        else:
            break
    return tuple(parts or [0])


class MLDataDiscovery:
    @staticmethod
    def discover_training_data() -> dict[str, Any]:
        candidates = []
        configured = os.environ.get("BEHAVIOR_DATASET_PATH")
        if configured:
            candidates.append(Path(configured))
        candidates.extend(
            [
                PROJECT_ROOT / "agent" / "data" / "behavior_data.csv",
                PROJECT_ROOT / "data" / "behavior_data.csv",
            ]
        )
        custom_dir = os.environ.get("BEHAVIOR_DATASET_DIR")
        if custom_dir:
            candidates.extend(sorted(Path(custom_dir).glob("*.csv")))

        checked = []
        for candidate in candidates:
            checked.append(str(candidate))
            if candidate.exists() and candidate.stat().st_size > 0:
                logger.info("Selected ML training dataset: %s", candidate)
                return {"status": "found", "selected": str(candidate), "checked": checked}

        return {
            "status": "missing",
            "selected": None,
            "checked": checked,
            "message": "No training CSV was found. Add behavior_data.csv or set BEHAVIOR_DATASET_PATH.",
        }


class StartupDiagnostics:
    @classmethod
    def initialize_platform(cls, service_name: str = "SurakshaNetra Platform") -> dict[str, Any]:
        configure_startup_logging()
        steps = [
            _run_step("Directories", lambda: DirectoryManager.ensure_directories()),
            _run_step("Configuration", lambda: ConfigValidator.validate_config()),
            _run_step("Databases", lambda: DatabaseInitializer.initialize_all()),
            _run_step("Dependencies", lambda: DependencyValidator.validate_dependencies()),
            _run_step("ML Dataset Discovery", lambda: MLDataDiscovery.discover_training_data()),
        ]
        diag = cls.run_all(service_name, initialize=False)
        diag["steps"] = [step.__dict__ for step in steps]
        diag["status"] = "READY" if all(step.ok for step in steps) and diag["database"]["ok"] else "DEGRADED"
        cls.print_summary(service_name, diag)
        return diag

    @classmethod
    def run_all(cls, service_name: str = "SurakshaNetra Platform", initialize: bool = False) -> dict[str, Any]:
        if initialize:
            return cls.initialize_platform(service_name)

        start = time.perf_counter()
        dirs = [{"path": str(path.relative_to(PROJECT_ROOT)), "status": "present" if path.exists() else "missing"} for path in REQUIRED_DIRECTORIES]
        deps = DependencyValidator.validate_dependencies()
        cfg = ConfigValidator.validate_config()
        database = DatabaseInitializer.check_databases()
        threat_intel = cls._check_threat_intel()
        ml_model = cls._check_ml_model()
        dataset = MLDataDiscovery.discover_training_data()
        duration = round((time.perf_counter() - start) * 1000, 2)
        all_ok = all(d["status"] == "present" for d in dirs) and all(dep["status"] != "FAILED" for dep in deps) and cfg["valid"] and database["ok"]

        return {
            "service_name": service_name,
            "status": "READY" if all_ok else "DEGRADED",
            "duration_ms": duration,
            "directories": dirs,
            "dependencies": deps,
            "config": cfg,
            "database": database,
            "threat_intel": threat_intel,
            "ml_model": ml_model,
            "ml_dataset": dataset,
            "logging": {"status": "ready", "path": str(PROJECT_ROOT / "logs" / "startup.log")},
            "api": {"status": "ready"},
            "websocket": {"status": "ready"},
            "queue": {"status": "operational"},
        }

    @staticmethod
    def _check_threat_intel() -> dict[str, Any]:
        try:
            from threat_intelligence.ioc_manager import get_ioc_stats

            stats = get_ioc_stats()
            status = "LOADED" if stats.get("total_active", 0) > 0 else "EMPTY"
            detail = "IOC database is empty; safe default is active." if status == "EMPTY" else ""
            return {"status": status, "total_iocs": stats.get("total_active", 0), "detail": detail}
        except Exception as exc:
            return {"status": "WARNING", "detail": str(exc), "total_iocs": 0}

    @staticmethod
    def _check_ml_model() -> dict[str, Any]:
        model_path = PROJECT_ROOT / "ml_service" / "models" / "model.pkl"
        if model_path.exists():
            return {"status": "LOADED", "path": str(model_path.relative_to(PROJECT_ROOT))}
        return {"status": "NOT_TRAINED", "path": str(model_path.relative_to(PROJECT_ROOT)), "detail": "Model artifact is absent; API will return safe untrained responses."}

    @staticmethod
    def print_summary(service_name: str = "SurakshaNetra Platform", diag: dict[str, Any] | None = None) -> None:
        diag = diag or StartupDiagnostics.run_all(service_name)
        lines = [
            "=" * 50,
            f"SurakshaNetra Startup Validation - {service_name}",
            "=" * 50,
            f"{_mark(diag['config']['valid'])} Configuration Loaded",
            f"{_mark(all(d['status'] == 'present' for d in diag['directories']))} Required Directories Present",
            f"{_mark(diag['database']['ok'])} SQLite Connected",
            f"{_mark(diag['database']['ok'])} Database Schema Valid",
            f"{_mark(diag['threat_intel']['status'] in {'LOADED', 'EMPTY'})} Threat Intelligence {diag['threat_intel']['status']}",
            f"{_mark(diag['ml_model']['status'] == 'LOADED')} ML Model {diag['ml_model']['status']}",
            f"{_mark(True)} Logging Initialized",
            f"{_mark(True)} REST API Ready",
            f"{_mark(True)} WebSocket Ready",
            f"{_mark(True)} Dependency Check Completed in {diag['duration_ms']} ms",
            "",
            f"System Status : {diag['status']}",
            "=" * 50,
        ]
        for line in lines:
            logger.info(line)
            print(line)


def _mark(ok: bool) -> str:
    return "[OK]" if ok else "[WARN]"


class HealthCheckManager:
    @staticmethod
    def get_health_status() -> dict[str, Any]:
        uptime = int(time.time() - STARTUP_TIME)
        diag = StartupDiagnostics.run_all()
        return {
            "status": "healthy" if diag["status"] == "READY" else "degraded",
            "overall_status": diag["status"],
            "version": "2.0.0",
            "uptime_seconds": uptime,
            "timestamp": int(time.time()),
            "database_status": "connected" if diag["database"]["ok"] else "error",
            "database": diag["database"],
            "threat_intel_status": diag["threat_intel"]["status"],
            "ml_service_status": diag["ml_model"]["status"],
            "websocket_status": diag["websocket"]["status"],
            "queue_status": diag["queue"]["status"],
            "build_info": {
                "release": "2.0.0-RC1",
                "schema_version": SCHEMA_VERSION,
                "environment": os.environ.get("ENV", "production"),
                "python_version": sys.version.split()[0],
            },
        }

    @staticmethod
    def get_liveness() -> dict[str, Any]:
        return {"status": "alive", "timestamp": int(time.time())}

    @staticmethod
    def get_readiness() -> dict[str, Any]:
        diag = StartupDiagnostics.run_all()
        ready = diag["status"] == "READY"
        return {
            "status": "ready" if ready else "not_ready",
            "checks": {
                "configuration": diag["config"]["valid"],
                "directories": all(d["status"] == "present" for d in diag["directories"]),
                "database": diag["database"]["ok"],
                "threat_intel": diag["threat_intel"]["status"] in {"LOADED", "EMPTY"},
                "ml_model": diag["ml_model"]["status"] in {"LOADED", "NOT_TRAINED"},
                "logging": diag["logging"]["status"] == "ready",
                "api": diag["api"]["status"] == "ready",
                "websocket": diag["websocket"]["status"] == "ready",
                "dependencies": all(dep["status"] != "FAILED" for dep in diag["dependencies"]),
            },
            "timestamp": int(time.time()),
        }
