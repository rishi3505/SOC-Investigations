# Architecture

## System Overview

```
┌─────────────────────────────────────────────────────────────┐
│                    User Device                               │
│  ┌──────────────────────────────────────────────────────┐   │
│  │  Agent (collector.py)                                │   │
│  │  ┌──────────┐  ┌──────────────┐  ┌──────────────┐   │   │
│  │  │ Keyboard │  │ Mouse        │  │ System       │   │   │
│  │  │ Monitor  │  │ Tracker      │  │ Monitor      │   │   │
│  │  └──────────┘  └──────────────┘  └──────────────┘   │   │
│  │  ┌──────────────────────────────────────────────┐   │   │
│  │  │ Location Tracker (IP-based Geo)              │   │   │
│  │  └──────────────────────────────────────────────┘   │   │
│  └──────────────────────────────────────────────────────┘   │
└────────────────────┬────────────────────────────────────────┘
                     │ POST /api/v1/analyze
                     ▼
┌─────────────────────────────────────────────────────────────┐
│  ML Service (FastAPI - port 8000)                           │
│                                                             │
│  ┌────────────────────┐  ┌────────────────────────────┐    │
│  │  app.py            │  │  anomaly_model.py          │    │
│  │  - /analyze        │  │  - Isolation Forest (ML)  │    │
│  │  - /feedback       │  │  - Rule-based scoring     │    │
│  │  - /retrain        │  │  - Hybrid risk computation │    │
│  │  - /dashboard/*    │  │  - XAI reasons             │    │
│  └────────────────────┘  └────────────────────────────┘    │
│                                                             │
│  ┌────────────────────┐  ┌────────────────────────────┐    │
│  │  train.py          │  │  preprocessing.py          │    │
│  │  - Retrain pipeline│  │  - StandardScaler          │    │
│  │  - Adaptive thresh │  │  - OneHotEncoder           │    │
│  │  - Auto-trust locs │  │  - Feature pipeline        │    │
│  └────────────────────┘  └────────────────────────────┘    │
└────────────────────┬────────────────────────────────────────┘
                     │ SQLite (in-process)
                     ▼
┌─────────────────────────────────────────────────────────────┐
│  Backend DB (SQLite)                                        │
│  data/behavior.db                                           │
│  ┌──────────────────────────────────────────────────────┐   │
│  │  Tables:                                              │   │
│  │  - behavior_data         (raw behavioral records)     │   │
│  │  - session_risk_history  (rolling risk scores)        │   │
│  │  - user_profiles         (per-user thresholds)        │   │
│  │  - trusted_locations     (whitelisted geo-locations)  │   │
│  │  - trusted_sessions      (step-up auth sessions)      │   │
│  │  - feedback_data         (user labels for retraining) │   │
│  └──────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘

                     ▲ Query (Streamlit via API)
                     │
┌─────────────────────────────────────────────────────────────┐
│  Dashboard (Streamlit - port 8501)                          │
│  - Overview (system stats)                                  │
│  - Real-Time Monitoring (live risk trends)                  │
│  - Behavior Analysis (feature distributions)                │
│  - User Profiles (thresholds)                               │
│  - Trusted Locations                                        │
│  - API Test Console                                         │
└─────────────────────────────────────────────────────────────┘
```

## Risk Engine Pipeline

```
Raw Behavior Data
    ↓
1. Preprocessing (StandardScaler + OneHotEncoder)
    ↓
2. Isolation Forest (ML anomaly detection)
    ↓
3. Rule-Based Scoring (deviation from historical means)
    ↓
4. Hybrid Score = 0.8 × ML Score + 0.2 × Rule Score
    ↓
5. Multi-Signal Validation (behavior + location consensus)
    ↓
6. Risk State Machine (LEARNING → MONITORING → PROTECTED)
    ↓
7. Session Memory (rolling history, gradual decay)
    ↓
Risk Level + Action + XAI Reason
```

## Key Features

### Hybrid Risk Scoring
Combines Isolation Forest (80%) with rule-based heuristics (20%) for robust detection.

### Multi-Signal Validation
Only triggers HIGH risk if 2+ features deviate significantly or 1+ extreme deviation detected. Suppresses false positives from single-signal noise.

### Adaptive Thresholds
Per-user thresholds calculated using Median + Median Absolute Deviation (MAD) after each retraining cycle.

### Gradual Risk Decay
Risk scores decay by 12.5% per window after 3 consecutive normal windows, preventing prolonged false alarms.

### Lifecycle Stages
New users start in LEARNING mode (all risks suppressed) and graduate to PROTECTED mode after 500 samples.

### Explainable AI
Every decision includes human-readable reasons identifying which features deviated from baseline and by how much.
