import time


class ForensicTimeline:
    def __init__(self, incident_id: str = None):
        self.incident_id = incident_id
        self.events = []

    def add_event(
        self,
        event_type: str,
        description: str,
        timestamp: int = None,
        metadata: dict = None,
    ):
        self.events.append({
            "timestamp": timestamp or int(time.time()),
            "event_type": event_type,
            "description": description,
            "metadata": metadata or {},
        })

    def add_behavior_collected(self, user_id: str, risk_score: float = None):
        self.add_event(
            "behavior_collected",
            f"Behavior data collected for user {user_id}",
            metadata={"user_id": user_id, "risk_score": risk_score},
        )

    def add_ml_analysis(self, risk_score: float, is_anomalous: bool):
        self.add_event(
            "ml_analysis",
            f"ML analysis complete: risk_score={risk_score}, anomalous={is_anomalous}",
            metadata={"risk_score": risk_score, "is_anomalous": is_anomalous},
        )

    def add_risk_scored(self, risk_level: str, evidence_score: float):
        self.add_event(
            "risk_scored",
            f"Risk assessment: level={risk_level}, evidence={evidence_score}",
            metadata={"risk_level": risk_level, "evidence_score": evidence_score},
        )

    def add_policy_triggered(self, policy_id: str, policy_name: str):
        self.add_event(
            "policy_triggered",
            f"Policy matched: {policy_id} - {policy_name}",
            metadata={"policy_id": policy_id, "policy_name": policy_name},
        )

    def add_containment_action(self, action: str, details: dict = None):
        self.add_event(
            "containment_action",
            f"Containment action executed: {action}",
            metadata={"action": action, "details": details},
        )

    def add_evidence_collection(self, artifact_count: int):
        self.add_event(
            "evidence_collection",
            f"Forensic evidence collected: {artifact_count} artifacts",
            metadata={"artifact_count": artifact_count},
        )

    def add_incident_created(self, incident_id: str, severity: str):
        self.incident_id = incident_id
        self.add_event(
            "incident_created",
            f"Incident {incident_id} created with severity {severity}",
            metadata={"incident_id": incident_id, "severity": severity},
        )

    def add_response_completed(self, action: str, result: str):
        self.add_event(
            "response_completed",
            f"Response action '{action}' completed: {result}",
            metadata={"action": action, "result": result},
        )

    def add_incident_resolved(self, resolution: str):
        self.add_event(
            "incident_resolved",
            f"Incident resolved: {resolution}",
            metadata={"resolution": resolution},
        )

    def to_dict(self) -> dict:
        self.events.sort(key=lambda e: e["timestamp"])
        return {
            "incident_id": self.incident_id,
            "total_events": len(self.events),
            "time_span_seconds": (
                self.events[-1]["timestamp"] - self.events[0]["timestamp"]
                if len(self.events) >= 2
                else 0
            ),
            "events": self.events,
        }

    def to_list(self) -> list:
        self.events.sort(key=lambda e: e["timestamp"])
        return self.events

    def merge(self, other: "ForensicTimeline"):
        self.events.extend(other.events)
        self.events.sort(key=lambda e: e["timestamp"])
