"""
Threat Intelligence Router — IOC management, feed management, threat scoring,
hunt results, and detection rule management.
"""
import time
from fastapi import APIRouter, Depends, HTTPException, Query
from ..database import get_connection
from ..auth import authenticate_request
from ..models import CreateIOCRequest, UpdateIOCRequest, BulkIOCRequest, ThreatMatchRequest, ReputationRequest, ScoreRequest, UpdateFeedRequest, RunCycleRequest, UpdateHuntRequest

router = APIRouter(prefix="/api/v1/threat-intel", tags=["Threat Intelligence"])


@router.get("/iocs")
async def list_iocs(
    search: str = "",
    ioc_type: str = None,
    severity: str = None,
    page: int = Query(1, ge=1),
    limit: int = Query(50, ge=1, le=200),
    user: dict = Depends(authenticate_request),
):
    from threat_intelligence.ioc_manager import search_iocs
    return search_iocs(search=search, ioc_type=ioc_type, severity=severity, page=page, limit=limit)


@router.get("/iocs/{ioc_id}")
async def get_ioc(ioc_id: str, user: dict = Depends(authenticate_request)):
    from threat_intelligence.ioc_manager import get_ioc_by_id
    ioc = get_ioc_by_id(ioc_id)
    if not ioc:
        raise HTTPException(status_code=404, detail="IOC not found")
    return ioc


@router.post("/iocs")
async def create_ioc(payload: CreateIOCRequest, user: dict = Depends(authenticate_request)):
    from threat_intelligence.ioc_manager import add_ioc
    try:
        ioc_id = add_ioc(
            ioc_type=payload.ioc_type,
            value=payload.value,
            threat_family=payload.threat_family,
            severity=payload.severity,
            confidence=payload.confidence,
            source=payload.source,
            description=payload.description,
            mitre_technique_id=payload.mitre_technique_id or "",
            mitre_technique_name=payload.mitre_technique_name or "",
            mitre_tactic=payload.mitre_tactic or "",
            expiration=payload.expiration,
            tags=payload.tags,
            reference_url=payload.reference_url,
        )
        return {"status": "created", "ioc_id": ioc_id}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.put("/iocs/{ioc_id}")
async def update_ioc(ioc_id: str, payload: UpdateIOCRequest, user: dict = Depends(authenticate_request)):
    from threat_intelligence.ioc_manager import update_ioc, get_ioc_by_id
    if not get_ioc_by_id(ioc_id):
        raise HTTPException(status_code=404, detail="IOC not found")
    kwargs = payload.model_dump(exclude_none=True)
    updated = update_ioc(ioc_id, **kwargs)
    return {"status": "updated" if updated else "no_changes"}


@router.get("/iocs/stats")
async def ioc_stats(user: dict = Depends(authenticate_request)):
    from threat_intelligence.ioc_manager import get_ioc_stats, deactivate_expired_iocs
    expired = deactivate_expired_iocs()
    stats = get_ioc_stats()
    stats["expired_deactivated"] = expired
    return stats


@router.post("/iocs/bulk")
async def bulk_add_iocs(payload: BulkIOCRequest, user: dict = Depends(authenticate_request)):
    from threat_intelligence.ioc_manager import bulk_add_iocs
    iocs = [ioc.model_dump() for ioc in payload.iocs]
    if not iocs:
        raise HTTPException(status_code=400, detail="No IOCs provided")
    imported = bulk_add_iocs(iocs)
    return {"status": "completed", "imported": imported, "total": len(iocs)}


@router.post("/match")
async def match_iocs(payload: ThreatMatchRequest, user: dict = Depends(authenticate_request)):
    from threat_intelligence.ioc_matcher import match_value, match_batch
    value = payload.value
    value_type = payload.type
    artifacts = payload.artifacts
    if artifacts:
        return {"matches": match_batch(artifacts)}
    if value:
        result = match_value(value, value_type)
        return {"match": result}
    raise HTTPException(status_code=400, detail="Provide 'value' or 'artifacts'")


@router.post("/reputation")
async def check_reputation(payload: ReputationRequest, user: dict = Depends(authenticate_request)):
    from threat_intelligence.reputation_engine import get_reputation
    artifact = payload.artifact
    artifact_type = payload.type or "IP"
    if not artifact:
        raise HTTPException(status_code=400, detail="Provide 'artifact'")
    return get_reputation(artifact, artifact_type)


@router.post("/score")
async def compute_threat_score(payload: ScoreRequest, user: dict = Depends(authenticate_request)):
    from threat_intelligence.threat_scoring import ThreatScoreComponents, compute_threat_score
    components = ThreatScoreComponents(
        behavior_score=payload.behavior_score,
        threat_intel_score=payload.threat_intel_score,
        device_trust_score=payload.device_trust_score,
        location_trust_score=payload.location_trust_score,
        baseline_deviation=payload.baseline_deviation,
        detection_rule_matches=payload.detection_rule_matches,
        detection_rule_avg_severity=payload.detection_rule_avg_severity,
    )
    return compute_threat_score(components)


@router.get("/feeds")
async def list_feeds(user: dict = Depends(authenticate_request)):
    from threat_intelligence.feed_manager import get_feeds
    return {"feeds": get_feeds()}


@router.put("/feeds/{feed_id}")
async def update_feed(feed_id: int, payload: UpdateFeedRequest, user: dict = Depends(authenticate_request)):
    from threat_intelligence.feed_manager import update_feed_config
    kwargs = payload.model_dump(exclude_none=True)
    updated = update_feed_config(feed_id, **kwargs)
    return {"status": "updated" if updated else "no_changes"}


@router.post("/feeds/{feed_id}/run")
async def run_feed(feed_id: int, user: dict = Depends(authenticate_request)):
    from threat_intelligence.feed_manager import run_feed as execute_feed
    result = execute_feed(feed_id)
    return result


@router.post("/feeds/run-all")
async def run_all_due_feeds(user: dict = Depends(authenticate_request)):
    from threat_intelligence.feed_manager import run_all_due_feeds
    results = run_all_due_feeds()
    return {"results": results, "total": len(results)}


@router.get("/rules")
async def list_detection_rules(user: dict = Depends(authenticate_request)):
    from rules.rule_engine import load_rules
    rules = load_rules()
    return {"rules": rules, "total": len(rules)}


@router.get("/rules/{rule_id}")
async def get_detection_rule(rule_id: str, user: dict = Depends(authenticate_request)):
    from rules.rule_engine import get_rule_by_id
    rule = get_rule_by_id(rule_id)
    if not rule:
        raise HTTPException(status_code=404, detail="Rule not found")
    return rule


@router.get("/hunts")
async def list_hunt_results(
    severity: str = None,
    status: str = None,
    rule_id: str = None,
    mitre_technique: str = None,
    page: int = Query(1, ge=1),
    limit: int = Query(50, ge=1, le=200),
    user: dict = Depends(authenticate_request),
):
    from hunter.engine import get_hunter
    return get_hunter().get_results(severity=severity, status=status, rule_id=rule_id, mitre_technique=mitre_technique, page=page, limit=limit)


@router.get("/hunts/stats")
async def hunt_stats(user: dict = Depends(authenticate_request)):
    from hunter.engine import get_hunter
    return get_hunter().get_stats()


@router.get("/hunts/{hunt_id}")
async def get_hunt_result(hunt_id: str, user: dict = Depends(authenticate_request)):
    from hunter.engine import get_hunter
    result = get_hunter().get_result_by_id(hunt_id)
    if not result:
        raise HTTPException(status_code=404, detail="Hunt result not found")
    return result


@router.put("/hunts/{hunt_id}")
async def update_hunt_result(hunt_id: str, payload: UpdateHuntRequest, user: dict = Depends(authenticate_request)):
    from hunter.engine import get_hunter
    updated = get_hunter().update_result(
        hunt_id,
        status=payload.status or "",
        analyst_notes=payload.analyst_notes or "",
        verified_by=user.get("username", ""),
    )
    if not updated:
        raise HTTPException(status_code=400, detail="Invalid status or hunt not found")
    return {"status": "updated"}


@router.post("/hunts/run-cycle")
async def run_hunt_cycle(payload: RunCycleRequest, user: dict = Depends(authenticate_request)):
    from hunter.engine import get_hunter
    from threat_intelligence.ioc_matcher import match_payload
    records = payload.records or []
    ioc_matches = {}
    for record in records:
        rid = str(record.get("id") or record.get("endpoint_id", "unknown"))
        ioc_matches[rid] = match_payload(record)
    hunt_ids = get_hunter().run_hunt_cycle(records, ioc_matches)
    return {"hunt_ids": hunt_ids, "total": len(hunt_ids)}


@router.get("/overview")
async def threat_intel_overview(user: dict = Depends(authenticate_request)):
    from threat_intelligence.ioc_manager import get_ioc_stats
    ioc_stats = get_ioc_stats()
    from hunter.engine import get_hunter
    hunt_stats = get_hunter().get_stats()
    from rules.rule_engine import load_rules
    rules = load_rules()
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM incidents WHERE severity = 'CRITICAL' AND status NOT IN ('RESOLVED','CLOSED')")
    critical_incidents = cursor.fetchone()[0]
    conn.close()
    return {
        "ioc_stats": ioc_stats,
        "hunt_stats": hunt_stats,
        "active_rules": len(rules),
        "critical_incidents": critical_incidents,
    }
