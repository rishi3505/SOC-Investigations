import pandas as pd
import joblib
import os
import json
import numpy as np
import sys
sys.path.append(os.path.dirname(__file__))

from preprocessing import load_preprocessing_pipeline, load_historical_means, NUMERICAL_FEATURES

MODELS_DIR = os.path.join(os.path.dirname(__file__), 'models')

class AnomalyModel:
    def __init__(self):
        self.model = self._load_model()
        self.preprocessor = load_preprocessing_pipeline()
        self.historical_means = load_historical_means()

    def _load_model(self):
        path = os.path.join(MODELS_DIR, 'model.pkl')
        if os.path.exists(path):
            return joblib.load(path)
        return None

    def calculate_rule_score(self, data, baseline=None):
        """
        Calculates a rule-based score with explicit weighing and deviation filtering.
        """
        target_baseline = baseline if baseline else self.historical_means
        if not target_baseline:
            return 50.0, {}
            
        # Refinement Part 1: Explicit Weights
        weights = {
            "typing_speed": 1.0,
            "idle_time": 0.8,
            "app_switch_count": 0.7,
            "mouse_acceleration": 0.2,
            "direction_change_freq": 0.2,
            # Intermediate defaults for non-explicitly mentioned features
            "key_latency": 0.5,
            "avg_hold_time": 0.5,
            "latency_jitter": 0.5,
            "mouse_speed": 0.5,
            "click_frequency": 0.3
        }
        
        weighted_deviation = 0
        total_weight = 0
        
        # Contribution Logic (Part 4)
        significance = {
            "weak_count": 0,    # 15-30%
            "strong_count": 0,  # > 30%
            "extreme_count": 0, # > 40%
            "deviating_features": []
        }
        
        for feature, weight in weights.items():
            if feature in data:
                actual = float(data[feature])
                mean_val = float(target_baseline.get(feature, 0.0))
                
                # Deviation logic: (actual - mean) / mean
                if mean_val > 0.001:
                    raw_dev = abs(actual - mean_val) / mean_val
                    
                    # Refinement Part 2: Percentage-based filtering (Dead-zone)
                    if raw_dev < 0.15:
                        dev_impact = 0.0
                    else:
                        # Categorize significance
                        if raw_dev > 0.40: significance["extreme_count"] += 1
                        if raw_dev > 0.30: significance["strong_count"] += 1
                        elif raw_dev >= 0.15: significance["weak_count"] += 1
                        
                        significance["deviating_features"].append(feature)
                        
                        # Normalize deviation to impact score: min(1.0, dev)
                        dev_impact = min(1.0, raw_dev)
                        
                    weighted_deviation += dev_impact * weight
                    total_weight += weight
                    
        if total_weight == 0:
            return 50.0, significance
            
        # Convert to 0-100 scale
        rule_score = (weighted_deviation / total_weight) * 100
        return round(rule_score, 2), significance

    def predict(self, data, user_id="default", thresholds=None):
        """
        Takes raw behavior data and returns risk score and significance markers.
        """
        if self.model is None or self.preprocessor is None:
            return {
                "risk_score": 0.0,
                "confidence_score": 1.0,
                "is_anomalous": False,
                "reason": "Model not trained yet.",
                "significance": {"weak_count": 0, "strong_count": 0, "extreme_count": 0}
            }

        input_df = pd.DataFrame([data])
        
        # Preprocess input
        try:
            X_transformed = self.preprocessor.transform(input_df)
        except Exception as e:
            return {
                "risk_score": 0.0,
                "confidence_score": 0.0,
                "is_anomalous": False,
                "reason": f"Preprocessing error: {e}",
                "significance": {"weak_count": 0, "strong_count": 0, "extreme_count": 0}
            }

        # Predict anomaly status
        pred = self.model.predict(X_transformed)[0]
        raw_dist = self.model.decision_function(X_transformed)[0]
        
        confidence = min(1.0, abs(raw_dist) / 0.2)
        
        # Convert raw dist to risk
        risk_score = round(50 - (raw_dist * 100), 2)
        risk_score = max(0.0, min(100.0, risk_score))
        
        is_anomalous = bool(pred == -1)
        
        # Calculate Refined Rule Score and Significance
        rule_score, sig_report = self.calculate_rule_score(data)
        
        # Hybrid Scoring
        combined_risk_score = round((0.8 * risk_score) + (0.2 * rule_score), 2)
        
        return {
            "risk_score": combined_risk_score,
            "confidence_score": round(confidence, 4),
            "is_anomalous": is_anomalous,
            "significance": sig_report,
            "reason": "Anomalous patterns detected." if is_anomalous else "Normal behavior."
        }

_model_cache = None

def get_model_instance():
    global _model_cache
    if _model_cache is None:
        _model_cache = AnomalyModel()
    return _model_cache


def clear_model_cache():
    global _model_cache
    _model_cache = None
