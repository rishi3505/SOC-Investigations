import requests
import time

class LocationTracker:
    def __init__(self):
        self.last_location = None
        self.last_fetch_time = 0
        self.cache_duration = 300  # 5 minutes in seconds

    def get_location(self):
        """
        Fetches the current public IP location.
        Returns a dictionary with ip, city, country, and is_new_location.
        """
        current_time = time.time()
        
        # Return cached location if within duration
        if self.last_location and (current_time - self.last_fetch_time < self.cache_duration):
            return {**self.last_location, "is_new_location": False}

        try:
            # 1. Fetch public IP
            ip_resp = requests.get("https://api.ipify.org?format=json", timeout=5)
            ip_resp.raise_for_status()
            ip = ip_resp.json().get("ip")

            # 2. Fetch City/Country info
            loc_resp = requests.get(f"http://ip-api.com/json/{ip}", timeout=5)
            loc_resp.raise_for_status()
            loc_data = loc_resp.json()

            new_loc_info = {
                "ip_address": ip,
                "city": loc_data.get("city", "Unknown"),
                "country": loc_data.get("country", "Unknown")
            }

            # 3. Detect change
            is_new = False
            if self.last_location:
                if (new_loc_info["city"] != self.last_location["city"] or 
                    new_loc_info["country"] != self.last_location["country"]):
                    is_new = True

            self.last_location = new_loc_info
            self.last_fetch_time = current_time
            
            return {**new_loc_info, "is_new_location": is_new}

        except Exception as e:
            print(f"Error fetching location: {e}")
            # Graceful fallback to Unknown
            fallback = {
                "ip_address": "0.0.0.0",
                "city": "Unknown",
                "country": "Unknown",
                "is_new_location": False
            }
            return fallback

if __name__ == "__main__":
    tracker = LocationTracker()
    print(tracker.get_location())
