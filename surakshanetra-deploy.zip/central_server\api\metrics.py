"""Prometheus metrics endpoint for production monitoring."""
from prometheus_client import Counter, Histogram, generate_latest, CONTENT_TYPE_LATEST
from fastapi import APIRouter, Response
from fastapi.responses import PlainTextResponse

router = APIRouter(tags=["Metrics"])

HTTP_REQUESTS = Counter("cms_http_requests_total", "Total HTTP requests", ["method", "endpoint", "status"])
HTTP_LATENCY = Histogram("cms_http_latency_seconds", "HTTP request latency", ["method", "endpoint"],
                         buckets=[0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0])
ACTIVE_ENDPOINTS = Counter("cms_active_endpoints", "Active registered endpoints")
INCIDENTS_TRIGGERED = Counter("cms_incidents_total", "Total incidents triggered", ["severity"])
HEARTBEATS_RECEIVED = Counter("cms_heartbeats_total", "Total agent heartbeats received")
ANALYZE_REQUESTS = Counter("cms_analyze_requests_total", "Total /api/v1/analyze requests")


@router.get("/metrics")
async def metrics():
    return PlainTextResponse(generate_latest(), media_type=CONTENT_TYPE_LATEST)
