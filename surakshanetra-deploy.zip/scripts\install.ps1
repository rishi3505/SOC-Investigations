<#
.SYNOPSIS
    SurakshaNetra - One-command install for Windows VM
.DESCRIPTION
    Installs Python, creates venv, installs deps, and configures the CMS.
    Run this as Administrator on a fresh Windows VM.
.EXAMPLE
    .\scripts\install.ps1
#>

$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path -Parent (Split-Path -Parent $PSCommandPath)

Write-Host "=== SurakshaNetra Installer ===" -ForegroundColor Cyan

# 1. Check Python
$py = Get-Command "python" -ErrorAction SilentlyContinue
if (-not $py) {
    Write-Host "Python not found. Downloading Python 3.11..." -ForegroundColor Yellow
    $installer = "$env:TEMP\python-3.11.9-amd64.exe"
    $wc = New-Object System.Net.WebClient
    $wc.DownloadFile("https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe", $installer)
    Write-Host "Installing Python 3.11 (add to PATH)..." -ForegroundColor Yellow
    Start-Process -Wait -FilePath $installer -ArgumentList "/quiet InstallAllUsers=1 PrependPath=1"
    $env:Path = [Environment]::GetEnvironmentVariable("Path", "Machine")
}

python --version
if ($LASTEXITCODE -ne 0) { throw "Python installation failed" }

# 2. Create venv
$venvPath = "$ProjectRoot\.venv"
if (-not (Test-Path $venvPath)) {
    Write-Host "Creating virtual environment..." -ForegroundColor Cyan
    python -m venv $venvPath
}

# 3. Activate and install deps
& "$venvPath\Scripts\python.exe" -m pip install --upgrade pip
& "$venvPath\Scripts\python.exe" -m pip install -r "$ProjectRoot\requirements.txt"

# 4. Create data directories
$dirs = @("central_server\data", "evidence", "ml_service\models", "data")
foreach ($d in $dirs) {
    $p = Join-Path $ProjectRoot $d
    if (-not (Test-Path $p)) { New-Item -ItemType Directory -Path $p -Force | Out-Null }
}

# 5. Create .env template
$envFile = Join-Path $ProjectRoot ".env"
if (-not (Test-Path $envFile)) {
    @"
CMS_JWT_SECRET=change-me-in-production
COMMAND_SIGNING_KEY=change-me-in-production
ADMIN_USERNAME=admin
ADMIN_PASSWORD=admin123
CMS_HOST=0.0.0.0
CMS_PORT=9000
CMS_RELOAD=false
"@ | Set-Content -Path $envFile
    Write-Host "Created .env template - CHANGE DEFAULT CREDENTIALS" -ForegroundColor Yellow
}

# 6. Firewall rule
$ruleName = "SurakshaNetra CMS (9000)"
$existing = Get-NetFirewallRule -DisplayName $ruleName -ErrorAction SilentlyContinue
if (-not $existing) {
    New-NetFirewallRule -DisplayName $ruleName -Direction Inbound -Protocol TCP -LocalPort 9000 -Action Allow | Out-Null
    Write-Host "Added firewall rule for port 9000" -ForegroundColor Green
}

Write-Host "`n=== Install complete ===" -ForegroundColor Green
Write-Host "Run scripts\run.ps1 to start the CMS" -ForegroundColor Cyan
