import threading
import time
from typing import Dict, Callable, Optional

from .logging_setup import get_logger

logger = get_logger("health")


class ModuleState:
    def __init__(self, name: str):
        self.name = name
        self.alive = False
        self.consecutive_failures = 0
        self.last_check_time = 0.0
        self.restart_count = 0
        self.error: Optional[str] = None


class HealthMonitor:
    def __init__(
        self,
        check_interval: float = 15.0,
        max_consecutive_failures: int = 3,
        restart_delay: float = 2.0
    ):
        self._modules: Dict[str, ModuleState] = {}
        self._check_interval = check_interval
        self._max_consecutive_failures = max_consecutive_failures
        self._restart_delay = restart_delay
        self._restart_callbacks: Dict[str, Callable] = {}
        self._alive_checkers: Dict[str, Callable] = {}

        self._thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()

    def register_module(
        self,
        name: str,
        alive_checker: Callable[[], bool],
        restart_callback: Callable = None
    ):
        self._modules[name] = ModuleState(name)
        self._alive_checkers[name] = alive_checker
        if restart_callback:
            self._restart_callbacks[name] = restart_callback
        logger.info("Health monitor: registered module '%s'", name)

    def unregister_module(self, name: str):
        self._modules.pop(name, None)
        self._alive_checkers.pop(name, None)
        self._restart_callbacks.pop(name, None)

    def start(self):
        if self._thread and self._thread.is_alive():
            return
        self._stop_event.clear()
        self._thread = threading.Thread(target=self._run, name="health-monitor", daemon=True)
        self._thread.start()
        logger.info("Health monitor started (interval=%ds)", self._check_interval)

    def stop(self):
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=5)
        logger.info("Health monitor stopped")

    def _run(self):
        while not self._stop_event.wait(self._check_interval):
            for name, state in self._modules.items():
                self._check_module(name, state)

    def _check_module(self, name: str, state: ModuleState):
        checker = self._alive_checkers.get(name)
        if not checker:
            return

        try:
            alive = checker()
            state.last_check_time = time.time()

            if alive:
                if not state.alive:
                    logger.info("Module '%s' recovered", name)
                state.alive = True
                state.consecutive_failures = 0
                state.error = None
            else:
                state.alive = False
                state.consecutive_failures += 1
                state.error = "Module not responding"

                if state.consecutive_failures >= self._max_consecutive_failures:
                    logger.warning(
                        "Module '%s' failed %d consecutive checks. Restarting...",
                        name, state.consecutive_failures
                    )
                    self._restart_module(name, state)
        except Exception as e:
            state.alive = False
            state.consecutive_failures += 1
            state.error = str(e)
            logger.error("Health check error for '%s': %s", name, e)

            if state.consecutive_failures >= self._max_consecutive_failures:
                self._restart_module(name, state)

    def _restart_module(self, name: str, state: ModuleState):
        callback = self._restart_callbacks.get(name)
        if callback:
            try:
                logger.info("Restarting module '%s' (restart #%d)", name, state.restart_count + 1)
                time.sleep(self._restart_delay)
                callback()
                state.restart_count += 1
                state.consecutive_failures = 0
                state.alive = True
                logger.info("Module '%s' restarted successfully", name)
            except Exception as e:
                logger.error("Failed to restart module '%s': %s", name, e)
        else:
            logger.warning("No restart callback registered for module '%s'", name)

    def get_module_state(self, name: str) -> Optional[ModuleState]:
        return self._modules.get(name)

    def get_all_module_states(self) -> Dict[str, dict]:
        return {
            name: {
                "alive": state.alive,
                "consecutive_failures": state.consecutive_failures,
                "restart_count": state.restart_count,
                "error": state.error,
                "last_check": state.last_check_time
            }
            for name, state in self._modules.items()
        }

    def is_healthy(self) -> bool:
        if not self._modules:
            return False
        return any(state.alive for state in self._modules.values())
