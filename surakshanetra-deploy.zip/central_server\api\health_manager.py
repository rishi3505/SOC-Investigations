"""
Health Manager — Endpoint health tracking, scoring, and alerting.
Computes composite health scores from CPU, memory, disk, queue, heartbeat, and service metrics.
"""
import json
import time
from fastapi import APIRouter, Depends, HTTPException, Query
from ..database import get_connection
from ..auth import authenticate_request
from ..models import HealthSnapshotRequest

router = APIRouter(prefix="/api/v1/health", tags=["Health Manager"])


def compute_health_score(metrics: dict) -> float:
    score = 100.0
    cpu = metrics.get("cpu_percent", 0)
    if cpu > 80: score -= 25
    elif cpu > 60: score -= 15
    elif cpu > 40: score -= 5

    mem = metrics.get("memory_percent", 0)
    if mem > 80: score -= 20
    elif mem > 60: score -= 10

    disk = metrics.get("disk_percent", 0)
    if disk > 90: score -= 15
    elif disk > 75: score -= 8

    queue = metrics.get("queue_size", 0)
    if queue > 1000: score -= 20
    elif queue > 500: score -= 10
    elif queue > 100: score -= 5

    hb_delay = metrics.get("heartbeat_delay", 0)
    if hb_delay > 300: score -= 30
    elif hb_delay > 120: score -= 15
    elif hb_delay > 60: score -= 5

    return max(0, min(100, round(score, 1)))


def _get_health_category(score: float) -> str:
    if score >= 90: return "HEALTHY"
    if score >= 70: return "DEGRADED"
    if score >= 40: return "UNHEALTHY"
    return "CRITICAL"


@router.post("/snapshot/{endpoint_id}")
async def report_health(endpoint_id: str, payload: HealthSnapshotRequest, user: dict = Depends(authenticate_request)):
    conn = get_connection()
    now = int(time.time())
    metrics = {
        "cpu_percent": payload.cpu_percent,
        "memory_percent": payload.memory_percent or payload.memory_mb,
        "disk_percent": payload.disk_percent,
        "queue_size": payload.queue_size,
        "heartbeat_delay": payload.heartbeat_delay,
        "last_incident_age": 0,
        "ml_health": "OK",
        "db_health": "OK",
        "service_status": "RUNNING",
    }
    health_score = compute_health_score(metrics)

    conn.execute("""
        INSERT INTO endpoint_health_snapshots
            (endpoint_id, health_score, cpu_percent, memory_percent, disk_percent,
             queue_size, heartbeat_delay, last_incident_age, ml_health, db_health,
             service_status, metrics_json, timestamp)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (endpoint_id, health_score, metrics["cpu_percent"], metrics["memory_percent"],
          metrics["disk_percent"], metrics["queue_size"], metrics["heartbeat_delay"],
          metrics["last_incident_age"], metrics["ml_health"], metrics["db_health"],
          metrics["service_status"], json.dumps(metrics), now))

    conn.execute("UPDATE endpoints SET health_score = ?, health_updated_at = ? WHERE endpoint_id = ?",
                 (health_score, now, endpoint_id))

    category = _get_health_category(health_score)
    if category in ("UNHEALTHY", "CRITICAL"):
        try:
            conn.execute(
                "INSERT INTO notifications (endpoint_id, type, severity, message, created_at) VALUES (?, ?, ?, ?, ?)",
                (endpoint_id, "health_degraded", "HIGH",
                 f"Endpoint {endpoint_id} health score {health_score}% - {category}", now),
            )
        except Exception:
            pass

    conn.commit()
    conn.close()
    return {"status": "recorded", "health_score": health_score, "category": category}


@router.get("/snapshots/{endpoint_id}")
async def get_health_history(endpoint_id: str, limit: int = Query(50, ge=1, le=200), user: dict = Depends(authenticate_request)):
    conn = get_connection()
    rows = conn.execute(
        "SELECT * FROM endpoint_health_snapshots WHERE endpoint_id = ? ORDER BY timestamp DESC LIMIT ?",
        (endpoint_id, limit),
    ).fetchall()
    conn.close()
    return {"endpoint_id": endpoint_id, "snapshots": [dict(r) for r in rows]}


@router.get("/score/{endpoint_id}")
async def get_health_score(endpoint_id: str, user: dict = Depends(authenticate_request)):
    conn = get_connection()
    row = conn.execute(
        "SELECT health_score, health_updated_at, lifecycle_status, last_seen FROM endpoints WHERE endpoint_id = ?",
        (endpoint_id,),
    ).fetchone()
    conn.close()
    if not row:
        raise HTTPException(status_code=404, detail="Endpoint not found")
    ep = dict(row)
    return {
        "endpoint_id": endpoint_id,
        "health_score": ep.get("health_score", 100),
        "category": _get_health_category(ep.get("health_score", 100)),
        "updated_at": ep.get("health_updated_at"),
        "lifecycle_status": ep.get("lifecycle_status"),
        "last_seen": ep.get("last_seen"),
    }


@router.get("/overview")
async def health_overview(user: dict = Depends(authenticate_request)):
    conn = get_connection()
    now = int(time.time())
    rows = conn.execute("SELECT endpoint_id, health_score, last_seen, health_status FROM endpoints").fetchall()
    conn.close()
    healthy = degraded = unhealthy = critical = offline = 0
    scores = []
    for r in rows:
        ep = dict(r)
        score = ep.get("health_score", 100) or 100
        cat = _get_health_category(score)
        scores.append(score)
        if cat == "HEALTHY": healthy += 1
        elif cat == "DEGRADED": degraded += 1
        elif cat == "UNHEALTHY": unhealthy += 1
        elif cat == "CRITICAL": critical += 1
        if ep.get("last_seen") and (now - ep["last_seen"]) > 300:
            offline += 1
    avg_score = round(sum(scores) / max(len(scores), 1), 1) if scores else 100
    return {
        "health_distribution": {"healthy": healthy, "degraded": degraded, "unhealthy": unhealthy, "critical": critical, "offline": offline},
        "average_health_score": avg_score,
        "total_endpoints": len(rows),
    }
