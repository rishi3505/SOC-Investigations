from ml_service.anomaly_model import get_model_instance

model_instance = get_model_instance()
_user_session_state: dict = {}
RECORDS_SINCE_LAST_TRAIN = 0
TRAIN_THRESHOLD = 500
PASSIVE_APPS = ["YouTube", "Netflix", "VLC", "Chrome", "PDF Reader", "Zoom", "Teams", "Video Player"]
