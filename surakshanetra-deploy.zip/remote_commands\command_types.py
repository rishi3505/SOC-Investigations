"""
Command type definitions for remote endpoint management.
"""
from dataclasses import dataclass, field
from typing import Optional


COMMAND_REGISTRY = {
    "REFRESH_CONFIG": {
        "label": "Refresh Configuration",
        "description": "Force endpoint to re-fetch its configuration profile",
        "category": "configuration",
        "requires_ack": True,
        "timeout_seconds": 60,
    },
    "RESTART_AGENT": {
        "label": "Restart Agent",
        "description": "Restart the entire endpoint agent service",
        "category": "agent",
        "requires_ack": True,
        "timeout_seconds": 120,
    },
    "RESTART_MONITORING": {
        "label": "Restart Monitoring",
        "description": "Restart the behavioral monitoring subsystem",
        "category": "monitoring",
        "requires_ack": True,
        "timeout_seconds": 60,
    },
    "RESTART_ML_ENGINE": {
        "label": "Restart ML Engine",
        "description": "Restart the local ML inference engine",
        "category": "ml",
        "requires_ack": True,
        "timeout_seconds": 60,
    },
    "COLLECT_EVIDENCE": {
        "label": "Collect Immediate Evidence",
        "description": "Collect forensic evidence snapshot and upload to CMS",
        "category": "forensics",
        "requires_ack": True,
        "timeout_seconds": 300,
    },
    "START_THREAT_HUNT": {
        "label": "Start Threat Hunt",
        "description": "Run detection rules against local behavior data and report findings",
        "category": "hunting",
        "requires_ack": True,
        "timeout_seconds": 300,
    },
    "TRIGGER_HEALTH_CHECK": {
        "label": "Trigger Health Check",
        "description": "Run a comprehensive health check and report results",
        "category": "health",
        "requires_ack": True,
        "timeout_seconds": 60,
    },
    "FORCE_POLICY_SYNC": {
        "label": "Force Policy Sync",
        "description": "Force the endpoint to synchronize policies from CMS",
        "category": "policy",
        "requires_ack": True,
        "timeout_seconds": 60,
    },
    "UPDATE_THREAT_INTEL": {
        "label": "Update Threat Intelligence",
        "description": "Force refresh of local IOC database and detection rules",
        "category": "threat_intel",
        "requires_ack": True,
        "timeout_seconds": 120,
    },
    "FLUSH_LOCAL_QUEUE": {
        "label": "Flush Local Queue",
        "description": "Flush all pending data from the local retry queue to CMS",
        "category": "data",
        "requires_ack": True,
        "timeout_seconds": 120,
    },
    "RE_REGISTER": {
        "label": "Re-register Device",
        "description": "Re-register the endpoint with CMS (generates new device ID)",
        "category": "lifecycle",
        "requires_ack": True,
        "timeout_seconds": 60,
    },
    "REQUEST_INVENTORY": {
        "label": "Request Device Inventory",
        "description": "Collect and upload full device hardware/software inventory",
        "category": "inventory",
        "requires_ack": True,
        "timeout_seconds": 300,
    },
    "INSTALL_UPDATE": {
        "label": "Install Agent Update",
        "description": "Download and install the pending agent update",
        "category": "update",
        "requires_ack": True,
        "timeout_seconds": 600,
    },
    "ROLLBACK_UPDATE": {
        "label": "Rollback Agent Update",
        "description": "Roll back agent to the previous version",
        "category": "update",
        "requires_ack": True,
        "timeout_seconds": 600,
    },
}

COMMAND_CATEGORIES = frozenset(
    cmd["category"] for cmd in COMMAND_REGISTRY.values()
)


def get_command_info(command_type: str) -> Optional[dict]:
    return COMMAND_REGISTRY.get(command_type)


def list_command_types(category: Optional[str] = None) -> list[dict]:
    result = []
    for ctype, info in COMMAND_REGISTRY.items():
        if category and info["category"] != category:
            continue
        result.append({"command_type": ctype, **info})
    return result


TARGET_TYPES = frozenset({"endpoint", "group", "all"})


@dataclass
class RemoteCommand:
    command_type: str
    target_type: str = "endpoint"
    target_ids: list = field(default_factory=list)
    payload: dict = field(default_factory=dict)
    priority: int = 0
    issued_by: str = "admin"
    expires_in_seconds: Optional[int] = None

    def validate(self) -> Optional[str]:
        if self.command_type not in COMMAND_REGISTRY:
            return f"Unknown command type: {self.command_type}"
        if self.target_type not in TARGET_TYPES:
            return f"Invalid target type: {self.target_type}"
        if not self.target_ids and self.target_type != "all":
            return "target_ids required for endpoint/group targets"
        return None
