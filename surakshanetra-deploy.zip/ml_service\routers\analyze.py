import json
import os
import sys
import asyncio

sys.path.append(os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.append(os.path.join(os.path.dirname(__file__), ".."))

from fastapi import APIRouter, HTTPException, BackgroundTasks
from pydantic import BaseModel

from backend.db import (
    insert_behavior, check_trusted_session, get_user_thresholds,
    insert_feedback, check_location_trust,
    get_sample_count, increment_sample_count, add_session_risk, get_session_history,
    insert_incident, insert_response_history, insert_policy_audit,
    register_device, update_device_last_seen, check_device_trust, insert_device_history,
)
from backend.response_engine import (
    evaluate as response_evaluate,
    create_incident as engine_create_incident,
)
from backend.containment_engine import execute_containment
from ml_service.state import model_instance, _user_session_state, PASSIVE_APPS
from ml_service.train import train_model

router = APIRouter()


class BehaviorPayload(BaseModel):
    typing_speed: float
    key_latency: float
    avg_hold_time: float
    latency_jitter: float
    mouse_speed: float
    mouse_acceleration: float
    direction_change_freq: float
    click_frequency: float
    active_app: str
    app_switch_count: int
    idle_time: float
    time_of_day: float
    user_id: str = "default_user"
    ip_address: str = "Unknown"
    city: str = "Unknown"
    country: str = "Unknown"
    is_new_location: bool = False
    device_hash: str = ""
    device_hostname: str = ""
    device_os_version: str = ""
    device_windows_build: str = ""
    device_architecture: str = ""
    device_change_score: float = 0.0
    device_trust_status: str = "UNKNOWN"


def calculate_aggregated_risk(user_id, current_result, samples_total):
    history = get_session_history(user_id, limit=20)
    if history.empty:
        return current_result["risk_score"], "LOW", "ALLOW", "Initial window."
    state_label = "PROTECTED"
    if samples_total < 200:
        state_label = "LEARNING"
    elif samples_total < 500:
        state_label = "MONITORING"
    short_term = history.head(5)
    long_term = history.head(20)
    total_anomalies_st = short_term["is_anomalous"].sum()
    consecutive_anomalies = 0
    for val in history["is_anomalous"]:
        if val:
            consecutive_anomalies += 1
        else:
            break
    normal_streak = 0
    for val in history["is_anomalous"]:
        if not val:
            normal_streak += 1
        else:
            break
    st_avg = short_term["risk_score"].mean()
    lt_avg = long_term["risk_score"].mean()
    rolling_score = (st_avg * 0.7) + (lt_avg * 0.3)
    raw_rolling_score = rolling_score
    risk_level = "LOW"
    action = "ALLOW"
    sig = current_result.get("significance", {})
    strong_total = sig.get("strong_count", 0)
    weak_total = sig.get("weak_count", 0)
    extreme_total = sig.get("extreme_count", 0)
    has_consensus = (strong_total + weak_total >= 2) or (extreme_total >= 1)
    if has_consensus:
        if total_anomalies_st >= 4 or (len(long_term) >= 10 and long_term["is_anomalous"].sum() >= 6):
            risk_level = "HIGH"
            action = "BLOCK"
        elif consecutive_anomalies >= 3 or total_anomalies_st >= 2:
            risk_level = "MEDIUM"
            action = "VERIFY"
        elif total_anomalies_st >= 1:
            risk_level = "LOW"
            action = "ALLOW"
    else:
        risk_level = "LOW"
        action = "ALLOW"
        if raw_rolling_score > 50:
            pass
    if normal_streak >= 3:
        decay_factor = 0.875 ** (normal_streak - 2)
        rolling_score *= decay_factor
        if risk_level == "HIGH":
            risk_level = "MEDIUM"
            action = "VERIFY"
        if normal_streak >= 5:
            risk_level = "LOW"
            action = "ALLOW"
    confidence = current_result.get("confidence_score", 1.0)
    if confidence < 0.4 and risk_level == "HIGH":
        risk_level = "MEDIUM"
        action = "VERIFY"
    if state_label == "LEARNING":
        risk_level = "LOW"
        action = "ALLOW"
        reason = "System in Learning Mode (Collecting Baseline)."
    elif state_label == "MONITORING":
        if risk_level in ["HIGH", "MEDIUM"]:
            risk_level = "LOW"
            action = "ALLOW"
            reason = f"Monitoring active. Suspected {risk_level} anomaly detected, but not enforced yet."
        else:
            reason = current_result["reason"]
    else:
        reason = current_result["reason"]
    return round(rolling_score, 2), risk_level, action, reason


def retrain_model_task():
    global model_instance
    print("Starting background retraining...")
    from ml_service.train import train_model as _train
    success = _train()
    if success:
        print("Retraining successful. Reloading model.")
        from ml_service.state import model_instance as mi
        from ml_service.anomaly_model import get_model_instance
        import ml_service.state as _state
        _state.model_instance = get_model_instance()
    else:
        print("Retraining failed or skipped due to insufficient data.")


@router.post("/api/v1/analyze")
async def analyze_behavior(payload: BehaviorPayload, background_tasks: BackgroundTasks):
    data = payload.model_dump()
    user_id = data.get("user_id", "default_user")
    increment_sample_count(user_id)
    samples_total = get_sample_count(user_id)
    behavior_data = {k: v for k, v in data.items() if not k.startswith("device_") and k != "device_change_score" and k != "device_trust_status"}
    insert_behavior(behavior_data)
    if samples_total % 200 == 0:
        background_tasks.add_task(retrain_model_task)
    thresholds = get_user_thresholds(user_id)
    raw_result = model_instance.predict(data, user_id=user_id, thresholds=thresholds)
    add_session_risk(user_id, raw_result["risk_score"], raw_result["is_anomalous"])
    final_score, final_level, final_action, final_reason = calculate_aggregated_risk(user_id, raw_result, samples_total)
    if user_id not in _user_session_state:
        _user_session_state[user_id] = {"consecutive_anomalies": 0, "system_state": "NORMAL", "last_incident_id": None, "has_recent_mfa": False, "positive_feedback_count": 0}
    state = _user_session_state[user_id]
    is_anomalous = raw_result.get("is_anomalous", False)
    if is_anomalous:
        state["consecutive_anomalies"] += 1
    else:
        state["consecutive_anomalies"] = 0
    sig = raw_result.get("significance", {})
    deviating_features = sig.get("deviating_features", [])
    is_trusted_session = check_trusted_session(user_id)
    is_trusted_location = check_location_trust(user_id, data.get("city", ""), data.get("country", ""))
    is_new_location = data.get("is_new_location", False)
    device_hash = data.get("device_hash", "")
    unknown_device = False
    device_fingerprint_changed = False
    device_hardware_change_score = data.get("device_change_score", 0.0)
    trusted_device = False
    device_trust_info = None
    if device_hash:
        device_trust_info = check_device_trust(device_hash)
        if device_trust_info is None:
            register_device({"device_hash": device_hash, "hostname": data.get("device_hostname", ""), "os_version": data.get("device_os_version", ""), "windows_build": data.get("device_windows_build", ""), "user_id": user_id})
            unknown_device = True
        else:
            update_device_last_seen(device_hash)
            trusted_device = device_trust_info.get("trusted", False)
            device_fingerprint_changed = device_hardware_change_score >= 60
            if device_hardware_change_score >= 20:
                insert_device_history({"device_hash": device_hash, "event_type": "HARDWARE_CHANGE", "details": json.dumps({"change_score": device_hardware_change_score, "timestamp": int(__import__("time").time())})})
    response_result = response_evaluate(risk_score=final_score, confidence=raw_result.get("confidence_score", 0.5), deviating_features=deviating_features, significance=sig, is_new_location=is_new_location, is_trusted_location=is_trusted_location, is_trusted_session=is_trusted_session, consecutive_anomalies=state["consecutive_anomalies"], has_positive_feedback=state["positive_feedback_count"] > 0, has_recent_mfa=state["has_recent_mfa"], has_failed_mfa=False, device_mismatch=unknown_device, unknown_device=unknown_device, device_fingerprint_changed=device_fingerprint_changed, device_hardware_change_score=device_hardware_change_score, trusted_device=trusted_device, current_system_state=state["system_state"], user_id=user_id)
    state["system_state"] = response_result["system_state"]
    incident_id = None
    if response_result.get("policy_matched"):
        insert_policy_audit({"policy_id": response_result["policy_matched"], "policy_name": response_result.get("recommendation", {}).get("possible_attack", ""), "user_id": user_id, "risk_score": final_score, "confidence": raw_result.get("confidence_score", 0), "matched": True, "action_taken": response_result["action"], "details": json.dumps(response_result)})
    if response_result.get("action") in ("STEP_UP_AUTH", "LOCK_SESSION", "RESTRICT") or response_result.get("risk_level_num", 0) >= 3:
        if state.get("last_incident_id") is None:
            incident_id = engine_create_incident(user_id=user_id, session_id=None, evaluation=response_result)
            state["last_incident_id"] = incident_id
            incident_data = {"incident_id": incident_id, "user_id": user_id, "session_id": f"SESS-{user_id}", "risk_score": final_score, "confidence": raw_result.get("confidence_score", 0), "evidence_score": response_result.get("evidence_score", 0), "severity": response_result.get("risk_level", "MEDIUM"), "status": "OPEN", "mitre_technique": response_result.get("mitre_technique", {}).get("technique_id", ""), "mitre_technique_name": response_result.get("mitre_technique", {}).get("technique_name", ""), "mitre_tactic": response_result.get("mitre_technique", {}).get("tactic", ""), "recommended_action": response_result.get("action", ""), "reason_json": json.dumps(response_result.get("recommendation", {})), "response_level": response_result.get("response_level", 0), "system_state": response_result.get("system_state", "NORMAL")}
            insert_incident(incident_data)
            severity = response_result.get("risk_level", "MEDIUM")
            if severity in ("HIGH", "CRITICAL"):
                background_tasks.add_task(lambda: asyncio.create_task(execute_containment(incident=incident_data, risk_score=final_score, evidence_score=response_result.get("evidence_score", 0), confidence=raw_result.get("confidence_score", 0), policy_decision=response_result)))
                response_result["containment_triggered"] = True
    insert_response_history({"user_id": user_id, "session_id": f"SESS-{user_id}", "risk_score": final_score, "confidence": raw_result.get("confidence_score", 0), "evidence_score": response_result.get("evidence_score", 0), "action_taken": response_result["action"], "response_level": response_result.get("response_level", 0), "system_state": response_result.get("system_state", "NORMAL"), "policy_id": response_result.get("policy_matched"), "incident_id": incident_id or state.get("last_incident_id"), "reasoning": json.dumps(response_result.get("recommendation", {}))})
    return {"risk_score": final_score, "risk_level": final_level, "action": final_action, "reason": final_reason, "confidence": raw_result.get("confidence_score"), "lifecycle_stage": "PROTECTED" if samples_total > 500 else ("MONITORING" if samples_total > 200 else "LEARNING"), "samples_collected": samples_total, "device_info": {"device_hash": device_hash[:16] + "..." if device_hash else None, "trusted": trusted_device, "unknown_device": unknown_device, "hardware_changed": device_fingerprint_changed, "change_score": device_hardware_change_score, "trust_status": device_trust_info.get("trust_status", "UNKNOWN") if device_trust_info else "UNKNOWN"} if device_hash else None, "response_engine": {"risk_level": response_result["risk_level"], "system_state": response_result["system_state"], "evidence_score": response_result["evidence_score"], "evidence_breakdown": response_result["evidence_breakdown"], "action": response_result["action"], "response_level": response_result["response_level"], "consecutive_anomalies": response_result["consecutive_anomalies"], "mitre_technique": response_result["mitre_technique"], "recommendation": response_result["recommendation"], "incident_id": state.get("last_incident_id") if response_result.get("risk_level_num", 0) >= 3 else None, "policy_matched": response_result.get("policy_matched")}}
