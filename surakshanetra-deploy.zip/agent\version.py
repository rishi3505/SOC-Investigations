import json
import os
import uuid
import time

_CONFIG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config.json")

_AGENT_VERSION = "1.0.0"
_BUILD_NUMBER = 1
_DEVICE_ID = None


def _load_config():
    if os.path.exists(_CONFIG_PATH):
        try:
            with open(_CONFIG_PATH, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            return {}
    return {}


def _save_config(config: dict):
    os.makedirs(os.path.dirname(_CONFIG_PATH), exist_ok=True)
    with open(_CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=4)


def get_device_id() -> str:
    global _DEVICE_ID
    if _DEVICE_ID:
        return _DEVICE_ID

    config = _load_config()
    agent_cfg = config.get("agent", {})

    device_id = agent_cfg.get("device_id")
    if not device_id:
        device_id = uuid.uuid4().hex[:16].upper()
        agent_cfg["device_id"] = device_id
        config["agent"] = agent_cfg
        _save_config(config)

    _DEVICE_ID = device_id
    return _DEVICE_ID


def get_agent_version() -> str:
    config = _load_config()
    return config.get("agent", {}).get("version", _AGENT_VERSION)


def get_build_number() -> int:
    config = _load_config()
    return int(config.get("agent", {}).get("build", _BUILD_NUMBER))


def get_install_date() -> str:
    config = _load_config()
    install_date = config.get("agent", {}).get("install_date")
    if not install_date:
        install_date = time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime())
        config.setdefault("agent", {})["install_date"] = install_date
        _save_config(config)
    return install_date


def get_last_update() -> str:
    config = _load_config()
    return config.get("agent", {}).get("last_update", "N/A")


def set_last_update(timestamp: str = None):
    if not timestamp:
        timestamp = time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime())
    config = _load_config()
    config.setdefault("agent", {})["last_update"] = timestamp
    _save_config(config)


def get_version_info() -> dict:
    return {
        "agent_version": get_agent_version(),
        "build_number": get_build_number(),
        "install_date": get_install_date(),
        "last_update": get_last_update(),
        "device_id": get_device_id(),
        "hostname": __import__("platform", fromlist=["node"]).node()
    }
