# SurakshaNetra — Threat Model

## Version 1.0 — RC1

---

## 1. System Overview

SurakshaNetra is a continuous authentication platform with three tiers:
- **Agent**: Windows service collecting behavioral biometrics and system telemetry
- **CMS**: Central Management Server — FastAPI backend with SQLite
- **SOC Dashboard**: React + TailwindCSS frontend

## 2. Assets

| ID | Asset | Sensitivity | Location |
|----|-------|-------------|----------|
| A-1 | JWT signing key | CRITICAL | `central_server/config.py` (env var) |
| A-2 | Command signing key | CRITICAL | `remote_commands/command_engine.py` (env var) |
| A-3 | API keys (per-user) | HIGH | `central.db` — `users.api_key` |
| A-4 | User behavioral data | HIGH | `behavior.db` — `behavior_data` table |
| A-5 | Password hashes | HIGH | `central.db` — `users.password_hash` |
| A-6 | Session tokens (JWT) | HIGH | In-memory / HTTP headers |
| A-7 | Incident/forensic evidence | HIGH | `evidence/` directory on CMS |
| A-8 | Agent configuration | MEDIUM | `agent/config.json` |
| A-9 | Policy definitions | MEDIUM | CMS `policies` table |
| A-10 | ML model files | MEDIUM | `ml_service/models/*.pkl` |
| A-11 | IOC database | MEDIUM | `threat_intelligence/ioc_store.db` |
| A-12 | Audit logs | MEDIUM | `audit_logs` / `audit_logs_extended` tables |
| A-13 | Endpoint inventory | MEDIUM | `inventories` table |
| A-14 | Remote command payloads | MEDIUM | `remote_commands` table |

## 3. Actors

| ID | Actor | Description | Privilege Level |
|----|-------|-------------|-----------------|
| ACT-1 | End-User (Behavior Subject) | Person being monitored | NONE (no direct system access) |
| ACT-2 | SOC Analyst | Views dashboards, reviews incidents | LOW (read + acknowledge) |
| ACT-3 | SOC Admin | Manages endpoints, policies, configs | HIGH (read/write) |
| ACT-4 | System Admin | Installs/manages CMS server | FULL (server-level) |
| ACT-5 | Agent Process | Windows service on endpoint | RESTRICTED (send-only) |
| ACT-6 | External Attacker | Unauthorized network/application access | NONE |

## 4. Trust Boundaries

```
[Internet / WAN]
    |
    | HTTPS (TLS)
    v
[SOC Dashboard] <--> [CMS API] <--> [SQLite Databases]
    ^                    |
    | HTTPS             | HTTPS
    |                   v
    |              [Agent Process] (endpoint)
    |
    +--- Browser Sandbox
```

| ID | Boundary | Trust Level | Data Flow |
|----|----------|-------------|-----------|
| TB-1 | Agent ↔ CMS | UNTRUSTED | Behavioral data, heartbeats, commands |
| TB-2 | Dashboard ↔ CMS | UNTRUSTED | Dashboards, admin actions |
| TB-3 | CMS ↔ SQLite | TRUSTED | Local file-system access |
| TB-4 | CMS ↔ ML Service | LOCAL | HTTP on localhost |
| TB-5 | CMS ↔ Filesystem | TRUSTED | Evidence storage |

## 5. Threats (STRIDE per Component)

### 5.1 CMS API Server

| Threat | STRIDE Category | Likelihood | Impact | Mitigation |
|--------|----------------|------------|--------|------------|
| JWT forgery via weak secret | Spoofing | LOW | CRITICAL | Auto-generated 64-char hex secret via `secrets.token_hex(32)` |
| JWT replay | Tampering | MEDIUM | HIGH | Token expiry (24h default), no refresh token rotation |
| API key brute-force | Spoofing | LOW | HIGH | API keys are 64-char random hex |
| SQL injection via behavior data | Tampering | MEDIUM | HIGH | All queries parameterized except `insert_behavior` (f-string column names) |
| Path traversal in evidence download | Tampering | MEDIUM | HIGH | Path canonicalization + prefix check against evidence base dir |
| Stack trace disclosure | Info Disclosure | LOW | MEDIUM | Global exception handler returns `{"detail": str(exc)}` (no traceback) |
| Unauthenticated access to admin APIs | Elevation of Privilege | LOW | CRITICAL | All 108 endpoints have `Depends(authenticate_request)` |
| CORS misconfiguration | Info Disclosure | LOW | MEDIUM | Fixed: explicit origins from env var, wildcard removed |
| Rate limiting | DoS | MEDIUM | MEDIUM | No rate limiting implemented |

### 5.2 Agent Process

| Threat | STRIDE Category | Likelihood | Impact | Mitigation |
|--------|----------------|------------|--------|------------|
| Config file tampering | Tampering | MEDIUM | MEDIUM | Config read-only at runtime, deep-merged with secure defaults |
| Queue DB poisoning | Tampering | LOW | LOW | SQLite WAL mode, local-only access |
| Command injection via wevtutil | Tampering | LOW | HIGH | Fixed: `subprocess` list form replaces `shell=True` |
| Offline queue overflow | DoS | LOW | LOW | `max_buffer_size: 5000` configurable |
| pynput listener hijacking | Elevation of Privilege | LOW | MEDIUM | Listener runs as current user, no privilege escalation |

### 5.3 SOC Dashboard (React)

| Threat | STRIDE Category | Likelihood | Impact | Mitigation |
|--------|----------------|------------|--------|------------|
| XSS via API response | Information Disclosure | MEDIUM | HIGH | React JSX auto-escapes; no `dangerouslySetInnerHTML` usage |
| JWT stored in localStorage | Information Disclosure | MEDIUM | HIGH | JWT in `Authorization` header, not persisted |
| CSP bypass | Information Disclosure | LOW | MEDIUM | CSP policy recommended but not enforced in build |
| API key leak in client bundle | Information Disclosure | LOW | HIGH | API keys only used server-side (CMS auth) |

### 5.4 Threat Intelligence Module

| Threat | STRIDE Category | Likelihood | Impact | Mitigation |
|--------|----------------|------------|--------|------------|
| Malicious IOC feed data | Tampering | MEDIUM | HIGH | Feeds fetched over HTTPS, JSON parsed safely |
| IOC DB corruption | DoS | LOW | LOW | `CREATE TABLE IF NOT EXISTS`, WAL mode |
| Feed manager SSRF | Information Disclosure | LOW | MEDIUM | URLs from config, validated feed list |

### 5.5 ML Service

| Threat | STRIDE Category | Likelihood | Impact | Mitigation |
|--------|----------------|------------|--------|------------|
| Model poisoning via training data | Tampering | LOW | HIGH | Only authorized behavior data; no external training data accepted |
| Pickle deserialization | Tampering | LOW | HIGH | `joblib.load()` on local model files only |
| Model file tampering | Tampering | LOW | HIGH | Models stored in `ml_service/models/`, read-only at runtime |

### 5.6 Forensics Module

| Threat | STRIDE Category | Likelihood | Impact | Mitigation |
|--------|----------------|------------|--------|------------|
| Path traversal in evidence collection | Tampering | MEDIUM | HIGH | Fixed: `incident_id` sanitized with regex `[^a-zA-Z0-9_\-]` |
| Symlink attack on evidence files | Tampering | LOW | HIGH | Evidence dir is controlled; no symlink creation by system |

## 6. Data Flow Diagrams

### 6.1 Behavior Data Flow
```
Agent Collector -> [Offline Queue] -> HTTP POST /api/v1/analyze -> CMS
    |                                                              |
    | pynput/psutil                                                +-> ML Service (localhost:8000)
    +-> CSV fallback                                               +-> SQLite behavior.db
```

### 6.2 Remote Command Flow
```
SOC Admin -> Dashboard -> CMS POST /api/v1/commands/issue
    |
    +-> HMAC-SHA256 sign -> INSERT remote_commands
    |
    v
Agent Polls -> GET /api/v1/commands/agent/poll
    |
    +-> POST /agent/acknowledge
    +-> POST /agent/complete
```

### 6.3 Authentication Flow
```
User -> POST /api/v1/auth/login -> JWT issued
    |
    +-> Subsequent requests: Authorization: Bearer <JWT>
    +-> API key alternative: X-API-Key header
```

## 7. Residual Risks

| Risk | Severity | Rationale |
|------|----------|-----------|
| No rate limiting | MEDIUM | All CMS endpoints lack request rate limits; DoS possible from authenticated users |
| No account lockout | MEDIUM | Login endpoint has no brute-force protection |
| No refresh tokens | LOW | JWT expiry is 24h with no rotation mechanism |
| SQLite not encrypted at rest | MEDIUM | Database files are plaintext on disk |
| No audit on login failures | LOW | Successful logins logged; failures not tracked |
| Password hashing uses SHA-256 | MEDIUM | Should use bcrypt/argon2 for password storage |
| No certificate pinning | LOW | Agent trusts system CA store for HTTPS |
| No HSTS header | LOW | Not configured on CMS or dashboard |
