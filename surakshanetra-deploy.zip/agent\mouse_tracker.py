import math
import time
import threading
from pynput import mouse

class MouseMonitor:
    """
    Monitors precise mouse traversal statistics and coordinates along with
    actionable idle tracking indicators.
    """
    def __init__(self):
        self.lock = threading.Lock()
        self.last_pos = None
        self.total_distance = 0.0
        self.click_count = 0
        self.last_activity = time.time()
        
        # New metrics
        self.velocities = []
        self.accelerations = []
        self.direction_changes = 0
        self.last_angle = None
        self.last_time = time.time()
        
        self.listener = mouse.Listener(
            on_move=self.on_move,
            on_click=self.on_click
        )
        
    def start(self):
        self.listener.start()
        
    def stop(self):
        self.listener.stop()
        
    def on_move(self, x, y):
        current_time = time.time()
        with self.lock:
            self.last_activity = current_time
            if self.last_pos is not None:
                dx = x - self.last_pos[0]
                dy = y - self.last_pos[1]
                dist = math.sqrt(dx*dx + dy*dy)
                self.total_distance += dist
                
                dt = current_time - self.last_time
                if dt > 0:
                    v = dist / dt
                    if self.velocities:
                        dv = v - self.velocities[-1]
                        self.accelerations.append(dv / dt)
                    self.velocities.append(v)
                    
                    # Direction change logic (Angle shift > ~45 degrees)
                    angle = math.atan2(dy, dx)
                    if self.last_angle is not None:
                        diff = abs(angle - self.last_angle)
                        if diff > 0.8: # ~45 degrees
                            self.direction_changes += 1
                    self.last_angle = angle
            
            self.last_pos = (x, y)
            self.last_time = current_time
            
    def on_click(self, x, y, button, pressed):
        current_time = time.time()
        if pressed:
            with self.lock:
                self.last_activity = current_time
                self.click_count += 1
                
    def get_metrics_and_reset(self):
        with self.lock:
            avg_accel = sum(self.accelerations) / len(self.accelerations) if self.accelerations else 0.0
            
            metrics = {
                "mouse_distance": self.total_distance,
                "mouse_acceleration": avg_accel,
                "direction_change_freq": self.direction_changes,
                "click_count": self.click_count,
                "last_activity": self.last_activity
            }
            
            self.total_distance = 0.0
            self.click_count = 0
            self.velocities.clear()
            self.accelerations.clear()
            self.direction_changes = 0
            self.last_angle = None
            
            return metrics
