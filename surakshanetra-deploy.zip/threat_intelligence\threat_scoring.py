"""
Threat Scoring — Computes a unified threat score by combining:
- Behavioral risk score (from ML model)
- Threat intelligence score (from IOC matches)
- Device trust, location trust, baseline, detection rules
"""
from dataclasses import dataclass
from typing import Optional


@dataclass
class ThreatScoreComponents:
    behavior_score: float = 0.0
    threat_intel_score: float = 0.0
    device_trust_score: float = 50.0
    location_trust_score: float = 50.0
    baseline_deviation: float = 0.0
    detection_rule_matches: int = 0
    detection_rule_avg_severity: float = 0.0

    @property
    def has_threat_intel(self) -> bool:
        return self.threat_intel_score > 0


class ThreatScoringEngine:
    WEIGHTS = {
        "behavior": 0.30, "threat_intel": 0.25, "device_trust": 0.10,
        "location_trust": 0.10, "baseline": 0.15, "detection_rules": 0.10,
    }

    def __init__(self, weights: Optional[dict] = None):
        if weights:
            self.WEIGHTS = {**self.WEIGHTS, **weights}

    def compute(self, components: ThreatScoreComponents) -> dict:
        raw_score = (
            components.behavior_score * self.WEIGHTS["behavior"]
            + components.threat_intel_score * self.WEIGHTS["threat_intel"]
            + (100 - components.device_trust_score) * self.WEIGHTS["device_trust"]
            + (100 - components.location_trust_score) * self.WEIGHTS["location_trust"]
            + components.baseline_deviation * self.WEIGHTS["baseline"]
            + self._rule_contribution(components) * self.WEIGHTS["detection_rules"]
        )
        raw_score = min(100, max(0, raw_score))
        return {
            "final_score": round(raw_score, 2),
            "threat_level": self._classify(raw_score),
            "severity": self._severity_from_score(raw_score),
            "confidence": round(self._compute_confidence(components), 4),
            "components": {
                "behavior_score": components.behavior_score,
                "threat_intel_score": components.threat_intel_score,
                "device_trust_score": components.device_trust_score,
                "location_trust_score": components.location_trust_score,
                "baseline_deviation": components.baseline_deviation,
                "detection_rule_matches": components.detection_rule_matches,
            },
            "weights_applied": dict(self.WEIGHTS),
        }

    def _rule_contribution(self, c: ThreatScoreComponents) -> float:
        if c.detection_rule_matches == 0:
            return 0.0
        base = c.detection_rule_avg_severity * 20
        return min(100, base * (1 + 0.1 * (c.detection_rule_matches - 1)))

    def _classify(self, score: float) -> str:
        if score >= 80: return "CRITICAL"
        if score >= 60: return "HIGH"
        if score >= 40: return "SUSPICIOUS"
        if score >= 20: return "MEDIUM"
        return "LOW"

    def _severity_from_score(self, score: float) -> str:
        if score >= 80: return "CRITICAL"
        if score >= 60: return "HIGH"
        if score >= 35: return "MEDIUM"
        return "LOW"

    def _compute_confidence(self, c: ThreatScoreComponents) -> float:
        base = 0.5
        if c.threat_intel_score > 0: base += 0.25
        if c.device_trust_score < 30: base += 0.1
        if c.detection_rule_matches >= 2: base += 0.1
        if c.baseline_deviation > 50: base += 0.05
        return min(0.99, base)


_threat_scoring = ThreatScoringEngine()


def get_threat_scoring() -> ThreatScoringEngine:
    return _threat_scoring


def compute_threat_score(components: ThreatScoreComponents) -> dict:
    return _threat_scoring.compute(components)
