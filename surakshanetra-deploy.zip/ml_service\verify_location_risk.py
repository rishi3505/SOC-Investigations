import requests
import json

BASE_URL = "http://127.0.0.1:8000"

def test_location_risk(is_new_location, is_anomalous=False):
    print(f"\n--- Testing Location Risk (New: {is_new_location}, Behavioral Anomaly: {is_anomalous}) ---")
    
    # Base normal payload
    payload = {
        "typing_speed": 55.0,
        "key_latency": 0.12,
        "avg_hold_time": 0.08,
        "mouse_speed": 350.0,
        "click_frequency": 1.2,
        "active_app": "VSCode",
        "app_switch_count": 1,
        "idle_time": 1.0,
        "time_of_day": 14,
        "session_duration": 120.0,
        "user_id": "default_user",
        "ip_address": "1.2.3.4",
        "city": "London",
        "country": "UK",
        "is_new_location": is_new_location
    }
    
    if is_anomalous:
        # Trigger behavioral anomaly
        payload["typing_speed"] = 250.0
        payload["click_frequency"] = 25.0
        
    response = requests.post(f"{BASE_URL}/api/v1/analyze", json=payload)
    print(f"Status Code: {response.status_code}")
    print(json.dumps(response.json(), indent=2))

if __name__ == "__main__":
    try:
        # Scenario 1: Known location
        test_location_risk(is_new_location=False)
        
        # Scenario 2: New location (Moderate risk)
        test_location_risk(is_new_location=True)
        
        # Scenario 3: New location + Behavioral Anomaly (Significant risk)
        test_location_risk(is_new_location=True, is_anomalous=True)
        
    except requests.exceptions.ConnectionError:
        print("\n[ERROR] API not reachable.")
