import hashlib
import json
import os
import socket
import sys
import time
import uuid


class ChainOfCustody:
    def __init__(self, incident_id: str, collector: str = "ForensicCollector"):
        self.case_id = f"CASE-{uuid.uuid4().hex[:8].upper()}-{int(time.time())}"
        self.incident_id = incident_id
        self.collector = collector
        self.collection_time = int(time.time())
        self.hostname = socket.gethostname()
        self.device_id = self._get_device_id()
        self.events = []
        self.hashes = {}

    def _get_device_id(self) -> str:
        try:
            if os.path.exists(os.path.join(os.path.dirname(__file__), "..", "agent", "version.py")):
                sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
                from agent.version import DEVICE_ID
                return DEVICE_ID
        except (ImportError, AttributeError):
            pass
        return hashlib.sha256(
            f"{self.hostname}-{os.environ.get('COMPUTERNAME', 'unknown')}".encode()
        ).hexdigest()[:16]

    def record_event(self, event_type: str, description: str, details: dict = None):
        self.events.append({
            "timestamp": int(time.time()),
            "event_type": event_type,
            "description": description,
            "details": details or {},
        })

    def add_hash(self, file_path: str, relative_path: str = None):
        if not os.path.exists(file_path):
            return
        sha256 = hashlib.sha256()
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                sha256.update(chunk)
        key = relative_path or os.path.basename(file_path)
        self.hashes[key] = sha256.hexdigest()

    def to_dict(self) -> dict:
        return {
            "case_id": self.case_id,
            "incident_id": self.incident_id,
            "collector": self.collector,
            "collection_time": self.collection_time,
            "collection_time_iso": time.strftime(
                "%Y-%m-%dT%H:%M:%SZ", time.gmtime(self.collection_time)
            ),
            "hostname": self.hostname,
            "device_id": self.device_id,
            "events": self.events,
            "hash_count": len(self.hashes),
        }

    def generate_manifest(self) -> dict:
        return {
            "chain_of_custody": self.to_dict(),
            "hash_manifest": self.hashes,
            "verification": {
                "manifest_hash": hashlib.sha256(
                    json.dumps(self.hashes, sort_keys=True).encode()
                ).hexdigest(),
                "generated_at": int(time.time()),
            },
        }
