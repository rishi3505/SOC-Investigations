import json
import threading
import time
from typing import Callable, Optional

import requests
import psutil

from .logging_setup import get_logger
from .version import get_version_info

logger = get_logger("communication")


class HeartbeatSender:
    def __init__(self, backend_url: str, interval: float = 60.0, on_status_change: Callable = None):
        self._backend_url = backend_url.rstrip("/")
        self._interval = interval
        self._on_status_change = on_status_change
        self._thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        self._current_status = "UNKNOWN"

    def start(self):
        if self._thread and self._thread.is_alive():
            return
        self._stop_event.clear()
        self._thread = threading.Thread(target=self._run, name="heartbeat", daemon=True)
        self._thread.start()
        logger.info("Heartbeat sender started (interval=%ds)", self._interval)

    def stop(self):
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=5)
        logger.info("Heartbeat sender stopped")

    def _run(self):
        while not self._stop_event.wait(self._interval):
            try:
                status = self._send_heartbeat()
                if status != self._current_status:
                    self._current_status = status
                    if self._on_status_change:
                        self._on_status_change(status)
            except Exception as e:
                logger.error("Heartbeat error: %s", e)
                if self._on_status_change:
                    self._on_status_change("OFFLINE")

    def _send_heartbeat(self) -> str:
        try:
            version_info = get_version_info()
            process = psutil.Process()
            memory_mb = process.memory_info().rss / (1024 * 1024)
            cpu_percent = process.cpu_percent(interval=0.1)

            payload = {
                "device_id": version_info.get("device_id", ""),
                "hostname": version_info.get("hostname", ""),
                "agent_version": version_info.get("agent_version", ""),
                "build_number": version_info.get("build_number", 0),
                "status": "ONLINE",
                "memory_usage_mb": round(memory_mb, 1),
                "cpu_usage_percent": round(cpu_percent, 1),
                "current_user": _get_current_user(),
                "timestamp": int(time.time())
            }

            resp = requests.post(
                f"{self._backend_url}/api/v1/agent/heartbeat",
                json=payload,
                timeout=5
            )
            if resp.status_code == 200:
                logger.debug("Heartbeat sent successfully")
                return "ONLINE"
            else:
                logger.warning("Heartbeat returned HTTP %d", resp.status_code)
                return "DEGRADED"
        except requests.ConnectionError:
            logger.debug("Heartbeat: backend unreachable")
            return "OFFLINE"
        except Exception as e:
            logger.warning("Heartbeat failed: %s", e)
            return "OFFLINE"

    def get_current_status(self) -> str:
        return self._current_status

    def set_current_status(self, status: str):
        self._current_status = status


def _get_current_user() -> str:
    try:
        import os
        return os.environ.get("USERNAME", os.environ.get("USER", "SYSTEM"))
    except Exception:
        return "SYSTEM"
