import os
import sys
import threading
import time

import win32serviceutil
import win32service
import win32event
import servicemanager

_AGENT_DIR = os.path.dirname(os.path.abspath(__file__))
_PARENT_DIR = os.path.dirname(_AGENT_DIR)

if _AGENT_DIR not in sys.path:
    sys.path.insert(0, _AGENT_DIR)
if _PARENT_DIR not in sys.path:
    sys.path.insert(0, _PARENT_DIR)

from .logging_setup import get_logger

logger = get_logger("service")


class SurakshaNetraAgentService(win32serviceutil.ServiceFramework):
    _svc_name_ = "SurakshaNetraAgent"
    _svc_display_name_ = "SurakshaNetra Continuous Authentication Agent"
    _svc_description_ = "Behavior Monitoring and Continuous Authentication Service"

    def __init__(self, args):
        win32serviceutil.ServiceFramework.__init__(self, args)
        self._stop_event = win32event.CreateEvent(None, 0, 0, None)
        self._agent_thread = None
        self._agent = None
        self._running = False

    def SvcDoRun(self):
        servicemanager.LogMsg(
            servicemanager.EVENTLOG_INFORMATION_TYPE,
            servicemanager.PYS_SERVICE_STARTED,
            (self._svc_name_, "")
        )
        logger.info("Service is starting...")

        self._running = True
        self._agent_thread = threading.Thread(target=self._run_agent, name="agent-main", daemon=True)
        self._agent_thread.start()

        win32event.WaitForSingleObject(self._stop_event, win32event.INFINITE)

    def SvcStop(self):
        self._running = False
        servicemanager.LogMsg(
            servicemanager.EVENTLOG_INFORMATION_TYPE,
            servicemanager.PYS_SERVICE_STOPPED,
            (self._svc_name_, "")
        )
        logger.info("Service stop requested")

        self._stop_agent()

        win32event.SetEvent(self._stop_event)

    def _run_agent(self):
        try:
            from background_agent import start_agent, stop_agent, get_agent
            from single_instance import try_acquire

            if not try_acquire():
                logger.error("Another instance is already running. Exiting.")
                return

            start_agent()
            self._agent = get_agent()

            while self._running and self._agent.is_running():
                time.sleep(1)

            logger.info("Agent main loop ended")

        except Exception as e:
            logger.exception("Agent runtime error: %s", e)
            servicemanager.LogMsg(
                servicemanager.EVENTLOG_ERROR_TYPE,
                servicemanager.PYS_SERVICE_STARTED,
                (self._svc_name_, f"Agent error: {e}")
            )

    def _stop_agent(self):
        try:
            from background_agent import stop_agent
            stop_agent()
        except Exception as e:
            logger.error("Error stopping agent: %s", e)


def run_service():
    if len(sys.argv) == 1:
        servicemanager.Initialize()
        servicemanager.PrepareToHostSingle(SurakshaNetraAgentService)
        servicemanager.StartServiceCtrlDispatcher()
    else:
        win32serviceutil.HandleCommandLine(SurakshaNetraAgentService)


if __name__ == "__main__":
    run_service()
