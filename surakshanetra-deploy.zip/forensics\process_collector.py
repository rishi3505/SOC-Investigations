import time
from datetime import datetime

try:
    import psutil
except ImportError:
    psutil = None


def collect_processes() -> list:
    processes = []
    if psutil is None:
        return processes
    for proc in psutil.process_iter(["pid", "name", "ppid", "cpu_percent", "memory_percent", "memory_info", "exe", "create_time", "cmdline", "status"]):
        try:
            pinfo = proc.info
            process = {
                "pid": pinfo["pid"],
                "name": pinfo["name"],
                "ppid": pinfo["ppid"],
                "cpu_percent": pinfo["cpu_percent"] or 0.0,
                "memory_percent": round(pinfo["memory_percent"] or 0.0, 2),
                "memory_rss": pinfo["memory_info"].rss if pinfo["memory_info"] else 0,
                "memory_vms": pinfo["memory_info"].vms if pinfo["memory_info"] else 0,
                "exe_path": pinfo["exe"] or "",
                "create_time": pinfo["create_time"],
                "create_time_iso": datetime.fromtimestamp(pinfo["create_time"]).isoformat() if pinfo["create_time"] else None,
                "cmdline": " ".join(pinfo["cmdline"]) if pinfo["cmdline"] else "",
                "status": pinfo["status"] or "",
            }
            processes.append(process)
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            pass
    processes.sort(key=lambda p: p["cpu_percent"], reverse=True)
    return processes


def collect_active_services() -> list:
    services = []
    if psutil is None:
        return services
    try:
        for service in psutil.win_service_iter():
            try:
                svc = service.as_dict()
                services.append({
                    "name": svc.get("name", ""),
                    "display_name": svc.get("display_name", ""),
                    "status": svc.get("status", ""),
                    "start_type": svc.get("start_type", ""),
                    "description": svc.get("description", ""),
                    "binpath": svc.get("binpath", ""),
                    "username": svc.get("username", ""),
                })
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass
            except Exception:
                pass
    except AttributeError:
        pass
    return services
