import hashlib
import json
import logging
import os
import platform
import subprocess
import uuid

logger = logging.getLogger(__name__)

FINGERPRINT_CACHE_PATH = os.path.join(os.path.dirname(__file__), "data", "device_fingerprint_cache.json")

HARDWARE_WEIGHTS = {
    "machine_guid": 30,
    "bios_uuid": 30,
    "motherboard_serial": 30,
    "cpu_identifier": 15,
    "disk_serial": 20,
    "mac_address": 25,
    "windows_sid": 20,
    "hostname": 5,
    "os_version": 3,
    "windows_build": 5,
    "system_architecture": 2,
    "installed_ram": 2,
    "screen_resolution": 1
}


def _run_powershell(command: str) -> str:
    try:
        result = subprocess.run(
            ["powershell", "-Command", command],
            capture_output=True, text=True, timeout=10
        )
        return result.stdout.strip()
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError) as e:
        logger.debug("PowerShell command failed: %s", e)
        return ""


def _get_hostname() -> str:
    return platform.node() or ""


def _get_machine_guid() -> str:
    return _run_powershell(
        "Get-ItemProperty -Path 'HKLM:\\SOFTWARE\\Microsoft\\Cryptography' -Name 'MachineGuid' | "
        "Select-Object -ExpandProperty MachineGuid"
    )


def _get_bios_uuid() -> str:
    return _run_powershell(
        "Get-CimInstance -Class Win32_ComputerSystemProduct | Select-Object -ExpandProperty UUID"
    )


def _get_motherboard_serial() -> str:
    return _run_powershell(
        "Get-CimInstance -Class Win32_BaseBoard | Select-Object -ExpandProperty SerialNumber"
    )


def _get_cpu_identifier() -> str:
    return _run_powershell(
        "Get-CimInstance -Class Win32_Processor | Select-Object -First 1 -ExpandProperty ProcessorId"
    )


def _get_disk_serial() -> str:
    return _run_powershell(
        "Get-CimInstance -Class Win32_DiskDrive | Select-Object -First 1 -ExpandProperty SerialNumber"
    ).strip()


def _get_mac_address() -> str:
    mac = _run_powershell(
        "Get-NetAdapter | Where-Object {$_.Status -eq 'Up'} | "
        "Select-Object -First 1 -ExpandProperty MacAddress"
    )
    if not mac:
        import uuid as _uuid
        mac = ":".join(format(b, "02x") for b in _uuid.getnode().to_bytes(6, "big")).upper()
    return mac


def _get_windows_sid() -> str:
    return _run_powershell(
        "Get-CimInstance -Class Win32_UserAccount | "
        "Where-Object {$_.Name -eq $env:USERNAME} | "
        "Select-Object -First 1 -ExpandProperty SID"
    )


def _get_os_version() -> str:
    return platform.version() or ""


def _get_windows_build() -> str:
    try:
        return str(platform.version())
    except Exception:
        return ""


def _get_system_architecture() -> str:
    return platform.machine() or ""


def _get_installed_ram() -> str:
    return _run_powershell(
        "Get-CimInstance -Class Win32_ComputerSystem | Select-Object -ExpandProperty TotalPhysicalMemory"
    )


def _get_screen_resolution() -> str:
    result = _run_powershell(
        "Add-Type -AssemblyName System.Windows.Forms; "
        "[System.Windows.Forms.Screen]::PrimaryScreen.Bounds | "
        "ForEach-Object { \"$($_.Width)x$($_.Height)\" }"
    )
    return result


def _normalize(value: str) -> str:
    if not value:
        return ""
    return value.strip().lower().replace("-", "").replace(":", "").replace(" ", "").replace(".", "")


def collect_identifiers() -> dict:
    identifiers = {
        "hostname": _get_hostname(),
        "machine_guid": _get_machine_guid(),
        "bios_uuid": _get_bios_uuid(),
        "motherboard_serial": _get_motherboard_serial(),
        "cpu_identifier": _get_cpu_identifier(),
        "disk_serial": _get_disk_serial(),
        "mac_address": _get_mac_address(),
        "windows_sid": _get_windows_sid(),
        "os_version": _get_os_version(),
        "windows_build": _get_windows_build(),
        "system_architecture": _get_system_architecture(),
        "installed_ram": _get_installed_ram(),
        "screen_resolution": _get_screen_resolution()
    }
    return identifiers


def compute_fingerprint(identifiers: dict) -> str:
    raw = "|".join(
        f"{k}={_normalize(v)}"
        for k, v in sorted(identifiers.items())
        if v
    )
    if not raw:
        raw = str(uuid.uuid4())
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def get_device_fingerprint(cache: bool = True) -> dict:
    if cache and os.path.exists(FINGERPRINT_CACHE_PATH):
        try:
            with open(FINGERPRINT_CACHE_PATH, "r", encoding="utf-8") as f:
                cached = json.load(f)
                if cached.get("fingerprint"):
                    return cached
        except (json.JSONDecodeError, IOError):
            pass

    identifiers = collect_identifiers()
    fingerprint = compute_fingerprint(identifiers)

    result = {
        "fingerprint": fingerprint,
        "_raw_identifiers": identifiers,
        "identifiers": {k: bool(v) for k, v in identifiers.items()},
        "hostname": identifiers.get("hostname", ""),
        "os_version": identifiers.get("os_version", ""),
        "windows_build": identifiers.get("windows_build", ""),
        "system_architecture": identifiers.get("system_architecture", ""),
        "installed_ram": identifiers.get("installed_ram", ""),
        "screen_resolution": identifiers.get("screen_resolution", "")
    }

    os.makedirs(os.path.dirname(FINGERPRINT_CACHE_PATH), exist_ok=True)
    try:
        with open(FINGERPRINT_CACHE_PATH, "w", encoding="utf-8") as f:
            json.dump(result, f)
    except IOError as e:
        logger.warning("Failed to cache fingerprint: %s", e)

    return result


def detect_hardware_changes(previous_identifiers: dict, current_identifiers: dict) -> dict:
    changes = {}
    change_score = 0.0
    max_possible = sum(HARDWARE_WEIGHTS.values())

    for key, weight in HARDWARE_WEIGHTS.items():
        prev_val = _normalize(previous_identifiers.get(key, ""))
        curr_val = _normalize(current_identifiers.get(key, ""))
        if prev_val and curr_val and prev_val != curr_val:
            changes[key] = {
                "previous": previous_identifiers.get(key, ""),
                "current": current_identifiers.get(key, ""),
                "weight": weight,
                "severity": _classify_change_severity(key)
            }
            change_score += weight

    normalized_score = round((change_score / max_possible) * 100, 2) if max_possible > 0 else 0.0
    return {
        "changed": bool(changes),
        "changed_components": list(changes.keys()),
        "change_score": normalized_score,
        "changes": changes,
        "severity": _classify_overall_severity(normalized_score)
    }


def _classify_change_severity(component: str) -> str:
    high_impact = {"machine_guid", "bios_uuid", "motherboard_serial"}
    medium_impact = {"cpu_identifier", "disk_serial", "windows_sid", "mac_address"}
    if component in high_impact:
        return "CRITICAL"
    elif component in medium_impact:
        return "HIGH"
    else:
        return "LOW"


def _classify_overall_severity(score: float) -> str:
    if score >= 60:
        return "CRITICAL"
    elif score >= 30:
        return "HIGH"
    elif score >= 10:
        return "MEDIUM"
    return "LOW"


def compare_with_previous(previous_fingerprint_data: dict) -> dict:
    stored_identifiers = previous_fingerprint_data.get("_raw_identifiers", {})
    current_identifiers = collect_identifiers()
    return detect_hardware_changes(stored_identifiers, current_identifiers)


if __name__ == "__main__":
    fp = get_device_fingerprint(cache=False)
    print("Device Fingerprint:", fp["fingerprint"])
    print("Hostname:", fp.get("hostname"))
    print("OS Version:", fp.get("os_version"))
    print("Architecture:", fp.get("system_architecture"))
    print("Available Identifiers:", sum(1 for v in fp["identifiers"].values() if v), "/ 13")
