"""
Update Manager — Agent version management with approval, scheduling,
force updates, rollback, and deployment tracking.
"""
import json
import time
from fastapi import APIRouter, Depends, HTTPException, Query
from ..database import get_connection
from ..auth import authenticate_request

router = APIRouter(prefix="/api/v1/updates", tags=["Agent Update Manager"])


def _write_audit(conn, action, category, target_type, target_id, actor, details):
    now = int(time.time())
    try:
        conn.execute(
            "INSERT INTO audit_logs_extended (action, category, target_type, target_id, actor, details, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (action, category, target_type, target_id, actor, json.dumps(details), now),
        )
    except Exception:
        pass


@router.post("/releases")
async def create_release(payload: dict, user: dict = Depends(authenticate_request)):
    version = payload.get("version", "")
    build_number = payload.get("build_number", 0)
    if not version:
        raise HTTPException(status_code=400, detail="Version required")
    conn = get_connection()
    now = int(time.time())
    try:
        cursor = conn.execute("""
            INSERT INTO agent_updates
                (version, build_number, release_notes, package_url, package_hash,
                 min_supported_version, mandatory, status, created_by, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, 'DRAFT', ?, ?)
        """, (version, build_number, payload.get("release_notes", ""),
              payload.get("package_url", ""), payload.get("package_hash", ""),
              payload.get("min_supported_version", "0"),
              1 if payload.get("mandatory", False) else 0,
              user.get("username", "admin"), now))
        update_id = cursor.lastrowid
        _write_audit(conn, "update.release.create", "updates", "agent_update", str(update_id),
                     user.get("username", "admin"), {"version": version, "build": build_number})
        conn.commit()
        conn.close()
        return {"status": "created", "update_id": update_id, "version": version}
    except Exception as e:
        conn.close()
        raise HTTPException(status_code=400, detail=str(e))


@router.get("/releases")
async def list_releases(status: str = None, user: dict = Depends(authenticate_request)):
    conn = get_connection()
    if status:
        rows = conn.execute("SELECT * FROM agent_updates WHERE status = ? ORDER BY build_number DESC", (status.upper(),)).fetchall()
    else:
        rows = conn.execute("SELECT * FROM agent_updates ORDER BY build_number DESC").fetchall()
    conn.close()
    return {"releases": [dict(r) for r in rows]}


@router.put("/releases/{update_id}")
async def update_release(update_id: int, payload: dict, user: dict = Depends(authenticate_request)):
    conn = get_connection()
    row = conn.execute("SELECT * FROM agent_updates WHERE id = ?", (update_id,)).fetchone()
    if not row:
        conn.close()
        raise HTTPException(status_code=404, detail="Release not found")
    allowed = {"status", "release_notes", "package_url", "package_hash", "mandatory", "min_supported_version"}
    updates = {k: v for k, v in payload.items() if k in allowed}
    if not updates:
        conn.close()
        return {"status": "no_changes"}
    if "status" in updates and updates["status"] == "RELEASED":
        updates["released_at"] = int(time.time())
    set_clause = ", ".join(f"{k} = ?" for k in updates)
    conn.execute(f"UPDATE agent_updates SET {set_clause} WHERE id = ?", (*updates.values(), update_id))
    _write_audit(conn, "update.release.update", "updates", "agent_update", str(update_id),
                 user.get("username", "admin"), updates)
    conn.commit()
    conn.close()
    return {"status": "updated", "update_id": update_id}


@router.post("/deploy")
async def deploy_update(payload: dict, user: dict = Depends(authenticate_request)):
    update_id = payload.get("update_id")
    target_type = payload.get("target_type", "endpoint")
    target_id = payload.get("target_id", "")
    schedule_type = payload.get("schedule_type", "IMMEDIATE")
    scheduled_at = payload.get("scheduled_at")

    if not update_id or not target_id:
        raise HTTPException(status_code=400, detail="update_id and target_id required")
    conn = get_connection()
    now = int(time.time())
    cursor = conn.execute(
        "INSERT INTO update_deployments (update_id, target_type, target_id, schedule_type, scheduled_at, status) VALUES (?, ?, ?, ?, ?, 'PENDING')",
        (update_id, target_type, target_id, schedule_type, scheduled_at or now),
    )
    deployment_id = cursor.lastrowid

    update_row = conn.execute("SELECT version, build_number FROM agent_updates WHERE id = ?", (update_id,)).fetchone()
    version = update_row["version"] if update_row else "unknown"

    if target_type == "endpoint":
        conn.execute(
            "UPDATE endpoints SET latest_agent_version = ?, latest_agent_build = ?, update_status = 'UPDATE_PENDING' WHERE endpoint_id = ?",
            (version, update_row["build_number"] if update_row else 0, target_id),
        )
    _write_audit(conn, "update.deploy", "updates", target_type, target_id,
                 user.get("username", "admin"), {"update_id": update_id, "version": version, "schedule": schedule_type})
    conn.commit()
    conn.close()
    return {"status": "deployment_created", "deployment_id": deployment_id, "update_id": update_id, "target_id": target_id}


@router.get("/deployments")
async def list_deployments(status: str = None, user: dict = Depends(authenticate_request)):
    conn = get_connection()
    if status:
        rows = conn.execute("SELECT d.*, u.version, u.build_number FROM update_deployments d JOIN agent_updates u ON d.update_id = u.id WHERE d.status = ? ORDER BY d.scheduled_at DESC", (status.upper(),)).fetchall()
    else:
        rows = conn.execute("SELECT d.*, u.version, u.build_number FROM update_deployments d JOIN agent_updates u ON d.update_id = u.id ORDER BY d.scheduled_at DESC").fetchall()
    conn.close()
    return {"deployments": [dict(r) for r in rows]}


@router.get("/status/{endpoint_id}")
async def get_update_status(endpoint_id: str, user: dict = Depends(authenticate_request)):
    conn = get_connection()
    row = conn.execute(
        "SELECT endpoint_id, agent_version, latest_agent_version, latest_agent_build, update_status, update_scheduled_at FROM endpoints WHERE endpoint_id = ?",
        (endpoint_id,),
    ).fetchone()
    conn.close()
    if not row:
        raise HTTPException(status_code=404, detail="Endpoint not found")
    ep = dict(row)
    ep["update_available"] = ep.get("latest_agent_version") and ep["latest_agent_version"] != ep.get("agent_version")
    return ep


@router.post("/check")
async def check_updates(endpoint_id: str = None, user: dict = Depends(authenticate_request)):
    """Returns latest available update info for agent."""
    conn = get_connection()
    latest = conn.execute(
        "SELECT * FROM agent_updates WHERE status = 'RELEASED' ORDER BY build_number DESC LIMIT 1"
    ).fetchone()
    if not latest:
        conn.close()
        return {"update_available": False}
    latest = dict(latest)
    if endpoint_id:
        ep = conn.execute("SELECT agent_version, build_number FROM endpoints WHERE endpoint_id = ?", (endpoint_id,)).fetchone()
        if ep:
            current_build = ep["build_number"] or 0
            latest["update_available"] = latest["build_number"] > current_build
            if latest["update_available"]:
                conn.execute("UPDATE endpoints SET latest_agent_version = ?, latest_agent_build = ?, update_status = 'UPDATE_AVAILABLE' WHERE endpoint_id = ?",
                             (latest["version"], latest["build_number"], endpoint_id))
                _write_audit(conn, "update.available", "updates", "endpoint", endpoint_id,
                             "system", {"current_build": current_build, "latest": latest["version"]})
        else:
            latest["update_available"] = False
    conn.commit()
    conn.close()
    return latest
