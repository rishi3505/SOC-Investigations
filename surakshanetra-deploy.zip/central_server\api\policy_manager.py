"""
Policy Manager — centralized policy CRUD and push to endpoints
"""
import json
import time
from fastapi import APIRouter, Depends, HTTPException, Query
from ..database import get_connection
from ..auth import authenticate_request
from ..models import CreatePolicyRequest, UpdatePolicyRequest

router = APIRouter(prefix="/api/v1/policies", tags=["Policy Manager"])


@router.get("")
async def list_policies(org_id: int = None, user: dict = Depends(authenticate_request)):
    conn = get_connection()
    cursor = conn.cursor()
    conditions = []
    params = []
    if user.get("org_id"):
        conditions.append("org_id = ?")
        params.append(user["org_id"])
    if org_id:
        conditions.append("org_id = ?")
        params.append(org_id)
    where = "WHERE " + " AND ".join(conditions) if conditions else ""
    cursor.execute(f"SELECT * FROM policies {where} ORDER BY created_at DESC", params)
    rows = cursor.fetchall()
    conn.close()
    return {"policies": [dict(r) for r in rows]}


@router.post("")
async def create_policy(payload: CreatePolicyRequest, user: dict = Depends(authenticate_request)):
    name = payload.name
    policy_json = payload.policy_json
    if not name or not policy_json:
        raise HTTPException(status_code=400, detail="name and policy_json required")
    conn = get_connection()
    cursor = conn.cursor()
    now = int(time.time())
    cursor.execute("""
        INSERT INTO policies (org_id, name, enabled, policy_json, version, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (
        user.get("org_id"), name, int(payload.enabled),
        json.dumps(policy_json) if isinstance(policy_json, dict) else policy_json,
        payload.version, now, now,
    ))
    conn.commit()
    policy_id = cursor.lastrowid
    conn.close()
    return {"status": "created", "policy_id": policy_id}


@router.put("/{policy_id}")
async def update_policy(policy_id: int, payload: UpdatePolicyRequest, user: dict = Depends(authenticate_request)):
    conn = get_connection()
    cursor = conn.cursor()
    now = int(time.time())
    updates = []
    params = []
    if payload.name is not None:
        updates.append("name = ?")
        params.append(payload.name)
    if payload.enabled is not None:
        updates.append("enabled = ?")
        params.append(int(payload.enabled))
    if payload.policy_json is not None:
        pj = payload.policy_json
        updates.append("policy_json = ?")
        params.append(json.dumps(pj) if isinstance(pj, dict) else pj)
    updates.append("updated_at = ?")
    params.append(now)
    params.append(policy_id)
    cursor.execute(f"UPDATE policies SET {', '.join(updates)} WHERE id = ?", params)
    conn.commit()
    conn.close()
    return {"status": "updated", "policy_id": policy_id}


@router.delete("/{policy_id}")
async def delete_policy(policy_id: int, user: dict = Depends(authenticate_request)):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM policies WHERE id = ?", (policy_id,))
    conn.commit()
    conn.close()
    return {"status": "deleted", "policy_id": policy_id}


@router.post("/{policy_id}/push")
async def push_policy(policy_id: int, user: dict = Depends(authenticate_request)):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM policies WHERE id = ?", (policy_id,))
    policy = cursor.fetchone()
    if not policy:
        conn.close()
        raise HTTPException(status_code=404, detail="Policy not found")
    policy = dict(policy)
    cursor.execute("SELECT endpoint_id FROM endpoints WHERE org_id = ?", (user.get("org_id"),))
    endpoints = [r["endpoint_id"] for r in cursor.fetchall()]
    version = str(int(time.time()))
    cursor.execute("UPDATE policies SET version = ? WHERE id = ?", (version, policy_id))
    conn.commit()
    conn.close()
    return {
        "status": "pushed",
        "policy_id": policy_id,
        "version": version,
        "endpoints_affected": len(endpoints),
        "endpoints": endpoints,
    }


@router.get("/agent/{device_id}")
async def get_agent_policy(device_id: str, user: dict = Depends(authenticate_request)):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT p.* FROM policies p
        JOIN endpoints e ON e.org_id = p.org_id
        WHERE e.endpoint_id = ? AND p.enabled = 1
        ORDER BY p.updated_at DESC LIMIT 1
    """, (device_id,))
    row = cursor.fetchone()
    conn.close()
    if not row:
        return {"policy": None, "version": "0"}
    policy = dict(row)
    return {"policy": json.loads(policy["policy_json"]) if isinstance(policy["policy_json"], str) else policy["policy_json"], "version": policy["version"]}
