import time
import json
import csv
import os
from collections import deque, Counter

from agent.keyboard import KeyboardMonitor
from agent.mouse_tracker import MouseMonitor
from agent.system_monitor import SystemMonitor
from agent.location_utils import LocationTracker
from agent.device_fingerprint import get_device_fingerprint

DATA_DIR = "data"
CSV_FILE = "data/behavior_data.csv"

INTERVAL = 2
WINDOW_SIZE = 5  # 5 samples * 2 sec = 10 seconds sliding window

def ensure_data_dir():
    if not os.path.exists(DATA_DIR):
        os.makedirs(DATA_DIR)

def get_aggregated_data(window):
    """
    Computes aggregated features over a sliding window of raw 2s data.
    Takes robust averages (ignoring empty latency zeroes) and mode app strings.
    """
    def mean(lst):
        return sum(lst) / len(lst) if lst else 0.0
        
    latencies = [d["key_latency"] for d in window if d["key_latency"] > 0]
    holds = [d["avg_hold_time"] for d in window if d["avg_hold_time"] > 0]
    
    apps = [d["active_app"] for d in window]
    most_common_app = Counter(apps).most_common(1)[0][0] if apps else "Unknown"
    
    latest = window[-1]
    
    return {
        "typing_speed": round(mean([d["typing_speed"] for d in window]), 4),
        "key_latency": round(mean(latencies), 4),
        "avg_hold_time": round(mean(holds), 4),
        "latency_jitter": round(mean([d["latency_jitter"] for d in window if d["latency_jitter"] > 0]), 4),
        "mouse_speed": round(mean([d["mouse_speed"] for d in window]), 4),
        "mouse_acceleration": round(mean([d["mouse_acceleration"] for d in window]), 4),
        "direction_change_freq": round(sum(d["direction_change_freq"] for d in window), 4),
        "click_frequency": round(mean([d["click_frequency"] for d in window]), 4),
        "active_app": most_common_app,
        "app_switch_count": sum(d["app_switch_count"] for d in window),
        "idle_time": latest["idle_time"],
        "time_of_day": latest["time_of_day"],
        "session_duration": latest["session_duration"],
        "ip_address": latest.get("ip_address", "Unknown"),
        "city": latest.get("city", "Unknown"),
        "country": latest.get("country", "Unknown"),
        "is_new_location": latest.get("is_new_location", False)
    }

def main():
    ensure_data_dir()
    
    kb_monitor = KeyboardMonitor()
    mouse_monitor = MouseMonitor()
    sys_monitor = SystemMonitor()
    
    kb_monitor.start()
    mouse_monitor.start()
    
    print(f"Started Behavior Data Collection Agent.")
    print(f"Raw Interval: {INTERVAL}s | Aggregation Window: {INTERVAL * WINDOW_SIZE}s.")
    print("Metrics will be printed as JSON and aggregated data saved to:", CSV_FILE)
    print("Press Ctrl+C to stop.")
    
    # Deque to store raw data for aggregation (10s window)
    window = deque()
    
    file_exists = os.path.isfile(CSV_FILE)
    
    # Location tracking
    loc_tracker = LocationTracker()
    last_agg_time = time.time()

    device_fp = get_device_fingerprint(cache=True)
    
    try:
        with open(CSV_FILE, mode='a', newline='', encoding='utf-8') as f:
            fieldnames = [
                "typing_speed", "key_latency", "avg_hold_time", "latency_jitter",
                "mouse_speed", "mouse_acceleration", "direction_change_freq",
                "click_frequency", "active_app", "app_switch_count", "idle_time",
                "time_of_day", "session_duration", "ip_address", "city",
                "country", "is_new_location"
            ]
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            
            if not file_exists:
                writer.writeheader()
                
            print(f"Hybrid Monitoring: Active @ {INTERVAL}s | Idle @ 5-10s.")
            
            while True:
                current_time = time.time()
                
                # Extract RAW data
                kb_metrics = kb_monitor.get_metrics_and_reset()
                mouse_metrics = mouse_monitor.get_metrics_and_reset()
                sys_metrics = sys_monitor.get_metrics_and_reset()
                
                # Detect idle status to adjust timing
                last_activity = max(kb_metrics["last_activity"], mouse_metrics["last_activity"])
                idle_time = max(0.0, current_time - last_activity)
                
                # Adaptive Interval (Part 4)
                # If idle > 10s, reduce frequency
                active_interval = INTERVAL
                if idle_time > 10:
                    active_interval = 5 # Sampling every 5s when idle
                
                typing_speed = kb_metrics["press_count"] / float(active_interval)
                mouse_speed = mouse_metrics["mouse_distance"] / float(active_interval)
                click_frequency = mouse_metrics["click_count"] / float(active_interval)
                
                # Get Location info (Part 1)
                loc_info = loc_tracker.get_location()
                
                # Refinement: Noise Filtering & Signal Smoothing (SMA-3)
                if not hasattr(main, "_sma_buffer"):
                    main._sma_buffer = deque(maxlen=3)
                
                # Input Clamp & Micro-movement logic (Refinement Part 3)
                m_accel = mouse_metrics["mouse_acceleration"]
                m_dfreq = mouse_metrics["direction_change_freq"]
                
                # Clamp unrealistic spikes
                m_accel = min(50.0, m_accel)
                
                # Micro-movement deadzone
                if m_accel < 0.01: m_accel = 0.0
                if m_dfreq < 0.01: m_dfreq = 0.0
                
                main._sma_buffer.append({
                    "mouse_acceleration": m_accel,
                    "direction_change_freq": m_dfreq,
                    "latency_jitter": kb_metrics["latency_jitter"]
                })
                
                def get_sma(key):
                    vals = [d[key] for d in main._sma_buffer]
                    return sum(vals) / len(vals) if vals else 0.0

                raw_data = {
                    "typing_speed": typing_speed,
                    "key_latency": kb_metrics["avg_key_latency"],
                    "avg_hold_time": kb_metrics["avg_hold_time"],
                    "latency_jitter": get_sma("latency_jitter"),
                    "mouse_speed": min(1000.0, mouse_speed), # Clamp speed too
                    "mouse_acceleration": get_sma("mouse_acceleration"),
                    "direction_change_freq": get_sma("direction_change_freq"),
                    "click_frequency": click_frequency,
                    "active_app": sys_metrics["active_app"],
                    "app_switch_count": sys_metrics["app_switch_count"],
                    "idle_time": idle_time,
                    "time_of_day": sys_metrics["time_of_day"],
                    "session_duration": round(sys_metrics["session_duration"], 2),
                    **loc_info
                }
                
                window.append(raw_data)
                # Ensure window does not exceed size for sliding (10s = 5 samples @ 2s)
                if len(window) > WINDOW_SIZE:
                    window.popleft()
                
                # Check for aggregation (every 5 seconds - the "Step")
                if current_time - last_agg_time >= 5:
                    if len(window) >= (WINDOW_SIZE // 2): # Ensure some data present
                        aggregated_data = get_aggregated_data(window)
                        
                        print(f"\n[SENDING TO BACKEND] (Idle: {idle_time:.1f}s) Risk signals aggregated over {len(window)} samples:")
                        
                        # Send to ML Service for real-time analysis
                        import requests
                        try:
                            response = requests.post("http://localhost:8000/api/v1/analyze", json={
                                **aggregated_data,
                                "user_id": "default_user",
                                "device_hash": device_fp.get("fingerprint", ""),
                                "device_hostname": device_fp.get("hostname", ""),
                                "device_os_version": device_fp.get("os_version", ""),
                                "device_windows_build": device_fp.get("windows_build", ""),
                                "device_architecture": device_fp.get("system_architecture", "")
                            }, timeout=2)
                            if response.status_code == 200:
                                result = response.json()
                                print(f"Risk Score: {result['risk_score']} | Level: {result['risk_level']} | Action: {result['action']}")
                                print(f"Reason: {result['reason']}")
                            else:
                                print(f"Server Error: {response.status_code}")
                        except Exception as e:
                            print(f"Failed to connect to ML Service: {e}")
                        
                        writer.writerow(aggregated_data)
                        f.flush()
                        
                        window.clear()
                        last_agg_time = current_time
                
                # Sleep for the adjusted interval
                time.sleep(active_interval)
                
    except KeyboardInterrupt:
        print("\nStopping Behavior Data Collection Agent...")
    except Exception as e:
        print(f"\nAn error occurred: {e}")
    finally:
        kb_monitor.stop()
        mouse_monitor.stop()

if __name__ == "__main__":
    main()
