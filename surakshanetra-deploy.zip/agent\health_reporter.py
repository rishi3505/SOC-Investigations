"""
Health Reporter — Collects and reports comprehensive endpoint health metrics
to CMS including CPU, memory, disk, queue, service status, and ML health.
"""
import json
import os
import threading
import time
from typing import Optional

import psutil
import requests

from .logging_setup import get_logger

logger = get_logger("communication")


class HealthReporter:
    def __init__(self, cms_url: str, device_id: str, report_interval: float = 60.0, backend_queue_size: int = 0):
        self._cms_url = cms_url.rstrip("/")
        self._device_id = device_id
        self._report_interval = report_interval
        self._backend_queue_size = backend_queue_size
        self._thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()

    def start(self):
        if self._thread and self._thread.is_alive():
            return
        self._stop_event.clear()
        self._thread = threading.Thread(target=self._run, name="health-reporter", daemon=True)
        self._thread.start()
        logger.info("Health reporter started (interval=%ds)", self._report_interval)

    def stop(self):
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=5)
        logger.info("Health reporter stopped")

    def report_now(self) -> dict:
        try:
            metrics = self._collect_metrics()
            resp = requests.post(
                f"{self._cms_url}/api/v1/health/snapshot/{self._device_id}",
                json=metrics,
                timeout=10,
            )
            if resp.status_code == 200:
                result = resp.json()
                logger.debug("Health reported: score=%s category=%s", result.get("health_score"), result.get("category"))
                return result
            return {"status": "error"}
        except Exception as e:
            logger.error("Health report failed: %s", e)
            return {"status": "error", "detail": str(e)}

    def _collect_metrics(self) -> dict:
        process = psutil.Process()
        memory = psutil.virtual_memory()
        disks = psutil.disk_partitions()
        disk_usage = 0
        if disks:
            try:
                disk_usage = psutil.disk_usage(disks[0].mountpoint).percent
            except Exception:
                pass

        queue_size = self._backend_queue_size
        if callable(queue_size):
            try:
                queue_size = queue_size()
            except Exception:
                pass

        ml_health = "OK"
        try:
            import sys
            sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
            from ml_service.anomaly_model import get_model_instance
            model = get_model_instance()
            if model and hasattr(model, "model") and model.model is not None:
                ml_health = "OK"
            else:
                ml_health = "NO_MODEL"
        except Exception:
            ml_health = "UNAVAILABLE"

        db_health = "OK"
        try:
            from .backend_queue import get_queue
            q = get_queue()
            if q:
                q.count_pending()
                db_health = "OK"
        except Exception:
            db_health = "UNAVAILABLE"

        return {
            "cpu_percent": round(process.cpu_percent(interval=0.5), 1),
            "memory_percent": round(memory.percent, 1),
            "disk_percent": round(disk_usage, 1),
            "queue_size": queue_size if isinstance(queue_size, int) else 0,
            "heartbeat_delay": 0,
            "last_incident_age": 0,
            "ml_health": ml_health,
            "db_health": db_health,
            "service_status": "RUNNING",
        }

    def _run(self):
        self.report_now()
        while not self._stop_event.wait(self._report_interval):
            self.report_now()
