"""
Agent Registry — endpoint registration and lifecycle management
"""
import time
from fastapi import APIRouter, Depends, HTTPException
from ..database import get_connection
from ..auth import authenticate_request
from ..models import RegisterEndpointRequest

router = APIRouter(prefix="/api/v1/agent", tags=["Agent Registry"])


@router.post("/register")
async def register_endpoint(payload: RegisterEndpointRequest, user: dict = Depends(authenticate_request)):
    endpoint_id = payload.device_id or payload.endpoint_id
    if not endpoint_id:
        raise HTTPException(status_code=400, detail="device_id or endpoint_id required")

    conn = get_connection()
    cursor = conn.cursor()
    now = int(time.time())
    cursor.execute("""
        INSERT OR IGNORE INTO endpoints
            (endpoint_id, device_id, hostname, agent_version, build_number,
             os, os_version, architecture, ip_address, install_date, last_update,
             first_seen, last_seen, health_status, org_id)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'ONLINE', ?)
    """, (
        endpoint_id,
        payload.device_id or endpoint_id,
        payload.hostname,
        payload.agent_version,
        payload.build_number,
        payload.os or "",
        payload.os_version or "",
        payload.architecture or "",
        payload.ip_address or "",
        payload.install_date or "",
        payload.last_update or 0,
        now, now,
        user.get("org_id"),
    ))
    conn.commit()
    conn.close()
    return {"status": "registered", "endpoint_id": endpoint_id}


@router.get("/status/{endpoint_id}")
async def get_agent_status(endpoint_id: str, user: dict = Depends(authenticate_request)):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM endpoints WHERE endpoint_id = ?", (endpoint_id,))
    row = cursor.fetchone()
    conn.close()
    if not row:
        raise HTTPException(status_code=404, detail="Endpoint not found")
    return {"status": "ok", "endpoint": dict(row)}
