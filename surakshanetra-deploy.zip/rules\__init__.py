"""
Detection Rules Package — Sigma-inspired JSON detection rules for XDR threat detection.
Each rule maps to a MITRE ATT&CK technique and defines detection conditions with thresholds.
"""
