"""
Seed IOC Database with sample IOCs for development and testing.
"""
import os
import sys
import time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from threat_intelligence.ioc_manager import init_ioc_db, add_ioc, get_ioc_stats

SAMPLE_IOCS = [
    # Known malicious IPs (C2 nodes)
    {"type": "IP", "value": "185.130.5.42", "severity": "CRITICAL", "confidence": "VERY_HIGH", "threat_family": "Emotet", "source": "sample", "mitre_technique_id": "T1071", "mitre_technique_name": "Application Layer Protocol", "mitre_tactic": "Command and Control"},
    {"type": "IP", "value": "91.121.87.132", "severity": "HIGH", "confidence": "HIGH", "threat_family": "TrickBot", "source": "sample", "mitre_technique_id": "T1071", "mitre_technique_name": "Application Layer Protocol", "mitre_tactic": "Command and Control"},
    {"type": "IP", "value": "45.33.32.156", "severity": "HIGH", "confidence": "HIGH", "threat_family": "Cobalt Strike", "source": "sample", "mitre_technique_id": "T1090", "mitre_technique_name": "Proxy", "mitre_tactic": "Command and Control"},
    {"type": "IP", "value": "104.248.50.87", "severity": "MEDIUM", "confidence": "MEDIUM", "threat_family": "Mirai", "source": "sample", "mitre_technique_id": "T1071", "mitre_technique_name": "Application Layer Protocol", "mitre_tactic": "Command and Control"},
    {"type": "IP", "value": "198.71.60.28", "severity": "HIGH", "confidence": "HIGH", "threat_family": "Matanbuchus", "source": "sample", "mitre_technique_id": "T1071"},

    # Malicious domains
    {"type": "DOMAIN", "value": "evil-c2-server.xyz", "severity": "CRITICAL", "confidence": "VERY_HIGH", "threat_family": "Unknown", "source": "sample", "mitre_technique_id": "T1071", "mitre_technique_name": "Application Layer Protocol", "mitre_tactic": "Command and Control"},
    {"type": "DOMAIN", "value": "phishing-login-page.com", "severity": "HIGH", "confidence": "HIGH", "threat_family": "Phishing", "source": "sample", "mitre_technique_id": "T1566", "mitre_technique_name": "Phishing", "mitre_tactic": "Initial Access"},
    {"type": "DOMAIN", "value": "malware-dist.cc", "severity": "HIGH", "confidence": "MEDIUM", "threat_family": "Dridex", "source": "sample", "mitre_technique_id": "T1204", "mitre_technique_name": "User Execution", "mitre_tactic": "Execution"},

    # Malicious URLs
    {"type": "URL", "value": "https://evil-c2-server.xyz/beacon", "severity": "CRITICAL", "confidence": "VERY_HIGH", "threat_family": "Cobalt Strike", "source": "sample", "mitre_technique_id": "T1090"},
    {"type": "URL", "value": "https://phishing-login-page.com/secure/verify", "severity": "HIGH", "confidence": "HIGH", "threat_family": "Phishing", "source": "sample", "mitre_technique_id": "T1566"},

    # Known malicious process names
    {"type": "PROCESS_NAME", "value": "svch0st.exe", "severity": "CRITICAL", "confidence": "VERY_HIGH", "threat_family": "Emotet", "source": "sample", "mitre_technique_id": "T1055", "mitre_technique_name": "Process Injection", "mitre_tactic": "Defense Evasion"},
    {"type": "PROCESS_NAME", "value": "winlog0n.exe", "severity": "CRITICAL", "confidence": "HIGH", "threat_family": "Mimikatz", "source": "sample", "mitre_technique_id": "T1003", "mitre_technique_name": "OS Credential Dumping", "mitre_tactic": "Credential Access"},
    {"type": "PROCESS_NAME", "value": "powershell_ise.exe", "severity": "HIGH", "confidence": "HIGH", "threat_family": "Living Off Land", "source": "sample", "mitre_technique_id": "T1059", "mitre_technique_name": "Command and Scripting Interpreter", "mitre_tactic": "Execution"},
    {"type": "PROCESS_NAME", "value": "rundll32_cs.exe", "severity": "CRITICAL", "confidence": "HIGH", "threat_family": "Cobalt Strike", "source": "sample", "mitre_technique_id": "T1055"},
    {"type": "PROCESS_NAME", "value": "msbuild_vuln.exe", "severity": "HIGH", "confidence": "MEDIUM", "threat_family": "Living Off Land", "source": "sample", "mitre_technique_id": "T1127", "mitre_technique_name": "Trusted Developer Utilities Proxy Execution", "mitre_tactic": "Defense Evasion"},

    # File hashes (SHA256)
    {"type": "SHA256", "value": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855", "severity": "CRITICAL", "confidence": "VERY_HIGH", "threat_family": "Emotet", "source": "sample", "mitre_technique_id": "T1204"},
    {"type": "SHA256", "value": "a7ffc6f8bf1ed76651c14756a061d662f580ff4de43b49fa82d80a4b80f8434a", "severity": "HIGH", "confidence": "HIGH", "threat_family": "TrickBot", "source": "sample", "mitre_technique_id": "T1204"},

    # Registry keys
    {"type": "REGISTRY_KEY", "value": "HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run\\WindowsDefender", "severity": "HIGH", "confidence": "HIGH", "threat_family": "Backdoor", "source": "sample", "mitre_technique_id": "T1547", "mitre_technique_name": "Boot or Logon Autostart Execution", "mitre_tactic": "Persistence"},
    {"type": "REGISTRY_KEY", "value": "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run\\JavaUpdateScheduler", "severity": "HIGH", "confidence": "MEDIUM", "threat_family": "Trojan", "source": "sample", "mitre_technique_id": "T1547"},

    # Scheduled tasks
    {"type": "SCHEDULED_TASK", "value": "WindowsUpdate_Explorer", "severity": "HIGH", "confidence": "HIGH", "threat_family": "Backdoor", "source": "sample", "mitre_technique_id": "T1053", "mitre_technique_name": "Scheduled Task/Job", "mitre_tactic": "Execution"},
    {"type": "SCHEDULED_TASK", "value": "GoogleUpdateTaskMachineQH", "severity": "MEDIUM", "confidence": "MEDIUM", "threat_family": "Adware", "source": "sample", "mitre_technique_id": "T1053"},

    # Service names
    {"type": "SERVICE_NAME", "value": "WindowsRemoteAccessSvc", "severity": "CRITICAL", "confidence": "HIGH", "threat_family": "RAT", "source": "sample", "mitre_technique_id": "T1569", "mitre_technique_name": "System Services", "mitre_tactic": "Execution"},
    {"type": "SERVICE_NAME", "value": "MsSqlServerBackupSvc", "severity": "HIGH", "confidence": "MEDIUM", "threat_family": "MSSQL Worm", "source": "sample", "mitre_technique_id": "T1569"},

    # User agents
    {"type": "USER_AGENT", "value": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36 Bot", "severity": "MEDIUM", "confidence": "MEDIUM", "threat_family": "Scraper", "source": "sample", "mitre_technique_id": "T1071"},
    {"type": "USER_AGENT", "value": "curl/7.68.0 (malicious)", "severity": "HIGH", "confidence": "HIGH", "threat_family": "Automated Attack", "source": "sample", "mitre_technique_id": "T1071"},

    # Email addresses
    {"type": "EMAIL", "value": "phish@evil-sender.cc", "severity": "HIGH", "confidence": "MEDIUM", "threat_family": "Phishing", "source": "sample", "mitre_technique_id": "T1566"},
    {"type": "EMAIL", "value": "malware-drop@tempmail.xyz", "severity": "MEDIUM", "confidence": "MEDIUM", "threat_family": "Malware", "source": "sample", "mitre_technique_id": "T1566"},

    # Mutexes
    {"type": "MUTEX", "value": "Global\\Emotet_Mutex_Session", "severity": "CRITICAL", "confidence": "HIGH", "threat_family": "Emotet", "source": "sample", "mitre_technique_id": "T1055"},

    # Named pipes
    {"type": "NAMED_PIPE", "value": "\\\\.\\pipe\\emotet_named_pipe", "severity": "CRITICAL", "confidence": "HIGH", "threat_family": "Emotet", "source": "sample", "mitre_technique_id": "T1055"},
]


def seed():
    print("Initializing IOC database...")
    init_ioc_db()

    print(f"Seeding {len(SAMPLE_IOCS)} sample IOCs...")
    imported = 0
    for ioc in SAMPLE_IOCS:
        try:
            add_ioc(**ioc)
            imported += 1
        except Exception as e:
            print(f"  Error seeding {ioc['type']}:{ioc['value']}: {e}")

    stats = get_ioc_stats()
    print(f"\nSeeding complete: {imported} IOCs imported")
    print(f"  Active: {stats['total_active']}")
    print(f"  By type: {stats['by_type']}")
    print(f"  By severity: {stats['by_severity']}")


if __name__ == "__main__":
    seed()
