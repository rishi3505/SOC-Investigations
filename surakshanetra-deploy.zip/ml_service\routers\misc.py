import json
import os
import sys

sys.path.append(os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.append(os.path.join(os.path.dirname(__file__), ".."))

from fastapi import APIRouter, HTTPException, BackgroundTasks
from pydantic import BaseModel

from backend.db import insert_feedback, update_incident_status, get_incident_by_id
from backend.response_engine import resolve_incident_on_recovery
from ml_service.state import model_instance, _user_session_state, RECORDS_SINCE_LAST_TRAIN

router = APIRouter()


class FeedbackPayload(BaseModel):
    behavior_id: int
    label: str


@router.post("/api/v1/feedback")
async def submit_feedback(payload: FeedbackPayload):
    try:
        insert_feedback(payload.behavior_id, payload.label)
        return {"status": "success", "message": "Feedback recorded."}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/api/v1/retrain")
async def manual_retrain(background_tasks: BackgroundTasks):
    from ml_service.routers.analyze import retrain_model_task
    background_tasks.add_task(retrain_model_task)
    return {"message": "Retraining started in the background."}


@router.get("/health")
def health_check():
    return {"status": "online", "model_loaded": model_instance.model is not None if model_instance else False, "records_buffered": RECORDS_SINCE_LAST_TRAIN}


@router.post("/api/v1/mfa-result")
def mfa_result(payload: dict):
    user_id = payload.get("user_id", "default_user")
    success = payload.get("success", False)
    if user_id not in _user_session_state:
        _user_session_state[user_id] = {"consecutive_anomalies": 0, "system_state": "NORMAL", "last_incident_id": None, "has_recent_mfa": False, "positive_feedback_count": 0}
    state = _user_session_state[user_id]
    if success:
        state["has_recent_mfa"] = True
        incident_id = state.get("last_incident_id")
        if incident_id:
            recovered = resolve_incident_on_recovery(
                incident_id=incident_id,
                evaluation={"risk_level": state.get("risk_level", "MEDIUM"), "risk_level_num": state.get("risk_level_num", 2), "response_level": state.get("response_level", 2), "system_state": state.get("system_state", "OBSERVATION"), "action": "OBSERVE", "evidence_score": state.get("evidence_score", 50), "recommendation": {"reasons": [], "recommended_action": ""}},
                mfa_success=True,
            )
            update_incident_status(incident_id, "RESOLVED", resolution_notes="MFA completed successfully")
            state["last_incident_id"] = None
            state["system_state"] = "OBSERVATION"
            return {"status": "recovered", "incident_id": incident_id, "new_state": recovered}
        state["system_state"] = "NORMAL"
        return {"status": "mfa_success", "message": "MFA successful, state normalized"}
    else:
        if state["consecutive_anomalies"] < 3:
            state["consecutive_anomalies"] += 2
        return {"status": "mfa_failed", "message": "MFA failed, risk escalated"}


@router.get("/api/v1/user-state/{user_id}")
def user_state(user_id: str):
    state = _user_session_state.get(user_id, {"consecutive_anomalies": 0, "system_state": "NORMAL", "last_incident_id": None, "has_recent_mfa": False, "positive_feedback_count": 0})
    return {"user_id": user_id, "state": state}
