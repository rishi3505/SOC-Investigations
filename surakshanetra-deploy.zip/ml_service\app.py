from fastapi import FastAPI, HTTPException, BackgroundTasks
from pydantic import BaseModel
import os
import sys
from contextlib import asynccontextmanager

# Add parent directory to path to import backend.db
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
# Add the current directory to path to allow importing neighbor modules
sys.path.append(os.path.dirname(__file__))

from backend.db import (
    insert_behavior, check_trusted_session, get_user_thresholds, 
    insert_feedback, check_location_trust, fetch_time_bucket_means,
    get_sample_count, increment_sample_count, add_session_risk, get_session_history,
    fetch_training_data, fetch_feedback_labeled_data, get_user_profiles_all,
    get_trusted_locations_all, get_behavior_by_user, get_total_record_count,
    get_session_history_all,
    insert_incident, get_incidents, get_incident_by_id, update_incident_status,
    insert_response_history, get_response_history,
    insert_policy_audit, get_policy_audit,
    register_device, update_device_last_seen, check_device_trust,
    insert_device_history,
    upsert_agent_heartbeat, get_agent_heartbeat,
    insert_containment_action, get_containment_actions,
    insert_evidence_package, get_evidence_packages, get_evidence_package_by_incident,
)
from backend.response_engine import (
    evaluate as response_evaluate,
    resolve_incident_on_recovery,
    create_incident as engine_create_incident,
    get_all_incidents as engine_get_incidents,
    get_incident as engine_get_incident,
    update_incident_status as engine_update_status
)
from backend.mitre_mapping import get_all_techniques
from backend.containment_engine import execute_containment
from anomaly_model import get_model_instance
from train import train_model
import json

# Global model instance
model_instance = None

# Per-user session state for response engine
_user_session_state: dict = {}

@asynccontextmanager
async def lifespan(app: FastAPI):
    global model_instance
    model_instance = get_model_instance()
    print("ML Service Started. Model instance loaded.")
    yield
    print("ML Service shutting down.")

app = FastAPI(
    title="Continuous Behavioral Auth API",
    description="Upgraded ML Microservice with SQLite Integration & Continuous Learning",
    version="2.0.0",
    lifespan=lifespan
)

class BehaviorPayload(BaseModel):
    typing_speed: float
    key_latency: float
    avg_hold_time: float
    latency_jitter: float
    mouse_speed: float
    mouse_acceleration: float
    direction_change_freq: float
    click_frequency: float
    active_app: str
    app_switch_count: int
    idle_time: float
    time_of_day: float
    user_id: str = "default_user"
    ip_address: str = "Unknown"
    city: str = "Unknown"
    country: str = "Unknown"
    is_new_location: bool = False
    device_hash: str = ""
    device_hostname: str = ""
    device_os_version: str = ""
    device_windows_build: str = ""
    device_architecture: str = ""
    device_change_score: float = 0.0
    device_trust_status: str = "UNKNOWN"

# Internal counter for automatic retraining
RECORDS_SINCE_LAST_TRAIN = 0
TRAIN_THRESHOLD = 500

# Apps where high idle time is normal
PASSIVE_APPS = ["YouTube", "Netflix", "VLC", "Chrome", "PDF Reader", "Zoom", "Teams", "Video Player"]

# 5. Hybrid Memory Manager & Multi-Window Risk Engine logic
def calculate_aggregated_risk(user_id, current_result, samples_total):
    """
    Computes rolling risk and determines final action based on session history.
    """
    history = get_session_history(user_id, limit=20)
    
    if history.empty:
        return current_result["risk_score"], "LOW", "ALLOW", "Initial window."

    # 1. Progressive Activation Stage
    state = "PROTECTED"
    if samples_total < 200:
        state = "LEARNING"
    elif samples_total < 500:
        state = "MONITORING"
    
    # 2. Risk State Buffers
    short_term = history.head(5) # Last 5 windows
    long_term = history # Last 20 windows
    
    total_anomalies_st = short_term['is_anomalous'].sum()
    consecutive_anomalies = 0
    for val in history['is_anomalous']:
        if val: consecutive_anomalies += 1
        else: break
        
    normal_streak = 0
    for val in history['is_anomalous']:
        if not val: normal_streak += 1
        else: break
        
    # 3. Hybrid Decay & Rolling Score Calculation (Refinement Part 5)
    # Long term has 0.3 weight
    st_avg = short_term['risk_score'].mean()
    lt_avg = long_term['risk_score'].mean()
    rolling_score = (st_avg * 0.7) + (lt_avg * 0.3)
    raw_rolling_score = rolling_score # Keep for reason logging
    
    # 4. Decision Matrix (Consistency-Based with Multi-Feature Consensus)
    risk_level = "LOW"
    action = "ALLOW"
    
    # Extract significance markers from current window
    sig = current_result.get("significance", {})
    strong_total = sig.get("strong_count", 0)
    weak_total = sig.get("weak_count", 0)
    extreme_total = sig.get("extreme_count", 0)
    
    # Consensus Logic (Refinement Part 4)
    # Require 2+ features deviating OR 1 extreme dev (>40%)
    has_consensus = (strong_total + weak_total >= 2) or (extreme_total >= 1)
    
    # Transition Rules:
    if has_consensus:
        if total_anomalies_st >= 4 or (len(long_term) >= 10 and long_term['is_anomalous'].sum() >= 6):
            risk_level = "HIGH"
            action = "BLOCK"
        elif consecutive_anomalies >= 3 or total_anomalies_st >= 2:
            risk_level = "MEDIUM"
            action = "VERIFY"
        elif total_anomalies_st >= 1:
            risk_level = "LOW"
            action = "ALLOW"
    else:
        # If no consensus, hold risk at LOW regardless of ML score
        risk_level = "LOW"
        action = "ALLOW"
        if raw_rolling_score > 50:
             current_result["reason"] += " (Escalation suppressed: No multi-feature consensus)"

    # 5. Apply Gradual Decay (12.5% per window) only after 3 normal windows
    if normal_streak >= 3:
        # We simulate historical decay by dampening the rolling score further
        decay_factor = 0.875 ** (normal_streak - 2)
        rolling_score *= decay_factor
        
        # Override levels if decay is active and streak is strong (Part 2)
        # Drop HIGH to MEDIUM if we have a streak of 3
        if risk_level == "HIGH":
             risk_level = "MEDIUM"
             action = "VERIFY"
        
        # Drop to LOW if we have a streak of 5
        if normal_streak >= 5:
            risk_level = "LOW"
            action = "ALLOW"

    # 5. Fail-Safe (Confidence Check)
    confidence = current_result.get("confidence_score", 1.0)
    if confidence < 0.4 and risk_level == "HIGH":
        risk_level = "MEDIUM"
        action = "VERIFY"
        current_result["reason"] += " (Confidence low, downgraded to VERIFY)"

    # 6. Activation Stage Enforcement
    if state == "LEARNING":
        risk_level = "LOW"
        action = "ALLOW"
        reason = "System in Learning Mode (Collecting Baseline)."
    elif state == "MONITORING":
        if risk_level in ["HIGH", "MEDIUM"]:
            risk_level = "LOW" # Passive monitoring only
            action = "ALLOW"
            reason = f"Monitoring active. Suspected {risk_level} anomaly detected, but not enforced yet."
        else:
            reason = current_result["reason"]
    else:
        reason = current_result["reason"]

    return round(rolling_score, 2), risk_level, action, reason

@app.post("/api/v1/analyze")
async def analyze_behavior(payload: BehaviorPayload, background_tasks: BackgroundTasks):
    data = payload.dict()
    user_id = data.get("user_id", "default_user")
    
    # 1. Update Lifecycle State (Refinement Part 1)
    increment_sample_count(user_id)
    samples_total = get_sample_count(user_id)
    
    # 2. Database logging (strip device fields from behavior data)
    behavior_data = {k: v for k, v in data.items() if not k.startswith("device_") and k != "device_change_score" and k != "device_trust_status"}
    insert_behavior(behavior_data)
    
    # 3. Retraining trigger logic (every 200 samples)
    if samples_total % 200 == 0:
        background_tasks.add_task(retrain_model_task)

    # 4. Contextual & ML Inference
    thresholds = get_user_thresholds(user_id)
    raw_result = model_instance.predict(data, user_id=user_id, thresholds=thresholds)
    
    # Add to session history BEFORE aggregation
    add_session_risk(user_id, raw_result["risk_score"], raw_result["is_anomalous"])
    
    # 5. Robust Risk Aggregation (Memory-Based)
    final_score, final_level, final_action, final_reason = calculate_aggregated_risk(
        user_id, raw_result, samples_total
    )

    # 6. Response Engine Integration (non-breaking enrichment)
    if user_id not in _user_session_state:
        _user_session_state[user_id] = {
            "consecutive_anomalies": 0,
            "system_state": "NORMAL",
            "last_incident_id": None,
            "has_recent_mfa": False,
            "positive_feedback_count": 0
        }
    state = _user_session_state[user_id]

    is_anomalous = raw_result.get("is_anomalous", False)
    if is_anomalous:
        state["consecutive_anomalies"] += 1
    else:
        state["consecutive_anomalies"] = 0

    sig = raw_result.get("significance", {})
    deviating_features = sig.get("deviating_features", [])

    is_trusted_session = check_trusted_session(user_id)
    is_trusted_location = check_location_trust(user_id, data.get("city", ""), data.get("country", ""))
    is_new_location = data.get("is_new_location", False)

    device_hash = data.get("device_hash", "")
    unknown_device = False
    device_fingerprint_changed = False
    device_hardware_change_score = data.get("device_change_score", 0.0)
    trusted_device = False
    device_trust_info = None

    if device_hash:
        device_trust_info = check_device_trust(device_hash)
        if device_trust_info is None:
            register_device({
                "device_hash": device_hash,
                "hostname": data.get("device_hostname", ""),
                "os_version": data.get("device_os_version", ""),
                "windows_build": data.get("device_windows_build", ""),
                "user_id": user_id
            })
            unknown_device = True
        else:
            update_device_last_seen(device_hash)
            trusted_device = device_trust_info.get("trusted", False)
            device_fingerprint_changed = device_hardware_change_score >= 60
            if device_hardware_change_score >= 20:
                insert_device_history({
                    "device_hash": device_hash,
                    "event_type": "HARDWARE_CHANGE",
                    "details": json.dumps({"change_score": device_hardware_change_score, "timestamp": int(time.time())})
                })

    response_result = response_evaluate(
        risk_score=final_score,
        confidence=raw_result.get("confidence_score", 0.5),
        deviating_features=deviating_features,
        significance=sig,
        is_new_location=is_new_location,
        is_trusted_location=is_trusted_location,
        is_trusted_session=is_trusted_session,
        consecutive_anomalies=state["consecutive_anomalies"],
        has_positive_feedback=state["positive_feedback_count"] > 0,
        has_recent_mfa=state["has_recent_mfa"],
        has_failed_mfa=False,
        device_mismatch=unknown_device,
        unknown_device=unknown_device,
        device_fingerprint_changed=device_fingerprint_changed,
        device_hardware_change_score=device_hardware_change_score,
        trusted_device=trusted_device,
        current_system_state=state["system_state"],
        user_id=user_id
    )

    state["system_state"] = response_result["system_state"]

    incident_id = None
    if response_result.get("policy_matched"):
        insert_policy_audit({
            "policy_id": response_result["policy_matched"],
            "policy_name": response_result.get("recommendation", {}).get("possible_attack", ""),
            "user_id": user_id,
            "risk_score": final_score,
            "confidence": raw_result.get("confidence_score", 0),
            "matched": True,
            "action_taken": response_result["action"],
            "details": json.dumps(response_result)
        })

    if response_result.get("action") in ("STEP_UP_AUTH", "LOCK_SESSION", "RESTRICT") or response_result.get("risk_level_num", 0) >= 3:
        if state.get("last_incident_id") is None:
            incident_id = engine_create_incident(
                user_id=user_id,
                session_id=None,
                evaluation=response_result
            )
            state["last_incident_id"] = incident_id
            incident_data = {
                "incident_id": incident_id,
                "user_id": user_id,
                "session_id": f"SESS-{user_id}",
                "risk_score": final_score,
                "confidence": raw_result.get("confidence_score", 0),
                "evidence_score": response_result.get("evidence_score", 0),
                "severity": response_result.get("risk_level", "MEDIUM"),
                "status": "OPEN",
                "mitre_technique": response_result.get("mitre_technique", {}).get("technique_id", ""),
                "mitre_technique_name": response_result.get("mitre_technique", {}).get("technique_name", ""),
                "mitre_tactic": response_result.get("mitre_technique", {}).get("tactic", ""),
                "recommended_action": response_result.get("action", ""),
                "reason_json": json.dumps(response_result.get("recommendation", {})),
                "response_level": response_result.get("response_level", 0),
                "system_state": response_result.get("system_state", "NORMAL")
            }
            insert_incident(incident_data)

            severity = response_result.get("risk_level", "MEDIUM")
            if severity in ("HIGH", "CRITICAL"):
                containment_result = asyncio.create_task(
                    execute_containment(
                        incident=incident_data,
                        risk_score=final_score,
                        evidence_score=response_result.get("evidence_score", 0),
                        confidence=raw_result.get("confidence_score", 0),
                        policy_decision=response_result,
                    )
                )
                response_result["containment_triggered"] = True
                background_tasks.add_task(lambda: containment_result)

    insert_response_history({
        "user_id": user_id,
        "session_id": f"SESS-{user_id}",
        "risk_score": final_score,
        "confidence": raw_result.get("confidence_score", 0),
        "evidence_score": response_result.get("evidence_score", 0),
        "action_taken": response_result["action"],
        "response_level": response_result.get("response_level", 0),
        "system_state": response_result.get("system_state", "NORMAL"),
        "policy_id": response_result.get("policy_matched"),
        "incident_id": incident_id or state.get("last_incident_id"),
        "reasoning": json.dumps(response_result.get("recommendation", {}))
    })

    return {
        "risk_score": final_score,
        "risk_level": final_level,
        "action": final_action,
        "reason": final_reason,
        "confidence": raw_result.get("confidence_score"),
        "lifecycle_stage": "PROTECTED" if samples_total > 500 else ("MONITORING" if samples_total > 200 else "LEARNING"),
        "samples_collected": samples_total,
        "device_info": {
            "device_hash": device_hash[:16] + "..." if device_hash else None,
            "trusted": trusted_device,
            "unknown_device": unknown_device,
            "hardware_changed": device_fingerprint_changed,
            "change_score": device_hardware_change_score,
            "trust_status": device_trust_info.get("trust_status", "UNKNOWN") if device_trust_info else "UNKNOWN"
        } if device_hash else None,
        "response_engine": {
            "risk_level": response_result["risk_level"],
            "system_state": response_result["system_state"],
            "evidence_score": response_result["evidence_score"],
            "evidence_breakdown": response_result["evidence_breakdown"],
            "action": response_result["action"],
            "response_level": response_result["response_level"],
            "consecutive_anomalies": response_result["consecutive_anomalies"],
            "mitre_technique": response_result["mitre_technique"],
            "recommendation": response_result["recommendation"],
            "incident_id": state.get("last_incident_id") if response_result.get("risk_level_num", 0) >= 3 else None,
            "policy_matched": response_result.get("policy_matched")
        }
    }

class FeedbackPayload(BaseModel):
    behavior_id: int
    label: str # 'normal' or 'anomaly'

@app.post("/api/v1/feedback")
async def submit_feedback(payload: FeedbackPayload):
    """
    Submits user feedback to mark a specific behavior record as normal or anomalous.
    """
    try:
        insert_feedback(payload.behavior_id, payload.label)
        return {"status": "success", "message": "Feedback recorded."}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/v1/retrain")
async def manual_retrain(background_tasks: BackgroundTasks):
    """
    Manually trigger model retraining.
    """
    background_tasks.add_task(retrain_model_task)
    return {"message": "Retraining started in the background."}

def retrain_model_task():
    global model_instance
    print("Starting background retraining...")
    success = train_model()
    if success:
        print("Retraining successful. Reloading model.")
        model_instance = get_model_instance()
    else:
        print("Retraining failed or skipped due to insufficient data.")

@app.get("/health")
def health_check():
    return {
        "status": "online",
        "model_loaded": model_instance.model is not None if model_instance else False,
        "records_buffered": RECORDS_SINCE_LAST_TRAIN
    }

@app.get("/api/v1/dashboard/stats")
def dashboard_stats():
    total_records = get_total_record_count()
    profiles = get_user_profiles_all()
    return {
        "total_records": total_records,
        "total_users": len(profiles),
        "users": profiles.to_dict(orient="records") if not profiles.empty else []
    }

@app.get("/api/v1/dashboard/sessions/{user_id}")
def dashboard_sessions(user_id: str, limit: int = 50):
    history = get_session_history_all(user_id=user_id, limit=limit)
    return {
        "user_id": user_id,
        "sessions": history.to_dict(orient="records") if not history.empty else []
    }

@app.get("/api/v1/dashboard/behavior/{user_id}")
def dashboard_behavior(user_id: str, limit: int = 100):
    behavior = get_behavior_by_user(user_id, limit=limit)
    return {
        "user_id": user_id,
        "records": behavior.to_dict(orient="records") if not behavior.empty else []
    }

@app.get("/api/v1/dashboard/locations")
def dashboard_locations():
    locations = get_trusted_locations_all()
    return {
        "locations": locations.to_dict(orient="records") if not locations.empty else []
    }

@app.get("/api/v1/dashboard/thresholds/{user_id}")
def dashboard_thresholds(user_id: str):
    thresholds = get_user_thresholds(user_id)
    sample_count = get_sample_count(user_id)
    return {
        "user_id": user_id,
        "thresholds": thresholds,
        "samples_collected": sample_count
    }

@app.get("/api/v1/incidents")
def list_incidents(user_id: str = None, status: str = None, limit: int = 50):
    df = get_incidents(user_id=user_id, status=status, limit=limit)
    return {
        "incidents": json.loads(df.to_json(orient="records")) if not df.empty else []
    }

@app.get("/api/v1/incidents/{incident_id}")
def get_incident_detail(incident_id: str):
    incident = get_incident_by_id(incident_id)
    if incident is None:
        raise HTTPException(status_code=404, detail="Incident not found")
    return incident

@app.put("/api/v1/incidents/{incident_id}/status")
def update_incident(incident_id: str, payload: dict):
    new_status = payload.get("status")
    if new_status not in ("OPEN", "UNDER_INVESTIGATION", "VERIFICATION_PENDING", "CONTAINED", "RESOLVED", "CLOSED"):
        raise HTTPException(status_code=400, detail=f"Invalid status: {new_status}")
    notes = payload.get("resolution_notes")
    update_incident_status(incident_id, new_status, resolution_notes=notes)
    engine_update_status(incident_id, new_status, resolution_notes=notes)
    return {"status": "updated", "incident_id": incident_id, "new_status": new_status}

@app.post("/api/v1/mfa-result")
def mfa_result(payload: dict):
    user_id = payload.get("user_id", "default_user")
    success = payload.get("success", False)

    if user_id not in _user_session_state:
        _user_session_state[user_id] = {
            "consecutive_anomalies": 0,
            "system_state": "NORMAL",
            "last_incident_id": None,
            "has_recent_mfa": False,
            "positive_feedback_count": 0
        }
    state = _user_session_state[user_id]

    if success:
        state["has_recent_mfa"] = True
        incident_id = state.get("last_incident_id")
        if incident_id:
            recovered = resolve_incident_on_recovery(
                incident_id=incident_id,
                evaluation={
                    "risk_level": state.get("risk_level", "MEDIUM"),
                    "risk_level_num": state.get("risk_level_num", 2),
                    "response_level": state.get("response_level", 2),
                    "system_state": state.get("system_state", "OBSERVATION"),
                    "action": "OBSERVE",
                    "evidence_score": state.get("evidence_score", 50),
                    "recommendation": {"reasons": [], "recommended_action": ""}
                },
                mfa_success=True
            )
            update_incident_status(incident_id, "RESOLVED", resolution_notes="MFA completed successfully")
            state["last_incident_id"] = None
            state["system_state"] = "OBSERVATION"
            return {"status": "recovered", "incident_id": incident_id, "new_state": recovered}
        state["system_state"] = "NORMAL"
        return {"status": "mfa_success", "message": "MFA successful, state normalized"}
    else:
        if state["consecutive_anomalies"] < 3:
            state["consecutive_anomalies"] += 2
        return {"status": "mfa_failed", "message": "MFA failed, risk escalated"}

@app.get("/api/v1/response-history")
def response_history(user_id: str = None, limit: int = 100):
    df = get_response_history(user_id=user_id, limit=limit)
    return {
        "history": json.loads(df.to_json(orient="records")) if not df.empty else []
    }

@app.get("/api/v1/policy-audit")
def policy_audit(limit: int = 100):
    df = get_policy_audit(limit=limit)
    return {
        "audit": json.loads(df.to_json(orient="records")) if not df.empty else []
    }

@app.get("/api/v1/mitre-techniques")
def mitre_techniques():
    return {"techniques": get_all_techniques()}

@app.get("/api/v1/devices")
def list_devices(limit: int = 100):
    from backend.db import get_all_devices
    df = get_all_devices(limit=limit)
    return {
        "devices": json.loads(df.to_json(orient="records")) if not df.empty else []
    }

@app.post("/api/v1/devices/approve")
def approve_device(payload: dict):
    from backend.db import approve_device as approve_device_db
    device_hash = payload.get("device_hash")
    notes = payload.get("notes")
    if not device_hash:
        raise HTTPException(status_code=400, detail="device_hash required")
    success = approve_device_db(device_hash, notes=notes)
    if not success:
        raise HTTPException(status_code=404, detail="Device not found")
    return {"status": "approved", "device_hash": device_hash}

@app.post("/api/v1/devices/revoke")
def revoke_device(payload: dict):
    from backend.db import revoke_device as revoke_device_db
    device_hash = payload.get("device_hash")
    if not device_hash:
        raise HTTPException(status_code=400, detail="device_hash required")
    success = revoke_device_db(device_hash)
    if not success:
        raise HTTPException(status_code=404, detail="Device not found")
    return {"status": "revoked", "device_hash": device_hash}

@app.get("/api/v1/devices/history")
def device_history(device_hash: str = None, limit: int = 100):
    from backend.db import get_device_history
    df = get_device_history(device_hash=device_hash, limit=limit)
    return {
        "history": json.loads(df.to_json(orient="records")) if not df.empty else []
    }

@app.post("/api/v1/agent/heartbeat")
def agent_heartbeat(payload: dict):
    upsert_agent_heartbeat(payload)
    return {"status": "ok", "device_id": payload.get("device_id", "")}

@app.get("/api/v1/agent/status/{device_id}")
def agent_status(device_id: str):
    hb = get_agent_heartbeat(device_id)
    if hb is None:
        raise HTTPException(status_code=404, detail="Agent not found")
    return {"status": "ok", "heartbeat": hb}

@app.get("/api/v1/user-state/{user_id}")
def user_state(user_id: str):
    state = _user_session_state.get(user_id, {
        "consecutive_anomalies": 0,
        "system_state": "NORMAL",
        "last_incident_id": None,
        "has_recent_mfa": False,
        "positive_feedback_count": 0
    })
    return {"user_id": user_id, "state": state}

@app.get("/api/v1/incidents/{incident_id}/containment")
def incident_containment(incident_id: str):
    df = get_containment_actions(incident_id=incident_id)
    actions = json.loads(df.to_json(orient="records")) if not df.empty else []
    return {"incident_id": incident_id, "containment_actions": actions}

@app.post("/api/v1/incidents/{incident_id}/contain")
async def trigger_containment(incident_id: str):
    incident = get_incident_by_id(incident_id)
    if incident is None:
        raise HTTPException(status_code=404, detail="Incident not found")
    from forensics.evidence_packer import EvidencePacker
    pkg_info = EvidencePacker.get_package_info(incident_id)
    if pkg_info:
        return {
            "status": "already_contained",
            "incident_id": incident_id,
            "evidence": pkg_info,
        }
    result = await execute_containment(
        incident=incident,
        risk_score=incident.get("risk_score", 0),
        evidence_score=incident.get("evidence_score", 0),
        confidence=incident.get("confidence", 0),
        policy_decision={
            "restrictions": ["lock_session", "notify_security_team"],
            "risk_level": incident.get("severity", "MEDIUM"),
        },
        db_interface=__import__("backend.db", fromlist=[""]),
    )
    return result

@app.get("/api/v1/incidents/{incident_id}/evidence")
def incident_evidence(incident_id: str):
    from forensics.evidence_packer import EvidencePacker
    pkg_info = EvidencePacker.get_package_info(incident_id)
    if pkg_info:
        return pkg_info
    return {
        "incident_id": incident_id,
        "package_available": False,
        "message": "No evidence package found for this incident",
    }

@app.get("/api/v1/incidents/{incident_id}/evidence/download")
def download_evidence(incident_id: str):
    from forensics.evidence_packer import EvidencePacker
    from fastapi.responses import FileResponse
    zip_path = EvidencePacker.get_package_path(incident_id)
    if not os.path.exists(zip_path):
        raise HTTPException(status_code=404, detail="Evidence package not found")
    return FileResponse(
        path=zip_path,
        media_type="application/zip",
        filename=f"{incident_id}.zip",
        headers={"Content-Disposition": f"attachment; filename={incident_id}.zip"},
    )

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app:app", host="0.0.0.0", port=8000, reload=True)
