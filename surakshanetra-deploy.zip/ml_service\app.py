import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from fastapi import FastAPI
from contextlib import asynccontextmanager

from ml_service.state import model_instance
from ml_service.routers.analyze import router as analyze_router
from ml_service.routers.dashboard import router as dashboard_router
from ml_service.routers.incidents import router as incidents_router
from ml_service.routers.devices import router as devices_router
from ml_service.routers.agent import router as agent_router
from ml_service.routers.misc import router as misc_router


@asynccontextmanager
async def lifespan(app: FastAPI):
    print("ML Service Started. Model instance loaded.")
    yield
    print("ML Service shutting down.")


app = FastAPI(
    title="Continuous Behavioral Auth API",
    description="Upgraded ML Microservice with SQLite Integration & Continuous Learning",
    version="2.0.0",
    lifespan=lifespan,
)

app.include_router(analyze_router)
app.include_router(dashboard_router)
app.include_router(incidents_router)
app.include_router(devices_router)
app.include_router(agent_router)
app.include_router(misc_router)


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("ml_service.app:app", host="0.0.0.0", port=8000, reload=True)
