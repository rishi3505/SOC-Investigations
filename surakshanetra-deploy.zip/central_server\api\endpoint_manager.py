"""
Endpoint Manager — CRUD, search, filter, tag management for all registered endpoints
"""
import json
import time
from fastapi import APIRouter, Depends, HTTPException, Query
from ..database import get_connection
from ..auth import authenticate_request

router = APIRouter(prefix="/api/v1/endpoints", tags=["Endpoint Manager"])


@router.get("")
async def list_endpoints(
    org_id: int = None,
    health_status: str = None,
    search: str = None,
    tags: str = None,
    page: int = Query(1, ge=1),
    limit: int = Query(50, ge=1, le=100),
    user: dict = Depends(authenticate_request),
):
    conn = get_connection()
    cursor = conn.cursor()
    conditions = []
    params = []
    if user.get("org_id"):
        conditions.append("e.org_id = ?")
        params.append(user["org_id"])
    if org_id:
        conditions.append("e.org_id = ?")
        params.append(org_id)
    if health_status:
        conditions.append("e.health_status = ?")
        params.append(health_status.upper())
    if search:
        conditions.append("(e.hostname LIKE ? OR e.endpoint_id LIKE ? OR e.ip_address LIKE ?)")
        s = f"%{search}%"
        params.extend([s, s, s])
    if tags:
        conditions.append("e.tags LIKE ?")
        params.append(f"%{tags}%")
    where = "WHERE " + " AND ".join(conditions) if conditions else ""
    offset = (page - 1) * limit
    cursor.execute(f"SELECT e.*, (SELECT COUNT(*) FROM heartbeats h WHERE h.endpoint_id = e.endpoint_id) as heartbeat_count FROM endpoints e {where} ORDER BY e.last_seen DESC LIMIT ? OFFSET ?", (*params, limit, offset))
    rows = cursor.fetchall()
    cursor.execute(f"SELECT COUNT(*) FROM endpoints e {where}", params)
    total = cursor.fetchone()[0]
    conn.close()
    return {
        "endpoints": [dict(r) for r in rows],
        "total": total,
        "page": page,
        "limit": limit,
    }


@router.get("/{endpoint_id}")
async def get_endpoint(endpoint_id: str, user: dict = Depends(authenticate_request)):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM endpoints WHERE endpoint_id = ?", (endpoint_id,))
    row = cursor.fetchone()
    conn.close()
    if not row:
        raise HTTPException(status_code=404, detail="Endpoint not found")
    return {"endpoint": dict(row)}


@router.put("/{endpoint_id}/tags")
async def update_tags(endpoint_id: str, payload: dict, user: dict = Depends(authenticate_request)):
    tags = payload.get("tags", [])
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE endpoints SET tags = ? WHERE endpoint_id = ?", (json.dumps(tags), endpoint_id))
    conn.commit()
    conn.close()
    return {"status": "updated", "endpoint_id": endpoint_id, "tags": tags}


@router.put("/{endpoint_id}/metadata")
async def update_metadata(endpoint_id: str, payload: dict, user: dict = Depends(authenticate_request)):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE endpoints SET metadata = ? WHERE endpoint_id = ?", (json.dumps(payload.get("metadata", {})), endpoint_id))
    conn.commit()
    conn.close()
    return {"status": "updated", "endpoint_id": endpoint_id}


@router.get("/{endpoint_id}/timeline")
async def get_endpoint_timeline(
    endpoint_id: str,
    limit: int = Query(100, ge=1, le=500),
    user: dict = Depends(authenticate_request),
):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT timestamp, 'heartbeat' as event_type, health_status as detail FROM heartbeats
        WHERE endpoint_id = ? UNION ALL
        SELECT created_at as timestamp, 'incident' as event_type, severity as detail FROM incidents
        WHERE endpoint_id = ? UNION ALL
        SELECT timestamp, 'behavior' as event_type, 'risk_score' as detail FROM behavior_data
        WHERE endpoint_id = ?
        ORDER BY timestamp DESC LIMIT ?
    """, (endpoint_id, endpoint_id, endpoint_id, limit))
    rows = cursor.fetchall()
    conn.close()
    return {"endpoint_id": endpoint_id, "events": [dict(r) for r in rows]}


@router.get("/{endpoint_id}/heartbeats")
async def get_endpoint_heartbeats(
    endpoint_id: str,
    limit: int = Query(100, ge=1, le=500),
    user: dict = Depends(authenticate_request),
):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM heartbeats WHERE endpoint_id = ? ORDER BY timestamp DESC LIMIT ?", (endpoint_id, limit))
    rows = cursor.fetchall()
    conn.close()
    return {"endpoint_id": endpoint_id, "heartbeats": [dict(r) for r in rows]}
