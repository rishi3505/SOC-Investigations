import logging
import logging.handlers
import os
import json
import threading
from datetime import datetime

_lock = threading.Lock()
_initialized = False

LOG_NAMES = {
    "service": "service.log",
    "health": "health.log",
    "communication": "communication.log",
    "agent": "agent.log",
}

_loggers: dict = {}

_DEFAULT_FORMAT = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
_DEFAULT_DATE_FORMAT = "%Y-%m-%d %H:%M:%S"


def _ensure_log_dir(log_dir: str):
    if not os.path.exists(log_dir):
        os.makedirs(log_dir, exist_ok=True)


def _create_file_handler(log_path: str, level: int, max_bytes: int, backup_count: int):
    handler = logging.handlers.RotatingFileHandler(
        log_path, maxBytes=max_bytes, backupCount=backup_count, encoding="utf-8"
    )
    handler.setLevel(level)
    formatter = logging.Formatter(_DEFAULT_FORMAT, datefmt=_DEFAULT_DATE_FORMAT)
    handler.setFormatter(formatter)
    return handler


def _create_console_handler(level: int):
    handler = logging.StreamHandler()
    handler.setLevel(level)
    formatter = logging.Formatter(_DEFAULT_FORMAT, datefmt=_DEFAULT_DATE_FORMAT)
    handler.setFormatter(formatter)
    return handler


def setup_logging(config: dict = None):
    global _initialized

    with _lock:
        if _initialized:
            return

        log_dir = "logs"
        level_name = "INFO"
        max_mb = 10
        backup_count = 5

        if config and isinstance(config, dict):
            lc = config.get("logging", {})
            log_dir = lc.get("directory", log_dir)
            level_name = lc.get("level", level_name)
            max_mb = int(lc.get("max_file_size_mb", max_mb))
            backup_count = int(lc.get("backup_count", backup_count))

        level = getattr(logging, level_name.upper(), logging.INFO)
        max_bytes = max_mb * 1024 * 1024

        agent_dir = os.path.dirname(os.path.abspath(__file__))
        if os.path.isabs(log_dir):
            log_dir = os.path.basename(log_dir)
        log_path = os.path.normpath(os.path.join(agent_dir, log_dir))
        _ensure_log_dir(log_path)

        for name, filename in LOG_NAMES.items():
            logger = logging.getLogger(f"surakshanetra.{name}")
            logger.setLevel(level)
            logger.handlers.clear()

            file_path = os.path.join(log_path, filename)
            file_handler = _create_file_handler(file_path, level, max_bytes, backup_count)
            logger.addHandler(file_handler)

            console = _create_console_handler(level)
            logger.addHandler(console)

            logger.propagate = False
            _loggers[name] = logger

        _initialized = True


def get_logger(module_name: str):
    if not _initialized:
        setup_logging()
    return logging.getLogger(f"surakshanetra.{module_name}")


def reconfigure_logging(config: dict):
    global _initialized
    with _lock:
        _initialized = False
        for logger in _loggers.values():
            logger.handlers.clear()
        _loggers.clear()
    setup_logging(config)


def get_log_file_paths(log_dir: str = None) -> dict:
    if not log_dir:
        agent_dir = os.path.dirname(os.path.abspath(__file__))
        log_dir = os.path.join(agent_dir, "logs")
    return {name: os.path.join(log_dir, fname) for name, fname in LOG_NAMES.items()}
