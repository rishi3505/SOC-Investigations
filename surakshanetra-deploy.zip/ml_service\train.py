import os
import sys
from pathlib import Path
import pandas as pd
from sklearn.ensemble import IsolationForest
import joblib

# Add parent directory to path to import backend.db
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from backend.db import fetch_training_data, fetch_feedback_labeled_data, update_user_thresholds, add_trusted_location, init_db
from ml_service.preprocessing import create_preprocessing_pipeline, save_preprocessing_artifacts, NUMERICAL_FEATURES, CATEGORICAL_FEATURES
import numpy as np

MODELS_DIR = Path(__file__).resolve().parent / "models"
MIN_RECORDS_FOR_TRAINING = 500

# Ordered CSV fallback paths (searched top-to-bottom)
CSV_FALLBACK_PATHS = [
    PROJECT_ROOT / "agent" / "data" / "behavior_data.csv",
    PROJECT_ROOT / "data" / "behavior_data.csv",
    PROJECT_ROOT / "ml_service" / "data" / "behavior_data.csv",
]

def train_model():
    """
    Main training function. Loads data, preprocesses, trains, and saves the model.
    """
    print("Ensuring database is initialized...")
    init_db()

    print("Loading data for training...")
    
    # Try loading from DB first
    try:
        df = fetch_training_data()
        print(f"Loaded {len(df)} records from SQLite ({PROJECT_ROOT / 'data' / 'behavior.db'}).")
    except Exception as e:
        print(f"Error fetching from DB: {e}. Falling back to CSV.")
        df = pd.DataFrame()

    # Fallback: search known CSV paths in order
    if len(df) < MIN_RECORDS_FOR_TRAINING:
        csv_loaded = False
        for csv_path in CSV_FALLBACK_PATHS:
            if csv_path.exists():
                try:
                    csv_df = pd.read_csv(str(csv_path))
                    print(f"Loaded {len(csv_df)} records from CSV: {csv_path}")
                    df = pd.concat([df, csv_df], ignore_index=True).drop_duplicates()
                    csv_loaded = True
                    break
                except pd.errors.EmptyDataError:
                    print(f"CSV at {csv_path} is empty, skipping.")
                except Exception as e:
                    print(f"Error reading CSV at {csv_path}: {e}")
        if not csv_loaded:
            print(f"No CSV dataset found. Searched paths:")
            for p in CSV_FALLBACK_PATHS:
                print(f"  - {p} {'(EXISTS)' if p.exists() else '(NOT FOUND)'}")
            print("Run: python scripts/seed_demo_data.py to generate demo data first.")

    if len(df) < MIN_RECORDS_FOR_TRAINING:
        print(f"CRITICAL: Insufficient data for training. Need {MIN_RECORDS_FOR_TRAINING}, found {len(df)}.")
        return False

    # 1. Integrate Feedback Data (Part 6 & 7)
    try:
        feedback_df = fetch_feedback_labeled_data()
        if not feedback_df.empty:
            print(f"Integrating {len(feedback_df)} user-labeled feedback records.")
            # Ensure feedback data that is labeled 'normal' is included and prioritized
            # (In this simple version, we just append it, but we could duplicate it to increase weight)
            normal_feedback = feedback_df[feedback_df['feedback_label'] == 'normal'].copy()
            if not normal_feedback.empty:
                normal_feedback = normal_feedback.drop(columns=['feedback_label'])
                df = pd.concat([df, normal_feedback], ignore_index=True).drop_duplicates()
    except Exception as e:
        print(f"Error fetching feedback data: {e}")

    print("Preprocessing data...")
    # Drop timestamp if it exists as it's not a feature
    if 'timestamp' in df.columns:
        df = df.drop(columns=['timestamp'])
    
    # Handle missing values: only drop if features used for training are missing
    df = df.dropna(subset=NUMERICAL_FEATURES + CATEGORICAL_FEATURES)
    
    X = df
    
    # Create and fit preprocessing pipeline
    pipeline = create_preprocessing_pipeline()
    X_transformed = pipeline.fit_transform(X)
    
    print("Training Isolation Forest model...")
    model = IsolationForest(n_estimators=100, contamination=0.05, random_state=42)
    model.fit(X_transformed)
    
    # Save artifacts
    MODELS_DIR.mkdir(parents=True, exist_ok=True)
    joblib.dump(model, str(MODELS_DIR / 'model.pkl'))
    save_preprocessing_artifacts(pipeline, df)

    # 2. Calculate Adaptive Thresholds (Robust Version)
    from ml_service.anomaly_model import AnomalyModel
    temp_model = AnomalyModel()

    scores = []
    print("Calculating robust adaptive thresholds...")
    for _, row in df.iterrows():
        res = temp_model.predict(row.to_dict())
        scores.append(res["risk_score"])

    scores = np.array(scores)
    median_score = np.median(scores)

    # MAD = Median(|X_i - Median(X)|)
    mad = np.median(np.abs(scores - median_score))

    # Consistency constant for normal distribution is 1.4826
    # Robust standard deviation proxy: 1.4826 * MAD
    robust_std = 1.4826 * mad

    # User's Logic with robust bounds
    low_t = round(median_score + (0.5 * robust_std), 2)
    med_t = round(median_score + (1.2 * robust_std), 2)
    high_t = round(median_score + (2.0 * robust_std), 2)

    # Safety Floor: Ensure thresholds don't drop to zero in perfectly uniform data
    low_t = max(low_t, 30.0)
    med_t = max(med_t, 55.0)
    high_t = max(high_t, 80.0)

    print(f"Robust Thresholds for 'default_user': LOW={low_t}, MED={med_t}, HIGH={high_t}")
    update_user_thresholds("default_user", low_t, med_t, high_t)

    # 3. Auto-Trust Locations (Part 2)
    # If a location has > 10 records with is_new_location==False, we trust it.
    try:
        location_counts = df[df['is_new_location'] == False].groupby(['user_id', 'city', 'country']).size().reset_index(name='counts')
        for _, row in location_counts.iterrows():
            if row['counts'] >= 10:
                city_clean = row['city'].encode('ascii', 'ignore').decode()
                country_clean = row['country'].encode('ascii', 'ignore').decode()
                print(f"Auto-trusting location: {city_clean}, {country_clean} for user {row['user_id']}")
                add_trusted_location(row['user_id'], row['city'], row['country'])
    except Exception as e:
        print(f"Error auto-trusting locations: {e}")

    print("[DONE] Model, adaptive thresholds, and trusted locations updated successfully.")
    return True

if __name__ == "__main__":
    success = train_model()
    if not success:
        sys.exit(1)
