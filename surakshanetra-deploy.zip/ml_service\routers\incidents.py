import json
import os
import sys

sys.path.append(os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.append(os.path.join(os.path.dirname(__file__), ".."))

from fastapi import APIRouter, HTTPException

from backend.db import (
    get_incidents, get_incident_by_id, update_incident_status,
    get_containment_actions, get_evidence_packages, get_evidence_package_by_incident,
)

router = APIRouter()


@router.get("/api/v1/incidents")
def list_incidents(user_id: str = None, status: str = None, limit: int = 50):
    df = get_incidents(user_id=user_id, status=status, limit=limit)
    return {"incidents": json.loads(df.to_json(orient="records")) if not df.empty else []}


@router.get("/api/v1/incidents/{incident_id}")
def get_incident_detail(incident_id: str):
    incident = get_incident_by_id(incident_id)
    if incident is None:
        raise HTTPException(status_code=404, detail="Incident not found")
    return incident


@router.put("/api/v1/incidents/{incident_id}/status")
def update_incident(incident_id: str, payload: dict):
    new_status = payload.get("status")
    if new_status not in ("OPEN", "UNDER_INVESTIGATION", "VERIFICATION_PENDING", "CONTAINED", "RESOLVED", "CLOSED"):
        raise HTTPException(status_code=400, detail=f"Invalid status: {new_status}")
    notes = payload.get("resolution_notes")
    update_incident_status(incident_id, new_status, resolution_notes=notes)
    try:
        from backend.response_engine import update_incident_status as engine_update
        engine_update(incident_id, new_status, resolution_notes=notes)
    except Exception:
        pass
    return {"status": "updated", "incident_id": incident_id, "new_status": new_status}


@router.get("/api/v1/incidents/{incident_id}/containment")
def incident_containment(incident_id: str):
    df = get_containment_actions(incident_id=incident_id)
    actions = json.loads(df.to_json(orient="records")) if not df.empty else []
    return {"incident_id": incident_id, "containment_actions": actions}


@router.post("/api/v1/incidents/{incident_id}/contain")
async def trigger_containment(incident_id: str):
    incident = get_incident_by_id(incident_id)
    if incident is None:
        raise HTTPException(status_code=404, detail="Incident not found")
    from forensics.evidence_packer import EvidencePacker
    pkg_info = EvidencePacker.get_package_info(incident_id)
    if pkg_info:
        return {"status": "already_contained", "incident_id": incident_id, "evidence": pkg_info}
    from backend.containment_engine import execute_containment
    result = await execute_containment(
        incident=incident, risk_score=incident.get("risk_score", 0),
        evidence_score=incident.get("evidence_score", 0),
        confidence=incident.get("confidence", 0),
        policy_decision={"restrictions": ["lock_session", "notify_security_team"],
                          "risk_level": incident.get("severity", "MEDIUM")},
        db_interface=__import__("backend.db", fromlist=[""]),
    )
    return result


@router.get("/api/v1/incidents/{incident_id}/evidence")
def incident_evidence(incident_id: str):
    from forensics.evidence_packer import EvidencePacker
    pkg_info = EvidencePacker.get_package_info(incident_id)
    if pkg_info:
        return pkg_info
    return {"incident_id": incident_id, "package_available": False, "message": "No evidence package found for this incident"}


@router.get("/api/v1/incidents/{incident_id}/evidence/download")
def download_evidence(incident_id: str):
    from forensics.evidence_packer import EvidencePacker
    from fastapi.responses import FileResponse
    zip_path = EvidencePacker.get_package_path(incident_id)
    if not os.path.exists(zip_path):
        raise HTTPException(status_code=404, detail="Evidence package not found")
    return FileResponse(path=zip_path, media_type="application/zip",
                        filename=f"{incident_id}.zip",
                        headers={"Content-Disposition": f"attachment; filename={incident_id}.zip"})
