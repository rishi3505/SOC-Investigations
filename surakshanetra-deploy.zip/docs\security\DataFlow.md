# SurakshaNetra — Data Flow Diagrams

## Version 1.0 — RC1

---

## 1. Behavior Data Ingestion Flow

```
[Agent Process]                     [CMS]                          [ML Service]
     |                                |                                |
     |-- 1. Collect keystroke/        |                                |
     |    mouse/process data          |                                |
     |-- 2. Buffer in _queue.json     |                                |
     |-- 3. POST /api/v1/analyze ---->|                                |
     |    (JSON payload)              |                                |
     |                                |-- 4. Validate API key/JWT      |
     |                                |-- 5. Forward to ML service --->|
     |                                |    (HTTP localhost:8000)       |
     |                                |                                |-- 6. Model inference
     |                                |                                |-- 7. Risk score
     |                                |<-- 8. Score + anomalies -------|
     |                                |                                |
     |                                |-- 9. Store in behavior.db      |
     |<-- 10. 200 OK -----------------|                                |
```

**Data Stores**: `behavior.db`, `_queue.json` (agent-side), `buffer.json` (agent-side fallback)

**Security Controls**:
- HTTPS between agent and CMS
- API key or JWT authentication on `/api/v1/analyze`
- ML service only accessible on localhost
- Offline queue with exponential backoff

---

## 2. Authentication Flow

```
[SOC Admin]                    [CMS API]                    [SQLite]
     |                            |                            |
     |-- 1. POST /auth/login ---->|                            |
     |    {username, password}    |-- 2. SHA-256 hash password |
     |                            |-- 3. Query central.db ---->|
     |                            |<-- 4. User record ---------|
     |                            |                            |
     |                            |-- 5. Verify password hash  |
     |                            |-- 6. Generate JWT          |
     |<-- 7. 200 OK {token} ------|    (HS256, 24h expiry)     |
     |                            |                            |
     |-- 8. GET /endpoints ------>|                            |
     |    Authorization: Bearer   |-- 9. Verify JWT signature  |
     |    <token>                 |-- 10. Extract roles        |
     |                            |-- 11. Authorize access     |
     |<-- 12. 200 OK {data} ------|                            |
```

**Data Stores**: `central.db` (users table), JWT (in-memory client-side)

**Security Controls**:
- JWT signed with `secrets.token_hex(32)` key
- 24-hour token expiry
- Password hashed with SHA-256 (to be bcrypt)
- No token persistence in localStorage; Authorization header only
- API key alternative for machine-to-machine

---

## 3. Remote Command Flow

```
[SOC Admin]                 [CMS API]                    [Agent]              [DB]
     |                          |                           |                    |
     |-- POST /commands/issue ->|                           |                    |
     |   {type, target, params}|                           |                    |
     |                          |-- 1. Issue JWT for command|                    |
     |                          |-- 2. HMAC-SHA256 sign     |                    |
     |                          |-- 3. INSERT command ----->|                    |
     |<-- {command_id} ---------|                           |                    |
     |                          |                           |                    |
     |                          |<-- GET /commands/poll ----|                    |
     |                          |    (Agent polls every 30s)|                    |
     |                          |-- 4. Query pending ------>|                    |
     |                          |<-- pending commands ------|                    |
     |                          |-- 5. Deliver to agent --->|                    |
     |                          |                           |-- 6. Execute       |
     |                          |                           |-- 7. Log result    |
     |                          |<-- POST /commands/ack ----|                    |
     |                          |<-- POST /commands/complete|                    |
     |                          |-- 8. Update status ------>|                    |
     |                          |                           |                    |
     |<-- GET /commands/{id} ---|                           |                    |
     |    (status check)        |                           |                    |
```

**Data Stores**: `remote_commands` table

**Security Controls**:
- HMAC-SHA256 signing with `secrets.token_hex(32)` key
- Command expiry (30-minute window)
- Replay protection via command_id per agent
- Agent must poll; no push to agents
- JWT auth on all admin command endpoints

---

## 4. Forensics Evidence Flow

```
[Incident Trigger] -> [Forensics Engine] -> [Evidence Packer] -> [CMS Storage]
       |                      |                      |                    |
       |-- Collect artifacts  |                      |                    |
       |-- Chain of custody   |                      |                    |
       |                      |-- Hash evidence      |                    |
       |                      |-- Create manifest    |                    |
       |                      |                      |-- Package ZIP      |
       |                      |                      |-- Store in evidence/|
       |                      |                      |                    |
       |                      |                      |<-- SOC Admin -----|
       |                      |                      |    GET /evidence/ |
       |                      |                      |    download       |
```

**Data Stores**: `evidence/{incident_id}/` directory, ZIP archives

**Security Controls**:
- `incident_id` sanitized with `re.sub(r'[^a-zA-Z0-9_\-]', '_', ...)` — all path constructions
- Download endpoint validates `os.path.commonpath` against evidence base dir
- SHA-256 hash manifest for integrity verification
- Chain of custody tracking

---

## 5. Dashboard Query Flow

```
[SOC Browser]                 [Vite Dev Server]            [CMS API]              [SQLite]
     |                             |                            |                    |
     |-- React App loads --------->|                            |                    |
     |<-- JS bundle ---------------|                            |                    |
     |                             |                            |                    |
     |-- User logs in              |                            |                    |
     |-- POST /auth/login -------->|                            |                    |
     |<-- JWT token --------------|                            |                    |
     |                             |                            |                    |
     |-- GET /endpoints ---------->|                            |                    |
     |   Authorization: Bearer    |-- Proxy to :9000 ---------->|-- Query DB ------->|
     |   <token>                  |                             |<-- Results --------|
     |                             |<-- 200 OK {endpoints} -----|                    |
     |<-- Render endpoint table    |                            |                    |
     |                             |                            |                    |
     |-- GET /health/summary ----->|                            |-- Query DB ------->|
     |                             |<-- 200 OK {overview} ------|<-- Results --------|
     |<-- Health scorecards        |                            |                    |
```

**Security Controls**:
- JWT auth on all CMS proxied requests
- React JSX auto-escapes against XSS
- Vite dev server runs on separate port (5173) from CMS (9000)
- API proxy in Vite config (no CORS issues in dev)

---

## 6. Threat Intelligence Flow

```
[External Feeds] -> [Feed Manager] -> [IOC Store]   -> [Analysis Engine] -> [Incidents]
     |                    |                 |                 |                    |
     |-- AlienVault OTX   |-- Fetch HTTPS   |-- Store IOCs    |-- Match against   |
     |-- MISP             |-- Parse JSON    |-- TAXII feed    |    behavioral      |
     |-- Custom feeds     |-- Validate      |-- Expiry TTL    |    data            |
     |                    |                 |                 |-- Generate alerts  |
```

**Data Stores**: `threat_intelligence/ioc_store.db` (SQLite)

**Security Controls**:
- Feeds fetched over HTTPS only
- JSON parsing with `json.loads()` (safe from prototype pollution)
- Feed validation against known feed list
- Auth on all threat intel API endpoints
