"""
Incident Router — receive, deduplicate, and route incidents from all endpoints
"""
import json
import time
import uuid
from fastapi import APIRouter, Depends, HTTPException, Query
from ..database import get_connection
from ..auth import authenticate_request
from ..models import UpdateIncidentStatusRequest

router = APIRouter(prefix="/api/v1/incidents", tags=["Incident Router"])


@router.get("")
async def list_incidents(
    endpoint_id: str = None,
    org_id: int = None,
    severity: str = None,
    status: str = None,
    mitre_technique: str = None,
    search: str = None,
    page: int = Query(1, ge=1),
    limit: int = Query(50, ge=1, le=100),
    user: dict = Depends(authenticate_request),
):
    conn = get_connection()
    cursor = conn.cursor()
    conditions = []
    params = []
    if user.get("org_id"):
        conditions.append("i.org_id = ?")
        params.append(user["org_id"])
    if endpoint_id:
        conditions.append("i.endpoint_id = ?")
        params.append(endpoint_id)
    if severity:
        conditions.append("i.severity = ?")
        params.append(severity.upper())
    if status:
        conditions.append("i.status = ?")
        params.append(status.upper())
    if mitre_technique:
        conditions.append("i.mitre_technique LIKE ?")
        params.append(f"%{mitre_technique}%")
    if search:
        conditions.append("(i.incident_id LIKE ? OR i.user_id LIKE ? OR i.mitre_technique LIKE ?)")
        s = f"%{search}%"
        params.extend([s, s, s])
    where = "WHERE " + " AND ".join(conditions) if conditions else ""
    offset = (page - 1) * limit
    cursor.execute(f"""
        SELECT i.*, e.hostname as endpoint_hostname
        FROM incidents i
        LEFT JOIN endpoints e ON i.endpoint_id = e.endpoint_id
        {where}
        ORDER BY i.created_at DESC LIMIT ? OFFSET ?
    """, (*params, limit, offset))
    rows = cursor.fetchall()
    cursor.execute(f"SELECT COUNT(*) FROM incidents i {where}", params)
    total = cursor.fetchone()[0]
    conn.close()
    return {"incidents": [dict(r) for r in rows], "total": total, "page": page, "limit": limit}


@router.get("/stats")
async def incident_stats(user: dict = Depends(authenticate_request)):
    conn = get_connection()
    cursor = conn.cursor()
    now = int(time.time())
    day_ago = now - 86400
    week_ago = now - 604800

    stats = {}
    cursor.execute("SELECT COUNT(*) FROM incidents")
    stats["total"] = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM incidents WHERE created_at > ?", (day_ago,))
    stats["last_24h"] = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM incidents WHERE created_at > ?", (week_ago,))
    stats["last_7d"] = cursor.fetchone()[0]
    cursor.execute("SELECT severity, COUNT(*) as cnt FROM incidents GROUP BY severity")
    stats["by_severity"] = {r["severity"]: r["cnt"] for r in cursor.fetchall()}
    cursor.execute("SELECT status, COUNT(*) as cnt FROM incidents GROUP BY status")
    stats["by_status"] = {r["status"]: r["cnt"] for r in cursor.fetchall()}
    cursor.execute("SELECT mitre_technique, COUNT(*) as cnt FROM incidents WHERE mitre_technique != '' GROUP BY mitre_technique ORDER BY cnt DESC LIMIT 10")
    stats["top_techniques"] = [{"technique": r["mitre_technique"], "count": r["cnt"]} for r in cursor.fetchall()]
    cursor.execute("SELECT user_id, COUNT(*) as cnt FROM incidents GROUP BY user_id ORDER BY cnt DESC LIMIT 10")
    stats["top_users"] = [{"user": r["user_id"], "count": r["cnt"]} for r in cursor.fetchall()]

    conn.close()
    return stats


@router.get("/{incident_id}")
async def get_incident(incident_id: str, user: dict = Depends(authenticate_request)):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT i.*, e.hostname as endpoint_hostname FROM incidents i LEFT JOIN endpoints e ON i.endpoint_id = e.endpoint_id WHERE i.incident_id = ?", (incident_id,))
    row = cursor.fetchone()
    conn.close()
    if not row:
        raise HTTPException(status_code=404, detail="Incident not found")
    return dict(row)


@router.put("/{incident_id}/status")
async def update_incident_status(incident_id: str, payload: UpdateIncidentStatusRequest, user: dict = Depends(authenticate_request)):
    new_status = payload.status
    valid = ("OPEN", "UNDER_INVESTIGATION", "VERIFICATION_PENDING", "CONTAINED", "RESOLVED", "CLOSED")
    if new_status not in valid:
        raise HTTPException(status_code=400, detail=f"Invalid status: {new_status}")
    notes = payload.resolution_notes
    conn = get_connection()
    cursor = conn.cursor()
    if new_status in ("RESOLVED", "CLOSED"):
        cursor.execute("UPDATE incidents SET status = ?, resolved_at = ?, resolution_notes = ? WHERE incident_id = ?",
                       (new_status, int(time.time()), notes, incident_id))
    else:
        cursor.execute("UPDATE incidents SET status = ?, assigned_analyst = COALESCE(NULLIF(?, ''), assigned_analyst) WHERE incident_id = ?",
                       (new_status, payload.analyst or "", incident_id))
    conn.commit()
    conn.close()
    return {"status": "updated", "incident_id": incident_id, "new_status": new_status}


@router.get("/{incident_id}/containment")
async def list_containment_actions(incident_id: str, user: dict = Depends(authenticate_request)):
    from backend.db import get_containment_actions
    try:
        df = get_containment_actions(incident_id)
        actions = df.to_dict("records") if df is not None and not df.empty else []
    except Exception:
        actions = []
    return {"incident_id": incident_id, "containment_actions": actions}


@router.post("/{incident_id}/contain")
async def trigger_containment(incident_id: str, user: dict = Depends(authenticate_request)):
    from backend.db import get_incident_by_id, insert_containment_action
    from backend.containment_engine import execute_containment
    inc = get_incident_by_id(incident_id)
    if not inc:
        raise HTTPException(status_code=404, detail="Incident not found")
    result = await execute_containment(
        incident=dict(inc),
        risk_score=inc.get("risk_score", 0),
        evidence_score=inc.get("evidence_score", 0),
    )
    return {"incident_id": incident_id, "status": "containment_executed", "result": result}


@router.get("/{incident_id}/evidence")
async def get_evidence(incident_id: str, user: dict = Depends(authenticate_request)):
    from backend.db import get_evidence_package_by_incident
    pkg = get_evidence_package_by_incident(incident_id)
    if not pkg:
        return {"incident_id": incident_id, "package_available": False}
    return {"incident_id": incident_id, "package_available": True, **dict(pkg)}


@router.get("/{incident_id}/evidence/download")
async def download_evidence(incident_id: str, user: dict = Depends(authenticate_request)):
    from backend.db import get_evidence_package_by_incident
    import os
    from pathlib import Path
    pkg = get_evidence_package_by_incident(incident_id)
    if not pkg or not pkg.get("package_path"):
        raise HTTPException(status_code=404, detail="No evidence package available")
    path = pkg["package_path"]
    evidence_base = os.path.normpath(os.path.join(os.path.dirname(__file__), "..", "..", "evidence"))
    requested = os.path.normpath(os.path.abspath(path))
    if not requested.startswith(evidence_base):
        raise HTTPException(status_code=403, detail="Access denied")
    if not os.path.exists(requested):
        raise HTTPException(status_code=404, detail="Evidence file not found on disk")
    from fastapi.responses import FileResponse
    return FileResponse(requested, filename=f"{incident_id}.zip", media_type="application/zip")


def create_incident(endpoint_id: str, org_id: int, incident_data: dict) -> str:
    incident_id = f"CMS-{uuid.uuid4().hex[:8].upper()}-{int(time.time())}"
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO incidents
            (endpoint_id, incident_id, org_id, user_id, severity, status,
             risk_score, confidence, evidence_score, mitre_technique,
             mitre_technique_name, mitre_tactic, recommended_action,
             reason_json, response_level, system_state, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        endpoint_id, incident_id, org_id,
        incident_data.get("user_id", "default_user"),
        incident_data.get("severity", "MEDIUM"), "OPEN",
        incident_data.get("risk_score", 0),
        incident_data.get("confidence", 0),
        incident_data.get("evidence_score", 0),
        incident_data.get("mitre_technique", ""),
        incident_data.get("mitre_technique_name", ""),
        incident_data.get("mitre_tactic", ""),
        incident_data.get("recommended_action", ""),
        json.dumps(incident_data.get("recommendation", {})),
        incident_data.get("response_level", 0),
        incident_data.get("system_state", "NORMAL"),
        int(time.time()),
    ))
    conn.commit()
    conn.close()
    return incident_id
