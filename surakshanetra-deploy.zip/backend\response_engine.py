import json
import logging
import os
import time
import uuid
from typing import Any, Dict, List, Optional, Tuple

from backend.mitre_mapping import map_mitre_technique

logger = logging.getLogger(__name__)

POLICIES_PATH = os.path.join(os.path.dirname(__file__), "policies.json")

LEVEL_NAMES = {
    0: "TRUSTED",
    1: "LOW",
    2: "MEDIUM",
    3: "SUSPICIOUS",
    4: "HIGH",
    5: "CRITICAL"
}

SYSTEM_STATES = ["NORMAL", "OBSERVATION", "SUSPICIOUS", "VERIFIED_ATTACK"]

INCIDENT_STATUSES = [
    "OPEN",
    "UNDER_INVESTIGATION",
    "VERIFICATION_PENDING",
    "CONTAINED",
    "RESOLVED",
    "CLOSED"
]

EVIDENCE_WEIGHTS = {
    "typing_anomaly": 15,
    "mouse_anomaly": 10,
    "location_anomaly": 20,
    "device_mismatch": 20,
    "unknown_application": 10,
    "time_anomaly": 5,
    "frequency_anomaly": 8,
    "idle_anomaly": 3,
    "behavior_anomaly": 12,
    "unknown_device": 15,
    "device_fingerprint_changed": 20,
    "device_hardware_changed_high": 15,
    "device_hardware_changed_medium": 10,
    "device_hardware_changed_low": 5,
    "trusted_session": -15,
    "trusted_location": -15,
    "trusted_device": -10,
    "positive_feedback": -10,
    "recent_mfa": -20
}

CONFIDENCE_THRESHOLD_LOW = 0.35
CONFIDENCE_THRESHOLD_MEDIUM = 0.50
CONFIDENCE_THRESHOLD_HIGH = 0.70

DEFAULT_INCIDENT_TTL = 3600

INCIDENT_STORE: Dict[str, dict] = {}


def _load_policies() -> List[dict]:
    if not os.path.exists(POLICIES_PATH):
        logger.warning("Policies file not found at %s. Using built-in defaults.", POLICIES_PATH)
        return []
    try:
        with open(POLICIES_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data.get("policies", [])
    except (json.JSONDecodeError, IOError) as e:
        logger.error("Failed to load policies: %s", e)
        return []


def _get_active_policies() -> List[dict]:
    policies = _load_policies()
    return sorted(
        [p for p in policies if p.get("enabled", True)],
        key=lambda x: x.get("priority", 999)
    )


def calculate_evidence_score(
    deviating_features: List[str],
    is_new_location: bool,
    device_mismatch: bool,
    trusted_session: bool,
    trusted_location: bool,
    has_positive_feedback: bool,
    has_recent_mfa: bool,
    unknown_device: bool = False,
    device_fingerprint_changed: bool = False,
    device_hardware_change_score: float = 0.0,
    trusted_device: bool = False
) -> Tuple[float, Dict[str, Any]]:
    score = 0.0
    breakdown: Dict[str, Any] = {"additions": {}, "deductions": {}}

    feature_anomaly_map = {
        "typing_speed": "typing_anomaly",
        "key_latency": "typing_anomaly",
        "avg_hold_time": "typing_anomaly",
        "latency_jitter": "typing_anomaly",
        "mouse_speed": "mouse_anomaly",
        "mouse_acceleration": "mouse_anomaly",
        "direction_change_freq": "mouse_anomaly",
        "click_frequency": "frequency_anomaly",
        "active_app": "unknown_application",
        "app_switch_count": "behavior_anomaly",
        "idle_time": "idle_anomaly",
        "time_of_day": "time_anomaly"
    }

    seen_categories = set()
    for feature in deviating_features:
        category = feature_anomaly_map.get(feature)
        if category and category not in seen_categories:
            weight = EVIDENCE_WEIGHTS.get(category, 5)
            score += weight
            seen_categories.add(category)
            breakdown["additions"][category] = weight

    if is_new_location and "location_anomaly" not in seen_categories:
        score += EVIDENCE_WEIGHTS["location_anomaly"]
        breakdown["additions"]["location_anomaly"] = EVIDENCE_WEIGHTS["location_anomaly"]

    if device_mismatch:
        score += EVIDENCE_WEIGHTS["device_mismatch"]
        breakdown["additions"]["device_mismatch"] = EVIDENCE_WEIGHTS["device_mismatch"]

    if unknown_device:
        score += EVIDENCE_WEIGHTS["unknown_device"]
        breakdown["additions"]["unknown_device"] = EVIDENCE_WEIGHTS["unknown_device"]

    if device_fingerprint_changed:
        score += EVIDENCE_WEIGHTS["device_fingerprint_changed"]
        breakdown["additions"]["device_fingerprint_changed"] = EVIDENCE_WEIGHTS["device_fingerprint_changed"]

    if device_hardware_change_score >= 60:
        score += EVIDENCE_WEIGHTS["device_hardware_changed_high"]
        breakdown["additions"]["device_hardware_changed_high"] = EVIDENCE_WEIGHTS["device_hardware_changed_high"]
    elif device_hardware_change_score >= 30:
        score += EVIDENCE_WEIGHTS["device_hardware_changed_medium"]
        breakdown["additions"]["device_hardware_changed_medium"] = EVIDENCE_WEIGHTS["device_hardware_changed_medium"]
    elif device_hardware_change_score >= 10:
        score += EVIDENCE_WEIGHTS["device_hardware_changed_low"]
        breakdown["additions"]["device_hardware_changed_low"] = EVIDENCE_WEIGHTS["device_hardware_changed_low"]

    if trusted_session:
        score += EVIDENCE_WEIGHTS["trusted_session"]
        breakdown["deductions"]["trusted_session"] = EVIDENCE_WEIGHTS["trusted_session"]

    if trusted_location:
        score += EVIDENCE_WEIGHTS["trusted_location"]
        breakdown["deductions"]["trusted_location"] = EVIDENCE_WEIGHTS["trusted_location"]

    if trusted_device:
        score += EVIDENCE_WEIGHTS["trusted_device"]
        breakdown["deductions"]["trusted_device"] = EVIDENCE_WEIGHTS["trusted_device"]

    if has_positive_feedback:
        score += EVIDENCE_WEIGHTS["positive_feedback"]
        breakdown["deductions"]["positive_feedback"] = EVIDENCE_WEIGHTS["positive_feedback"]

    if has_recent_mfa:
        score += EVIDENCE_WEIGHTS["recent_mfa"]
        breakdown["deductions"]["recent_mfa"] = EVIDENCE_WEIGHTS["recent_mfa"]

    final_score = max(0.0, min(100.0, score))
    return round(final_score, 2), breakdown


def _determine_risk_level(risk_score: float, evidence_score: float) -> Tuple[str, int]:
    hybrid = (risk_score * 0.6) + (evidence_score * 0.4)

    if hybrid >= 90:
        return "CRITICAL", 5
    elif hybrid >= 75:
        return "HIGH", 4
    elif hybrid >= 55:
        return "SUSPICIOUS", 3
    elif hybrid >= 35:
        return "MEDIUM", 2
    elif hybrid >= 15:
        return "LOW", 1
    else:
        return "TRUSTED", 0


def _get_system_state(current_state: str, response_level: int) -> str:
    if response_level >= 5:
        return "VERIFIED_ATTACK"
    elif response_level >= 3:
        return "SUSPICIOUS"
    elif response_level >= 2:
        return "OBSERVATION"
    else:
        return "NORMAL"


def _confidence_filter(risk_level: str, confidence: float) -> Optional[str]:
    if confidence < CONFIDENCE_THRESHOLD_LOW:
        if risk_level in ("HIGH", "CRITICAL"):
            return "MEDIUM"
        if risk_level == "SUSPICIOUS":
            return "LOW"
    elif confidence < CONFIDENCE_THRESHOLD_MEDIUM:
        if risk_level == "CRITICAL":
            return "HIGH"
        if risk_level == "HIGH":
            return "SUSPICIOUS"
    elif confidence < CONFIDENCE_THRESHOLD_HIGH:
        if risk_level == "CRITICAL":
            return "HIGH"
    return risk_level


def _match_policy(
    policies: List[dict],
    risk_level: str,
    risk_score: float,
    consecutive_anomalies: int,
    confidence: float,
    trusted_session: bool,
    trusted_location: bool,
    is_new_location: bool,
    has_failed_mfa: bool
) -> Optional[dict]:
    for policy in policies:
        cond = policy.get("conditions", {})
        prl = cond.get("risk_level", "")
        if prl and prl != risk_level:
            continue
        if risk_score < cond.get("min_risk_score", 0):
            continue
        if consecutive_anomalies < cond.get("min_consecutive_anomalies", 0):
            continue
        if confidence < cond.get("min_confidence", 0.0):
            continue

        if cond.get("require_failed_mfa", False) and not has_failed_mfa:
            continue
        if cond.get("require_location_anomaly", False) and not is_new_location:
            continue
        if cond.get("require_trusted_session", False) and not trusted_session:
            continue

        exceptions = policy.get("exceptions", [])
        for exc in exceptions:
            if "trusted_session" in exc.get("condition", ""):
                if trusted_session and trusted_location:
                    return {
                        "policy_id": policy["id"],
                        "policy_name": policy["name"],
                        "action": exc.get("override_action", policy["actions"]["action"]),
                        "response_level": exc.get("override_level_num", _level_name_to_num(exc.get("override_level", risk_level))),
                        "system_state": exc.get("override_level", risk_level),
                        "create_incident": policy["actions"].get("create_incident", False),
                        "incident_severity": policy["actions"].get("incident_severity", "MEDIUM"),
                        "notify_admin": policy["actions"].get("notify_admin", False),
                        "store_forensics": policy["actions"].get("store_forensics", False),
                        "restrictions": policy["actions"].get("restrictions", [])
                    }

        return {
            "policy_id": policy["id"],
            "policy_name": policy["name"],
            "action": policy["actions"].get("action", "OBSERVE"),
            "response_level": _level_name_to_num(policy["actions"].get("response_level", risk_level)),
            "system_state": policy["actions"].get("system_state", "NORMAL"),
            "create_incident": policy["actions"].get("create_incident", False),
            "incident_severity": policy["actions"].get("incident_severity", "MEDIUM"),
            "notify_admin": policy["actions"].get("notify_admin", False),
            "store_forensics": policy["actions"].get("store_forensics", False),
            "restrictions": policy["actions"].get("restrictions", [])
        }

    return None


def _level_name_to_num(name: str) -> int:
    for k, v in LEVEL_NAMES.items():
        if v == name:
            return k
    return 1


def _build_recommendation(
    action: str,
    risk_level: str,
    evidence_breakdown: Dict[str, Any],
    deviating_features: List[str],
    is_new_location: bool,
    device_mismatch: bool,
    mitre: dict,
    unknown_device: bool = False,
    device_fingerprint_changed: bool = False,
    trusted_device: bool = False
) -> Dict[str, Any]:
    reasons = []

    for category, weight in evidence_breakdown.get("additions", {}).items():
        reasons.append(f"{category.replace('_', ' ').title()}: +{weight}")

    for feature in deviating_features[:3]:
        reasons.append(f"Anomalous signal: {feature}")

    if is_new_location:
        reasons.append("Activity from unknown geographic location")

    if device_mismatch:
        reasons.append("Device fingerprint mismatch detected")

    if evidence_breakdown.get("additions", {}).get("unknown_device"):
        reasons.append("Unrecognized device - not in trusted device registry")

    if evidence_breakdown.get("additions", {}).get("device_fingerprint_changed"):
        reasons.append("Critical hardware identifiers changed since last session")

    if evidence_breakdown.get("additions", {}).get("device_hardware_changed_high"):
        reasons.append("High-severity hardware change detected (motherboard/BIOS)")

    if evidence_breakdown.get("deductions", {}).get("trusted_device"):
        reasons.append("Known trusted device - risk reduced")

    attack_type = mitre.get("technique_name", "Unknown")
    confidence_text = "High" if risk_level in ("HIGH", "CRITICAL") else "Medium" if risk_level == "SUSPICIOUS" else "Low"

    return {
        "possible_attack": attack_type,
        "confidence_level": confidence_text,
        "evidence_count": len(evidence_breakdown.get("additions", {})),
        "reasons": reasons,
        "recommended_action": action.replace("_", " ").title()
    }


def evaluate(
    risk_score: float,
    confidence: float,
    deviating_features: List[str],
    significance: Dict[str, int],
    is_new_location: bool,
    is_trusted_location: bool,
    is_trusted_session: bool,
    consecutive_anomalies: int,
    has_positive_feedback: bool,
    has_recent_mfa: bool,
    has_failed_mfa: bool,
    device_mismatch: bool = False,
    unknown_device: bool = False,
    device_fingerprint_changed: bool = False,
    device_hardware_change_score: float = 0.0,
    trusted_device: bool = False,
    current_system_state: str = "NORMAL",
    user_id: str = "default_user",
    session_id: Optional[str] = None
) -> Dict[str, Any]:
    logger.info(
        "Evaluating response for user=%s risk=%.2f confidence=%.2f anomalies=%d",
        user_id, risk_score, confidence, consecutive_anomalies
    )

    evidence_score, evidence_breakdown = calculate_evidence_score(
        deviating_features=deviating_features,
        is_new_location=is_new_location,
        device_mismatch=device_mismatch,
        unknown_device=unknown_device,
        device_fingerprint_changed=device_fingerprint_changed,
        device_hardware_change_score=device_hardware_change_score,
        trusted_device=trusted_device,
        trusted_session=is_trusted_session,
        trusted_location=is_trusted_location,
        has_positive_feedback=has_positive_feedback,
        has_recent_mfa=has_recent_mfa
    )

    raw_level, raw_level_num = _determine_risk_level(risk_score, evidence_score)

    filtered_level = _confidence_filter(raw_level, confidence)
    filtered_level_num = _level_name_to_num(filtered_level) if isinstance(filtered_level, str) else filtered_level

    policies = _get_active_policies()
    policy_match = _match_policy(
        policies=policies,
        risk_level=filtered_level,
        risk_score=risk_score,
        consecutive_anomalies=consecutive_anomalies,
        confidence=confidence,
        trusted_session=is_trusted_session,
        trusted_location=is_trusted_location,
        is_new_location=is_new_location,
        has_failed_mfa=has_failed_mfa
    )

    if policy_match:
        action = policy_match["action"]
        response_level = policy_match["response_level"]
        system_state = policy_match["system_state"]
    else:
        action = "OBSERVE" if filtered_level_num >= 2 else "LEARN"
        response_level = filtered_level_num
        system_state = _get_system_state(current_system_state, response_level)

    if consecutive_anomalies == 0 and response_level >= 3:
        response_level = min(response_level, 2)
        system_state = "OBSERVATION"
        action = "OBSERVE"

    mitre = map_mitre_technique(
        risk_level=filtered_level,
        deviating_features=deviating_features,
        is_new_location=is_new_location,
        device_mismatch=device_mismatch,
        unknown_device=unknown_device,
        device_fingerprint_changed=device_fingerprint_changed
    )

    recommendation = _build_recommendation(
        action=action,
        risk_level=filtered_level,
        evidence_breakdown=evidence_breakdown,
        deviating_features=deviating_features,
        is_new_location=is_new_location,
        device_mismatch=device_mismatch,
        mitre=mitre,
        unknown_device=unknown_device,
        device_fingerprint_changed=device_fingerprint_changed,
        trusted_device=trusted_device
    )

    result = {
        "risk_level": filtered_level,
        "risk_level_num": response_level,
        "risk_score": round(risk_score, 2),
        "confidence": round(confidence, 4),
        "evidence_score": evidence_score,
        "evidence_breakdown": evidence_breakdown,
        "system_state": system_state,
        "action": action,
        "response_level": response_level,
        "consecutive_anomalies": consecutive_anomalies,
        "mitre_technique": mitre,
        "recommendation": recommendation,
        "trusted_session": is_trusted_session,
        "trusted_location": is_trusted_location,
        "new_location": is_new_location,
        "device_mismatch": device_mismatch,
        "unknown_device": unknown_device,
        "device_fingerprint_changed": device_fingerprint_changed,
        "device_hardware_change_score": device_hardware_change_score,
        "trusted_device": trusted_device,
        "policy_matched": policy_match["policy_id"] if policy_match else None,
        "timestamp": int(time.time())
    }

    return result


def create_incident(
    user_id: str,
    session_id: Optional[str],
    evaluation: Dict[str, Any]
) -> str:
    incident_id = f"INC-{uuid.uuid4().hex[:8].upper()}-{int(time.time())}"
    incident = {
        "incident_id": incident_id,
        "user_id": user_id,
        "session_id": session_id or f"SESS-{uuid.uuid4().hex[:8].upper()}",
        "timestamp": int(time.time()),
        "risk_score": evaluation.get("risk_score", 0),
        "confidence": evaluation.get("confidence", 0),
        "evidence_score": evaluation.get("evidence_score", 0),
        "severity": evaluation.get("risk_level", "MEDIUM"),
        "status": "OPEN",
        "mitre_technique": evaluation.get("mitre_technique", {}).get("technique_id", ""),
        "mitre_technique_name": evaluation.get("mitre_technique", {}).get("technique_name", ""),
        "mitre_tactic": evaluation.get("mitre_technique", {}).get("tactic", ""),
        "recommended_action": evaluation.get("action", ""),
        "reason_json": json.dumps(evaluation.get("recommendation", {})),
        "response_level": evaluation.get("response_level", 0),
        "system_state": evaluation.get("system_state", "NORMAL"),
        "resolved_at": None,
        "resolution_notes": None
    }
    INCIDENT_STORE[incident_id] = incident
    logger.info("Incident created: %s | severity=%s | user=%s", incident_id, incident["severity"], user_id)
    return incident_id


def update_incident_status(
    incident_id: str,
    new_status: str,
    resolution_notes: Optional[str] = None
) -> bool:
    if incident_id not in INCIDENT_STORE:
        logger.warning("Incident %s not found.", incident_id)
        return False
    if new_status not in INCIDENT_STATUSES:
        logger.warning("Invalid status %s. Must be one of %s", new_status, INCIDENT_STATUSES)
        return False

    INCIDENT_STORE[incident_id]["status"] = new_status
    if new_status in ("RESOLVED", "CLOSED"):
        INCIDENT_STORE[incident_id]["resolved_at"] = int(time.time())
        INCIDENT_STORE[incident_id]["resolution_notes"] = resolution_notes

    logger.info("Incident %s status updated to %s", incident_id, new_status)
    return True


def get_incident(incident_id: str) -> Optional[dict]:
    return INCIDENT_STORE.get(incident_id)


def get_all_incidents(user_id: Optional[str] = None, status: Optional[str] = None, limit: int = 50) -> List[dict]:
    incidents = list(INCIDENT_STORE.values())
    if user_id:
        incidents = [i for i in incidents if i["user_id"] == user_id]
    if status:
        incidents = [i for i in incidents if i["status"] == status]
    incidents.sort(key=lambda x: x.get("timestamp", 0), reverse=True)
    return incidents[:limit]


def auto_recover(
    evaluation: Dict[str, Any],
    mfa_success: bool = False,
    behavior_normalized: bool = False
) -> Dict[str, Any]:
    result = dict(evaluation)

    if mfa_success:
        result["risk_level"] = "MEDIUM"
        result["risk_level_num"] = 2
        result["response_level"] = 2
        result["system_state"] = "OBSERVATION"
        result["action"] = "OBSERVE"
        result["evidence_score"] = max(0, result.get("evidence_score", 0) - 30)
        result["recommendation"]["reasons"].insert(0, "MFA completed successfully — risk reduced")
        result["recommendation"]["recommended_action"] = "Continue Monitoring"
        logger.info("Auto-recovery triggered via MFA success.")
        return result

    if behavior_normalized:
        result["risk_level"] = "LOW"
        result["risk_level_num"] = 1
        result["response_level"] = 1
        result["system_state"] = "NORMAL"
        result["action"] = "MONITOR"
        result["evidence_score"] = max(0, result.get("evidence_score", 0) - 15)
        result["recommendation"]["reasons"].insert(0, "Behavior normalized — exiting observation")
        result["recommendation"]["recommended_action"] = "Normal Monitoring"
        logger.info("Auto-recovery triggered via behavior normalization.")
        return result

    return result


def resolve_incident_on_recovery(
    incident_id: Optional[str],
    evaluation: Dict[str, Any],
    mfa_success: bool = False,
    behavior_normalized: bool = False
) -> Dict[str, Any]:
    recovered = auto_recover(evaluation, mfa_success=mfa_success, behavior_normalized=behavior_normalized)

    if incident_id and recovered["response_level"] <= 2:
        update_incident_status(
            incident_id,
            "RESOLVED",
            resolution_notes="Auto-resolved: " + (
                "MFA completed successfully" if mfa_success else "Behavior normalized"
            )
        )
        recovered["incident_resolved"] = incident_id

    return recovered
