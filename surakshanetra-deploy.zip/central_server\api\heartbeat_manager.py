"""
Heartbeat Manager — ingest and track endpoint health status
"""
import time
from fastapi import APIRouter, Depends
from ..database import get_connection
from ..auth import authenticate_request
from ..config import HEARTBEAT_TIMEOUT_SECONDS, OFFLINE_THRESHOLD_SECONDS

router = APIRouter(prefix="/api/v1/agent", tags=["Heartbeat Manager"])


@router.post("/heartbeat")
async def ingest_heartbeat(payload: dict, user: dict = Depends(authenticate_request)):
    endpoint_id = payload.get("device_id")
    if not endpoint_id:
        return {"status": "error", "detail": "device_id required"}

    conn = get_connection()
    cursor = conn.cursor()
    now = int(time.time())

    health_status = payload.get("status", "ONLINE")
    risk_level = payload.get("risk_level", "LOW")

    cursor.execute("""
        INSERT INTO heartbeats
            (endpoint_id, cpu_percent, memory_mb, current_user, risk_level,
             agent_version, health_status, session_state, incident_count,
             policy_version, timestamp)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        endpoint_id,
        payload.get("cpu_usage_percent", 0),
        payload.get("memory_usage_mb", 0),
        payload.get("current_user", ""),
        risk_level,
        payload.get("agent_version", ""),
        health_status,
        payload.get("session_state", "NORMAL"),
        payload.get("incident_count", 0),
        payload.get("policy_version", "0"),
        now,
    ))

    cursor.execute("""
        UPDATE endpoints SET
            last_seen = ?, health_status = ?, risk_level = ?,
            hostname = COALESCE(NULLIF(?, ''), hostname),
            agent_version = COALESCE(NULLIF(?, ''), agent_version),
            ip_address = COALESCE(NULLIF(?, ''), ip_address),
            session_state = COALESCE(NULLIF(?, ''), session_state)
        WHERE endpoint_id = ?
    """, (
        now, health_status, risk_level,
        payload.get("hostname", ""),
        payload.get("agent_version", ""),
        payload.get("ip_address", ""),
        payload.get("session_state", ""),
        endpoint_id,
    ))

    if cursor.rowcount == 0:
        cursor.execute("""
            INSERT OR IGNORE INTO endpoints
                (endpoint_id, device_id, hostname, agent_version, os,
                 first_seen, last_seen, health_status, risk_level)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            endpoint_id,
            payload.get("device_id", endpoint_id),
            payload.get("hostname", ""),
            payload.get("agent_version", ""),
            payload.get("os", "Windows"),
            now, now, health_status, risk_level,
        ))

    conn.commit()
    conn.close()
    return {"status": "ok", "endpoint_id": endpoint_id, "server_time": now}


@router.get("/heartbeat/status")
async def get_all_heartbeat_status(user: dict = Depends(authenticate_request)):
    conn = get_connection()
    cursor = conn.cursor()
    now = int(time.time())

    cursor.execute("SELECT endpoint_id, health_status, last_seen FROM endpoints")
    rows = cursor.fetchall()
    conn.close()

    statuses = []
    for row in rows:
        ep = dict(row)
        elapsed = now - (ep.get("last_seen") or 0)
        if ep["health_status"] == "ONLINE" and elapsed > OFFLINE_THRESHOLD_SECONDS:
            ep["effective_status"] = "OFFLINE"
        elif ep["health_status"] == "ONLINE" and elapsed > HEARTBEAT_TIMEOUT_SECONDS:
            ep["effective_status"] = "DEGRADED"
        else:
            ep["effective_status"] = ep["health_status"]
        ep["last_seen_ago"] = elapsed
        statuses.append(ep)

    return {"endpoints": statuses}
