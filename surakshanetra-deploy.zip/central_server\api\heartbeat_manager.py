"""
Heartbeat Manager — ingest and track endpoint health status
"""
import time
from fastapi import APIRouter, Depends
from ..database import get_connection
from ..auth import authenticate_request
from ..config import HEARTBEAT_TIMEOUT_SECONDS, OFFLINE_THRESHOLD_SECONDS
from ..models import HeartbeatRequest

router = APIRouter(prefix="/api/v1/agent", tags=["Heartbeat Manager"])


@router.post("/heartbeat")
async def ingest_heartbeat(payload: HeartbeatRequest, user: dict = Depends(authenticate_request)):
    endpoint_id = payload.device_id
    if not endpoint_id:
        return {"status": "error", "detail": "device_id required"}

    conn = get_connection()
    cursor = conn.cursor()
    now = int(time.time())

    health_status = payload.health_status
    risk_level = payload.risk_level

    cursor.execute("""
        INSERT INTO heartbeats
            (endpoint_id, cpu_percent, memory_mb, current_user, risk_level,
             agent_version, health_status, session_state, incident_count,
             policy_version, timestamp)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        endpoint_id,
        payload.cpu_percent,
        payload.memory_mb,
        payload.current_user,
        risk_level,
        payload.agent_version,
        health_status,
        payload.session_state,
        payload.incident_count,
        payload.policy_version,
        now,
    ))

    cursor.execute("""
        UPDATE endpoints SET
            last_seen = ?, health_status = ?, risk_level = ?,
            hostname = COALESCE(NULLIF(?, ''), hostname),
            agent_version = COALESCE(NULLIF(?, ''), agent_version),
            ip_address = COALESCE(NULLIF(?, ''), ip_address),
            session_state = COALESCE(NULLIF(?, ''), session_state)
        WHERE endpoint_id = ?
    """, (
        now, health_status, risk_level,
        payload.hostname or "",
        payload.agent_version,
        payload.ip_address or "",
        payload.session_state,
        endpoint_id,
    ))

    if cursor.rowcount == 0:
        cursor.execute("""
            INSERT OR IGNORE INTO endpoints
                (endpoint_id, device_id, hostname, agent_version, os,
                 first_seen, last_seen, health_status, risk_level)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            endpoint_id,
            payload.device_id or endpoint_id,
            payload.hostname or "",
            payload.agent_version,
            payload.os or "Windows",
            now, now, health_status, risk_level,
        ))

    conn.commit()
    conn.close()
    return {"status": "ok", "endpoint_id": endpoint_id, "server_time": now}


@router.get("/heartbeat/status")
async def get_all_heartbeat_status(user: dict = Depends(authenticate_request)):
    conn = get_connection()
    cursor = conn.cursor()
    now = int(time.time())

    cursor.execute("SELECT endpoint_id, health_status, last_seen FROM endpoints")
    rows = cursor.fetchall()
    conn.close()

    statuses = []
    for row in rows:
        ep = dict(row)
        elapsed = now - (ep.get("last_seen") or 0)
        if ep["health_status"] == "ONLINE" and elapsed > OFFLINE_THRESHOLD_SECONDS:
            ep["effective_status"] = "OFFLINE"
        elif ep["health_status"] == "ONLINE" and elapsed > HEARTBEAT_TIMEOUT_SECONDS:
            ep["effective_status"] = "DEGRADED"
        else:
            ep["effective_status"] = ep["health_status"]
        ep["last_seen_ago"] = elapsed
        statuses.append(ep)

    return {"endpoints": statuses}
