import json
import os
import sys

sys.path.append(os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.append(os.path.join(os.path.dirname(__file__), ".."))

from fastapi import APIRouter, HTTPException

from backend.db import upsert_agent_heartbeat, get_agent_heartbeat

router = APIRouter()


@router.post("/api/v1/agent/heartbeat")
def agent_heartbeat(payload: dict):
    upsert_agent_heartbeat(payload)
    return {"status": "ok", "device_id": payload.get("device_id", "")}


@router.get("/api/v1/agent/status/{device_id}")
def agent_status(device_id: str):
    hb = get_agent_heartbeat(device_id)
    if hb is None:
        raise HTTPException(status_code=404, detail="Agent not found")
    return {"status": "ok", "heartbeat": hb}
