# 🔐 AI-Based Continuous Authentication System (Mini UEBA Platform)

## 📌 Project Overview

This project builds a **Continuous Authentication System** that verifies a user not just at login, but continuously based on behavior.

Instead of:

```
Login → Trusted forever ❌
```

We implement:

```
Login → Continuous Behavior Monitoring → Risk Detection ✅
```

If behavior changes → system detects possible attacker → alert or logout.

---

## 🎯 Objective

* Detect **session hijacking**
* Identify **insider threats**
* Build **AI-driven behavior analysis system**
* Simulate real-world **SOC / UEBA systems**

---

## 🧠 Core Concept

We create a **behavior fingerprint** using:

* Typing patterns
* Mouse movement
* System activity

Then use AI to detect anomalies.

---

## 🏗️ Project Architecture

```
User Device
   ↓
[Agent - Behavior Collector]
   ↓
[Backend API]
   ↓
[ML Model - Anomaly Detection]
   ↓
[Decision Engine]
   ↓
[Dashboard + Alerts]
```

---

## 📁 Folder Structure

```
ai-continuous-authentication/
│
├── agent/              # Behavior collection
├── backend/            # DB, Response Engine, MITRE Mapping, Policies
├── ml_service/         # ML models + FastAPI endpoints
├── data/               # SQLite database + CSV storage
├── dashboard/          # Streamlit UI (10 pages)
├── docs/               # Documentation (API, Setup, Architecture)
│
├── requirements.txt
├── README.md
├── PROJECT_SUMMARY.md
├── test_integration.py
└── test_response_engine.py
```

---

## 👨‍💻 Role Distribution

### 🔐 Rushikesh (Cybersecurity)

Responsible for:

* Agent development (data collection)
* Backend API
* Rule-based detection
* Risk scoring
* Decision engine
* System integration

---

### 🤖 Gayatri (AI/ML)

Responsible for:

* Data preprocessing
* Feature engineering
* Model training
* Anomaly detection
* Model optimization

---

## 🔄 System Workflow

```
1. User performs activity
2. Agent collects behavior data
3. Data sent to backend
4. Backend sends to ML model
5. ML model returns anomaly score
6. Backend calculates risk
7. Decision taken (allow / alert / logout)
8. Dashboard displays result
```

---

## 📊 Data Collection (Agent)

### We Collect:

#### ⌨️ Keyboard

* Typing speed
* Key hold time
* Key latency

#### 🖱️ Mouse

* Movement speed
* Click frequency

#### 🖥️ System

* Active applications
* Login time
* Idle time

---

## ⚠️ Privacy Rule

❌ Do NOT store actual keystrokes
✅ Only store behavior (timing, patterns)

---

## 🧩 Data Format (Example)

```json
{
  "typing_speed": 62,
  "key_latency": 0.11,
  "mouse_speed": 400,
  "active_app": "chrome",
  "time": 14
}
```

---

## 🤖 ML Model Design (Gayatri)

### Model Type

* Isolation Forest (primary)
* One-Class SVM (optional)

---

### Training Logic

```
Train ONLY on normal behavior
↓
Model learns baseline
↓
New data → compare → anomaly detection
```

---

### Output Example

```json
{
  "anomaly_score": 0.82
}
```

---

## 🧠 Risk Decision Logic (Rushikesh)

```
Low Score → Normal
Medium Score → Warning
High Score → Alert / Logout
```

---

## 🔥 Unique Features

* Continuous authentication (not one-time login)
* Behavioral biometrics
* AI + rule-based hybrid detection
* Explainable alerts
* Session hijack detection

---

## ⚙️ Tech Stack

### Backend

* Python (Flask / FastAPI)

### Agent

* pynput
* psutil
* mouse

### ML

* scikit-learn
* pandas
* numpy

### Dashboard

* Streamlit / React

### Database

* MongoDB / SQLite

---

## 🛠️ Git Workflow

### Branch Strategy

```
main → stable code

feature/agent → Rushikesh
feature/backend → Rushikesh
feature/ml-model → Gayatri
```

---

### Workflow

```
Create branch
↓
Write code
↓
git add
git commit
git push
↓
Create Pull Request
↓
Merge into main
```

---

## ⚠️ Important Git Rules

* Never work directly on `main`
* Always pull before starting
* Commit only relevant files
* Avoid committing AI unwanted changes

---

## 🧪 Testing Strategy

### Test Cases

1. Normal user → LOW risk
2. Slight behavior change → MEDIUM risk
3. Attacker simulation → HIGH risk

---

## 🚀 Development Plan

### Phase 1 (Week 1–2)

* Agent basic data collection
* Dummy dataset creation

---

### Phase 2 (Week 3–4)

* Backend API
* ML model basic training

---

### Phase 3 (Week 5–6)

* Integration (Agent + ML)
* Risk engine

---

### Phase 4 (Week 7–8)

* Dashboard
* Testing & optimization

---

## 🧠 Current Tasks (START HERE)

### 🔐 Rushikesh

* [ ] Build keyboard data collector
* [ ] Capture mouse movement
* [ ] Extract system activity
* [ ] Create backend API

---

### 🤖 Gayatri

* [ ] Create dataset format
* [ ] Implement preprocessing
* [ ] Train Isolation Forest model
* [ ] Test anomaly detection

---

## 🔜 Next Steps

After initial setup:

1. Integrate Agent → Backend
2. Connect Backend → ML
3. Implement risk scoring
4. Build dashboard

---

## 🧠 Final Vision

This project simulates:

```
UEBA (User & Entity Behavior Analytics)
+
SOC Detection System
```

Used in real tools like enterprise security platforms.

---

## 🔥 Golden Rule

```
Working system > Perfect system
```

---

## 📌 Contributors

* Rushikesh (Cybersecurity)
* Gayatri (AI/ML)

---
