"""
Notification Service — generate and serve alerts for endpoint events
"""
import json
import time
from fastapi import APIRouter, Depends, Query
from ..database import get_connection
from ..auth import authenticate_request

router = APIRouter(prefix="/api/v1/notifications", tags=["Notification Service"])


NOTIFICATION_TYPES = {
    "NEW_ENDPOINT": "New endpoint registered",
    "ENDPOINT_OFFLINE": "Endpoint went offline",
    "CRITICAL_INCIDENT": "Critical incident detected",
    "POLICY_UPDATE": "Policy updated",
    "AGENT_MISMATCH": "Agent version mismatch detected",
    "ENDPOINT_DEGRADED": "Endpoint in degraded state",
    "HEALTH_RECOVERED": "Endpoint health recovered",
    "HEALTH_DEGRADED": "Endpoint health score degraded",
    "AGENT_OUTDATED": "Agent version is outdated",
    "UPDATE_FAILED": "Agent update failed",
    "CONFIG_DRIFT": "Configuration drift detected",
    "NEW_REGISTRATION": "New endpoint registration pending approval",
    "HIGH_INCIDENT_VOLUME": "High incident volume detected",
    "COMMAND_ISSUED": "Remote command was issued",
    "LIFECYCLE_CHANGE": "Endpoint lifecycle state changed",
    "INVENTORY_CHANGE": "Endpoint inventory changed",
}

NOTIFICATION_CATEGORIES = {
    "offline": {"ENDPOINT_OFFLINE", "ENDPOINT_DEGRADED"},
    "health": {"HEALTH_DEGRADED", "HEALTH_RECOVERED"},
    "updates": {"AGENT_OUTDATED", "UPDATE_FAILED", "AGENT_MISMATCH"},
    "incidents": {"CRITICAL_INCIDENT", "HIGH_INCIDENT_VOLUME"},
    "lifecycle": {"NEW_ENDPOINT", "NEW_REGISTRATION", "LIFECYCLE_CHANGE"},
    "config": {"POLICY_UPDATE", "CONFIG_DRIFT"},
    "commands": {"COMMAND_ISSUED"},
    "inventory": {"INVENTORY_CHANGE"},
}


def create_notification(endpoint_id: str, org_id: int, ntype: str, severity: str = "INFO", message: str = None):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO notifications (endpoint_id, org_id, type, severity, message, created_at)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (endpoint_id, org_id, ntype, severity, message or NOTIFICATION_TYPES.get(ntype, ntype), int(time.time())))
    conn.commit()
    conn.close()


@router.get("")
async def list_notifications(
    read: bool = None,
    severity: str = None,
    limit: int = Query(50, ge=1, le=200),
    user: dict = Depends(authenticate_request),
):
    conn = get_connection()
    cursor = conn.cursor()
    conditions = []
    params = []
    if user.get("org_id"):
        conditions.append("n.org_id = ?")
        params.append(user["org_id"])
    if read is not None:
        conditions.append("n.read = ?")
        params.append(1 if read else 0)
    if severity:
        conditions.append("n.severity = ?")
        params.append(severity.upper())
    where = "WHERE " + " AND ".join(conditions) if conditions else ""
    cursor.execute(f"SELECT n.*, e.hostname as endpoint_hostname FROM notifications n LEFT JOIN endpoints e ON n.endpoint_id = e.endpoint_id {where} ORDER BY n.created_at DESC LIMIT ?", (*params, limit))
    rows = cursor.fetchall()
    conn.close()
    return {"notifications": [dict(r) for r in rows]}


@router.post("/{notification_id}/read")
async def mark_read(notification_id: int, user: dict = Depends(authenticate_request)):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE notifications SET read = 1 WHERE id = ?", (notification_id,))
    conn.commit()
    conn.close()
    return {"status": "read", "notification_id": notification_id}


@router.post("/read-all")
async def mark_all_read(user: dict = Depends(authenticate_request)):
    conn = get_connection()
    cursor = conn.cursor()
    if user.get("org_id"):
        cursor.execute("UPDATE notifications SET read = 1 WHERE org_id = ?", (user["org_id"],))
    else:
        cursor.execute("UPDATE notifications SET read = 1")
    conn.commit()
    count = cursor.rowcount
    conn.close()
    return {"status": "all_read", "count": count}


@router.get("/unread-count")
async def unread_count(user: dict = Depends(authenticate_request)):
    conn = get_connection()
    cursor = conn.cursor()
    if user.get("org_id"):
        cursor.execute("SELECT COUNT(*) FROM notifications WHERE org_id = ? AND read = 0", (user["org_id"],))
    else:
        cursor.execute("SELECT COUNT(*) FROM notifications WHERE read = 0")
    count = cursor.fetchone()[0]
    conn.close()
    return {"unread_count": count}


def check_and_alert_offline_endpoints():
    conn = get_connection()
    cursor = conn.cursor()
    from central_server.config import OFFLINE_THRESHOLD_SECONDS
    threshold = int(time.time()) - OFFLINE_THRESHOLD_SECONDS
    cursor.execute("""
        SELECT endpoint_id, org_id, hostname FROM endpoints
        WHERE health_status = 'ONLINE' AND last_seen < ?
    """, (threshold,))
    offline = cursor.fetchall()
    for ep in offline:
        create_notification(ep["endpoint_id"], ep["org_id"], "ENDPOINT_OFFLINE", "WARNING",
                            f"Endpoint {ep['hostname'] or ep['endpoint_id']} went offline")
        cursor.execute("UPDATE endpoints SET health_status = 'OFFLINE' WHERE endpoint_id = ?", (ep["endpoint_id"],))
    conn.commit()
    conn.close()
    return len(offline)
