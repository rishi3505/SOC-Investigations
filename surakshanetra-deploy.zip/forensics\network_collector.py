import time
import subprocess
import re

try:
    import psutil
except ImportError:
    psutil = None


def collect_network_connections() -> list:
    connections = []
    if psutil is None:
        return connections
    try:
        for conn in psutil.net_connections(kind="all"):
            try:
                entry = {
                    "fd": conn.fd,
                    "family": str(conn.family),
                    "type": str(conn.type),
                    "local_ip": conn.laddr.ip if conn.laddr else "",
                    "local_port": conn.laddr.port if conn.laddr else 0,
                    "remote_ip": conn.raddr.ip if conn.raddr else "",
                    "remote_port": conn.raddr.port if conn.raddr else 0,
                    "status": conn.status,
                    "pid": conn.pid,
                }
                connections.append(entry)
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass
    except (psutil.AccessDenied, PermissionError):
        pass
    return connections


def collect_listening_ports() -> list:
    ports = []
    if psutil is None:
        return ports
    try:
        for conn in psutil.net_connections(kind="inet"):
            if conn.status == "LISTEN":
                try:
                    ports.append({
                        "port": conn.laddr.port if conn.laddr else 0,
                        "ip": conn.laddr.ip if conn.laddr else "",
                        "pid": conn.pid,
                        "family": str(conn.family),
                        "type": str(conn.type),
                    })
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass
    except (psutil.AccessDenied, PermissionError):
        pass
    ports.sort(key=lambda p: p["port"])
    return ports


def collect_established_connections() -> list:
    conns = []
    if psutil is None:
        return conns
    try:
        for conn in psutil.net_connections(kind="inet"):
            if conn.status == "ESTABLISHED":
                try:
                    conns.append({
                        "local_ip": conn.laddr.ip if conn.laddr else "",
                        "local_port": conn.laddr.port if conn.laddr else 0,
                        "remote_ip": conn.raddr.ip if conn.raddr else "",
                        "remote_port": conn.raddr.port if conn.raddr else 0,
                        "pid": conn.pid,
                        "family": str(conn.family),
                    })
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass
    except (psutil.AccessDenied, PermissionError):
        pass
    return conns


def collect_dns_cache() -> list:
    entries = []
    try:
        result = subprocess.run(["ipconfig", "/displaydns"], capture_output=True, text=True, timeout=10)
        if result.returncode == 0:
            lines = result.stdout.splitlines()
            current = {}
            for line in lines:
                stripped = line.strip()
                if stripped.startswith("Record Name"):
                    if current:
                        entries.append(current)
                    current = {"record_name": stripped.split(":")[-1].strip()}
                elif stripped.startswith("Record Type"):
                    current["record_type"] = stripped.split(":")[-1].strip()
                elif stripped.startswith("Time To Live"):
                    current["ttl"] = stripped.split(":")[-1].strip()
                elif stripped.startswith("Data Length"):
                    current["data_length"] = stripped.split(":")[-1].strip()
                elif stripped.startswith("A (Host) Record") or stripped.startswith("AAAA Record"):
                    current["ip_address"] = lines[lines.index(line) + 1].strip() if lines.index(line) + 1 < len(lines) else ""
            if current:
                entries.append(current)
    except (subprocess.TimeoutExpired, FileNotFoundError, subprocess.SubprocessError):
        pass
    return entries


def collect_arp_cache() -> list:
    entries = []
    try:
        result = subprocess.run(["arp", "-a"], capture_output=True, text=True, timeout=10)
        if result.returncode == 0:
            for line in result.stdout.splitlines():
                match = re.match(r'\s*(\d+\.\d+\.\d+\.\d+)\s+([0-9a-fA-F\-]+)\s+(\S+)', line)
                if match:
                    entries.append({
                        "ip": match.group(1),
                        "mac": match.group(2),
                        "type": match.group(3),
                    })
    except (subprocess.TimeoutExpired, FileNotFoundError, subprocess.SubprocessError):
        pass
    return entries


def collect_routing_table() -> list:
    entries = []
    try:
        result = subprocess.run(["route", "print"], capture_output=True, text=True, timeout=10)
        if result.returncode == 0:
            in_table = False
            for line in result.stdout.splitlines():
                if "Network Destination" in line and "Netmask" in line:
                    in_table = True
                    continue
                if in_table and line.strip() == "":
                    in_table = False
                    continue
                if in_table:
                    parts = line.split()
                    if len(parts) >= 4:
                        entries.append({
                            "network_destination": parts[0],
                            "netmask": parts[1],
                            "gateway": parts[2],
                            "interface": parts[3],
                            "metric": parts[4] if len(parts) > 4 else "",
                        })
    except (subprocess.TimeoutExpired, FileNotFoundError, subprocess.SubprocessError):
        pass
    return entries
