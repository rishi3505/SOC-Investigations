import requests
import json
import time

BASE_URL = "http://127.0.0.1:8000"

def test_health():
    print("\n--- Testing Health Check ---")
    response = requests.get(f"{BASE_URL}/health")
    print(f"Status Code: {response.status_code}")
    print(f"Response: {response.json()}")

def test_analyze_normal():
    print("\n--- Testing Analyze Endpoint (Normal Behavior) ---")
    payload = {
        "user_id": "default_user",
        "typing_speed": 55.0,
        "key_latency": 0.12,
        "avg_hold_time": 0.08,
        "mouse_speed": 350.0,
        "click_frequency": 1.2,
        "active_app": "VSCode",
        "app_switch_count": 1,
        "idle_time": 1.0,
        "time_of_day": 14,
        "session_duration": 120.0
    }
    
    response = requests.post(f"{BASE_URL}/api/v1/analyze", json=payload)
    print(f"Status Code: {response.status_code}")
    print(f"Response: {json.dumps(response.json(), indent=2)}")

def test_analyze_anomaly():
    print("\n--- Testing Analyze Endpoint (Anomalous Behavior) ---")
    # Sending extreme values to trigger HIGH risk
    payload = {
        "user_id": "default_user",
        "typing_speed": 250.0,  # Extremely fast
        "key_latency": 0.01,    # Extremely low
        "avg_hold_time": 0.005,
        "mouse_speed": 2500.0,
        "click_frequency": 25.0,
        "active_app": "HackerTool",
        "app_switch_count": 50,
        "idle_time": 0.0,
        "time_of_day": 3,
        "session_duration": 500.0
    }
    
    response = requests.post(f"{BASE_URL}/api/v1/analyze", json=payload)
    print(f"Status Code: {response.status_code}")
    print(f"Response: {json.dumps(response.json(), indent=2)}")

def test_feedback():
    print("\n--- Testing Feedback Endpoint ---")
    payload = {
        "behavior_id": 1,
        "label": "anomaly"
    }
    response = requests.post(f"{BASE_URL}/api/v1/feedback", json=payload)
    print(f"Status Code: {response.status_code}")
    print(f"Response: {response.json()}")

def test_retrain():
    print("\n--- Testing Retrain Endpoint ---")
    response = requests.post(f"{BASE_URL}/api/v1/retrain")
    print(f"Status Code: {response.status_code}")
    print(f"Response: {response.json()}")

if __name__ == "__main__":
    print("AI Behavioral Auth System - Advanced Integration Test")
    
    try:
        test_health()
        test_analyze_normal()
        test_analyze_anomaly()
        test_feedback()
        test_retrain()
    except requests.exceptions.ConnectionError:
        print("\n[ERROR] Could not connect to API. Is the server running? (Run: python ml_service/app.py)")
