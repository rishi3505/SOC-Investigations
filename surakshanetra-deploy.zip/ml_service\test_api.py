import json

from fastapi.testclient import TestClient

from ml_service.app import app


client = TestClient(app)


def _payload(**overrides):
    data = {
        "user_id": "default_user",
        "typing_speed": 55.0,
        "key_latency": 0.12,
        "avg_hold_time": 0.08,
        "latency_jitter": 0.02,
        "mouse_speed": 350.0,
        "mouse_acceleration": 0.5,
        "direction_change_freq": 4.0,
        "click_frequency": 1.2,
        "active_app": "VSCode",
        "app_switch_count": 1,
        "idle_time": 1.0,
        "time_of_day": 14,
        "session_duration": 120.0,
    }
    data.update(overrides)
    return data


def test_health():
    response = client.get("/health")
    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "online"
    assert "model_loaded" in body


def test_standard_health_endpoints():
    health = client.get("/api/v1/health")
    live = client.get("/api/v1/health/live")
    ready = client.get("/api/v1/health/ready")

    assert health.status_code == 200
    assert live.status_code == 200
    assert ready.status_code == 200
    assert live.json()["status"] == "alive"
    assert "checks" in ready.json()


def test_analyze_normal():
    response = client.post("/api/v1/analyze", json=_payload())
    assert response.status_code == 200
    body = response.json()
    assert "risk_score" in body
    assert "action" in body


def test_analyze_anomaly():
    response = client.post(
        "/api/v1/analyze",
        json=_payload(
            typing_speed=250.0,
            key_latency=0.01,
            avg_hold_time=0.005,
            latency_jitter=0.001,
            mouse_speed=2500.0,
            mouse_acceleration=8.0,
            direction_change_freq=45.0,
            click_frequency=25.0,
            active_app="HackerTool",
            app_switch_count=50,
            idle_time=0.0,
            time_of_day=3,
            session_duration=500.0,
        ),
    )
    assert response.status_code == 200
    assert "risk_level" in response.json()


def test_feedback():
    response = client.post("/api/v1/feedback", json={"behavior_id": 1, "label": "anomaly"})
    assert response.status_code == 200
    assert response.json()["status"] == "success"


def test_retrain():
    response = client.post("/api/v1/retrain")
    assert response.status_code == 200
    assert "Retraining started" in response.json()["message"]


if __name__ == "__main__":
    print("AI Behavioral Auth System - In-Process Smoke Test")
    for name, method, path, payload in [
        ("Health", "GET", "/health", None),
        ("Readiness", "GET", "/api/v1/health/ready", None),
        ("Analyze Normal", "POST", "/api/v1/analyze", _payload()),
    ]:
        response = client.request(method, path, json=payload)
        print(f"\n--- {name} ---")
        print(f"Status Code: {response.status_code}")
        print(json.dumps(response.json(), indent=2))
