import argparse
import os
import subprocess
import sys
import time

_AGENT_DIR = os.path.dirname(os.path.abspath(__file__))
_PARENT_DIR = os.path.dirname(_AGENT_DIR)
_BASE_DIR = _PARENT_DIR

if _AGENT_DIR not in sys.path:
    sys.path.insert(0, _AGENT_DIR)
if _PARENT_DIR not in sys.path:
    sys.path.insert(0, _PARENT_DIR)

PYTHON_EXE = sys.executable
SERVICE_SCRIPT = os.path.join(_AGENT_DIR, "service_worker.py")


def _run_powershell_silent(script: str) -> subprocess.CompletedProcess:
    return subprocess.run(
        ["powershell", "-NoProfile", "-Command", script],
        capture_output=True, text=True, timeout=60
    )


def install_service():
    print(f"Installing service: SurakshaNetraAgent...")
    print(f"  Python: {PYTHON_EXE}")
    print(f"  Script: {SERVICE_SCRIPT}")

    if not os.path.exists(SERVICE_SCRIPT):
        print(f"  ERROR: Service script not found at {SERVICE_SCRIPT}")
        return False

    script_dir = os.path.dirname(SERVICE_SCRIPT)
    parent_dir = os.path.dirname(script_dir)

    cmd = [
        PYTHON_EXE, SERVICE_SCRIPT,
        "--startup", "auto",
        "install"
    ]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)

    if result.returncode == 0:
        print("  Service installed successfully.")

        result = _run_powershell_silent("""
            $service = Get-Service -Name 'SurakshaNetraAgent' -ErrorAction SilentlyContinue
            if ($service) {
                $recovery = New-ItemProperty -Path 'HKLM:\\SYSTEM\\CurrentControlSet\\Services\\SurakshaNetraAgent' -Name 'FailureActions' -Value @()
                sc.exe failure SurakshaNetraAgent reset=86400 actions=restart/30000/restart/60000/restart/90000
                Set-Service -Name SurakshaNetraAgent -StartupType Automatic
                Write-Output 'Service configured: automatic startup, recovery actions set'
            }
        """)
        print(f"  {result.stdout.strip()}")
        return True
    else:
        print(f"  Failed to install service:")
        print(f"  {result.stderr}")
        return False


def uninstall_service():
    print("Uninstalling service: SurakshaNetraAgent...")

    result = _run_powershell_silent("""
        $service = Get-Service -Name 'SurakshaNetraAgent' -ErrorAction SilentlyContinue
        if ($service -and $service.Status -eq 'Running') {
            Stop-Service -Name SurakshaNetraAgent -Force -ErrorAction SilentlyContinue
            Start-Sleep -Seconds 2
        }
    """)

    cmd = [PYTHON_EXE, SERVICE_SCRIPT, "remove"]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)

    if result.returncode == 0:
        print("  Service uninstalled successfully.")
        return True
    else:
        print(f"  Failed to uninstall service:")
        print(f"  {result.stderr}")
        return False


def start_service():
    print("Starting service: SurakshaNetraAgent...")

    result = _run_powershell_silent("""
        $service = Get-Service -Name 'SurakshaNetraAgent' -ErrorAction SilentlyContinue
        if (-not $service) {
            Write-Output 'NOT_INSTALLED'
        } elseif ($service.Status -eq 'Running') {
            Write-Output 'ALREADY_RUNNING'
        } else {
            Start-Service -Name SurakshaNetraAgent
            Start-Sleep -Seconds 3
            $svc = Get-Service -Name SurakshaNetraAgent
            Write-Output $svc.Status
        }
    """)

    output = result.stdout.strip()
    if "NOT_INSTALLED" in output:
        print("  Service is not installed. Run 'python service_manager.py install' first.")
        return False
    elif "ALREADY_RUNNING" in output:
        print("  Service is already running.")
        return True
    elif "Running" in output:
        print("  Service started successfully.")
        return True
    else:
        print(f"  Failed to start service. Status: {output}")
        return False


def stop_service():
    print("Stopping service: SurakshaNetraAgent...")

    result = _run_powershell_silent("""
        $service = Get-Service -Name 'SurakshaNetraAgent' -ErrorAction SilentlyContinue
        if (-not $service) {
            Write-Output 'NOT_INSTALLED'
        } elseif ($service.Status -eq 'Stopped') {
            Write-Output 'ALREADY_STOPPED'
        } else {
            Stop-Service -Name SurakshaNetraAgent -Force -ErrorAction SilentlyContinue
            Start-Sleep -Seconds 3
            $svc = Get-Service -Name SurakshaNetraAgent
            Write-Output $svc.Status
        }
    """)

    output = result.stdout.strip()
    if "NOT_INSTALLED" in output:
        print("  Service is not installed.")
        return False
    elif "ALREADY_STOPPED" in output:
        print("  Service is already stopped.")
        return True
    elif "Stopped" in output:
        print("  Service stopped successfully.")
        return True
    else:
        print(f"  Failed to stop service. Status: {output}")
        return False


def restart_service():
    print("Restarting service: SurakshaNetraAgent...")
    stop_service()
    time.sleep(2)
    return start_service()


def check_status():
    result = _run_powershell_silent("""
        $service = Get-Service -Name 'SurakshaNetraAgent' -ErrorAction SilentlyContinue
        if (-not $service) {
            Write-Output 'STATUS=NOT_INSTALLED'
        } else {
            Write-Output "STATUS=$($service.Status)"
            Write-Output "START_TYPE=$($service.StartType)"
            try {
                $proc = Get-CimInstance -ClassName Win32_Service | Where-Object { $_.Name -eq 'SurakshaNetraAgent' }
                if ($proc) {
                    Write-Output "PATH=$($proc.PathName)"
                    Write-Output "PID=$($proc.ProcessId)"
                }
            } catch {}
        }
    """)

    print("SurakshaNetra Agent Service Status")
    print("=" * 50)
    for line in result.stdout.strip().split("\n"):
        if line.strip():
            print(f"  {line.strip()}")

    if "NOT_INSTALLED" in result.stdout:
        print("\n  Service is NOT installed.")
        print("  Run: python service_manager.py install")
        return False

    print("\n  Commands:")
    print("    python service_manager.py start")
    print("    python service_manager.py stop")
    print("    python service_manager.py restart")
    print("    python service_manager.py uninstall")
    return True


def main():
    parser = argparse.ArgumentParser(
        description="SurakshaNetra Agent Service Manager",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python service_manager.py install     Install the Windows service
  python service_manager.py start       Start the service
  python service_manager.py stop        Stop the service
  python service_manager.py status      Check service status
  python service_manager.py uninstall   Remove the service
        """
    )
    parser.add_argument("command", nargs="?", default="status",
                        choices=["install", "uninstall", "start", "stop", "restart", "status"],
                        help="Command to execute")

    args = parser.parse_args()

    commands = {
        "install": install_service,
        "uninstall": uninstall_service,
        "start": start_service,
        "stop": stop_service,
        "restart": restart_service,
        "status": check_status,
    }

    success = commands[args.command]()
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
