<#
.SYNOPSIS
    Run all enterprise tests on the CMS
.DESCRIPTION
    Activates venv and runs the enterprise test suite against a running CMS.
.EXAMPLE
    .\scripts\test.ps1
    .\scripts\test.ps1 -Test test_enterprise.py
#>

param(
    [string]$Test = "test_enterprise.py",
    [switch]$Verbose
)

$ProjectRoot = Split-Path -Parent (Split-Path -Parent $PSCommandPath)
$venvPython = Join-Path $ProjectRoot ".venv\Scripts\python.exe"

if (-not (Test-Path $venvPython)) {
    Write-Host "Virtual environment not found. Run scripts\install.ps1 first." -ForegroundColor Red
    exit 1
}

$extraArgs = @()
if ($Verbose) { $extraArgs += "-v" }

Write-Host "Running $Test ..." -ForegroundColor Cyan
& $venvPython -m pytest "$ProjectRoot\$Test" -q @extraArgs --tb=short

if ($LASTEXITCODE -eq 0) {
    Write-Host "`nAll tests passed!" -ForegroundColor Green
} else {
    Write-Host "`nSome tests failed." -ForegroundColor Red
}
exit $LASTEXITCODE
