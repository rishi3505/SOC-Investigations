import time
import platform

try:
    import win32evtlog
    import win32evtlogutil
    import win32security
    import win32api
    import pywintypes
    HAS_WIN32 = True
except ImportError:
    HAS_WIN32 = False

EVENT_LOG_TYPES = {
    "Application": "Application",
    "System": "System",
    "Security": "Security",
}

QUERY_EVENT_IDS = {
    "Logon": [4624, 4648],
    "Logoff": [4634, 4647],
    "Service Changes": [7034, 7035, 7036, 7040, 7045],
    "Application Errors": [1000, 1001, 1002],
    "Security Events": [4625, 4649, 4672, 4688, 4698, 4699, 4700, 4702],
}


def collect_windows_events(log_name: str = "System", max_events: int = 200) -> list:
    if not HAS_WIN32:
        return []
    events = []
    try:
        hand = win32evtlog.OpenEventLog(None, log_name)
        flags = win32evtlog.EVENTLOG_BACKWARDS_READ | win32evtlog.EVENTLOG_SEQUENTIAL_READ
        batch = win32evtlog.ReadEventLog(hand, flags, 0)
        count = 0
        for event in batch:
            if count >= max_events:
                break
            try:
                events.append({
                    "event_id": event.EventID,
                    "event_category": event.EventCategory,
                    "source": event.SourceName,
                    "time_generated": event.TimeGenerated.Format() if event.TimeGenerated else None,
                    "time_written": event.TimeWritten.Format() if event.TimeWritten else None,
                    "event_type": event.EventType,
                    "computer": event.ComputerName,
                    "message": _extract_event_message(event),
                    "strings": list(event.StringInserts) if event.StringInserts else [],
                })
            except Exception:
                pass
            count += 1
        win32evtlog.CloseEventLog(hand)
    except Exception:
        pass
    return events


def collect_relevant_events(max_events_per_type: int = 50) -> dict:
    result = {}
    for category, event_ids in QUERY_EVENT_IDS.items():
        events = _query_events_by_ids(event_ids, max_events_per_type)
        if events:
            result[category] = events
    return result


def _query_events_by_ids(event_ids: list, max_events: int) -> list:
    if not HAS_WIN32:
        return []
    events = []
    for log_name in ["Security", "System", "Application"]:
        try:
            hand = win32evtlog.OpenEventLog(None, log_name)
            flags = win32evtlog.EVENTLOG_BACKWARDS_READ | win32evtlog.EVENTLOG_SEQUENTIAL_READ
            batch = win32evtlog.ReadEventLog(hand, flags, 0)
            count = 0
            for event in batch:
                if count >= max_events:
                    break
                try:
                    event_id = event.EventID
                    if event_id in event_ids:
                        events.append({
                            "log": log_name,
                            "event_id": event_id,
                            "source": event.SourceName,
                            "time_generated": event.TimeGenerated.Format() if event.TimeGenerated else None,
                            "event_type": event.EventType,
                            "computer": event.ComputerName,
                            "category": event.EventCategory,
                            "message": _extract_event_message(event),
                        })
                        count += 1
                except Exception:
                    pass
            win32evtlog.CloseEventLog(hand)
        except Exception:
            pass
    return events


def _extract_event_message(event) -> str:
    try:
        return str(event.StringInserts) if event.StringInserts else ""
    except Exception:
        return ""


if not HAS_WIN32:

    def collect_windows_events(log_name="System", max_events=200):
        return []

    def collect_relevant_events(max_events_per_type=50):
        return {}


def write_custom_event_log(source: str, message: str, event_id: int = 1000, event_type: int = None):
    if not HAS_WIN32:
        return False
    if event_type is None:
        event_type = win32evtlog.EVENTLOG_WARNING_TYPE
    try:
        win32evtlogutil.ReportEvent(
            appName=source,
            eventID=event_id,
            eventCategory=0,
            eventType=event_type,
            strings=[message],
            data=None,
        )
        return True
    except Exception as e:
        return False
