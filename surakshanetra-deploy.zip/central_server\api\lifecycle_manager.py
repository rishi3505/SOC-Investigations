"""
Lifecycle Manager — Endpoint state machine with audit trail.
States: PENDING_REGISTRATION -> REGISTERED -> APPROVED -> ACTIVE ->
        INACTIVE / OFFLINE / MAINTENANCE / QUARANTINED -> RETIRED
"""
import json
import time
from fastapi import APIRouter, Depends, HTTPException, Query
from ..database import get_connection
from ..auth import authenticate_request
from ..models import TransitionRequest, BulkTransitionRequest

router = APIRouter(prefix="/api/v1/lifecycle", tags=["Endpoint Lifecycle"])

VALID_LIFECYCLE_STATES = frozenset({
    "PENDING_REGISTRATION", "REGISTERED", "APPROVED", "ACTIVE",
    "INACTIVE", "OFFLINE", "MAINTENANCE", "QUARANTINED", "RETIRED",
})

VALID_TRANSITIONS = {
    "PENDING_REGISTRATION": {"REGISTERED"},
    "REGISTERED": {"APPROVED", "QUARANTINED", "RETIRED"},
    "APPROVED": {"ACTIVE", "QUARANTINED", "RETIRED"},
    "ACTIVE": {"INACTIVE", "OFFLINE", "MAINTENANCE", "QUARANTINED", "RETIRED"},
    "INACTIVE": {"ACTIVE", "MAINTENANCE", "RETIRED"},
    "OFFLINE": {"ACTIVE", "INACTIVE", "MAINTENANCE", "RETIRED"},
    "MAINTENANCE": {"ACTIVE", "INACTIVE", "RETIRED"},
    "QUARANTINED": {"ACTIVE", "MAINTENANCE", "RETIRED"},
    "RETIRED": set(),
}


def _is_valid_transition(from_state: str, to_state: str) -> bool:
    if from_state not in VALID_TRANSITIONS:
        return False
    return to_state in VALID_TRANSITIONS[from_state]


def _log_transition(conn, endpoint_id: str, from_status: str, to_status: str, triggered_by: str, reason: str = ""):
    now = int(time.time())
    conn.execute(
        "INSERT INTO endpoint_lifecycle_log (endpoint_id, from_status, to_status, triggered_by, reason, timestamp) VALUES (?, ?, ?, ?, ?, ?)",
        (endpoint_id, from_status, to_status, triggered_by, reason, now),
    )
    _write_audit(conn, f"endpoint.{to_status.lower()}", "lifecycle", "endpoint", endpoint_id, triggered_by, {"from": from_status, "to": to_status, "reason": reason})


def _write_audit(conn, action: str, category: str, target_type: str, target_id: str, actor: str, details: dict):
    now = int(time.time())
    try:
        conn.execute(
            "INSERT INTO audit_logs_extended (action, category, target_type, target_id, actor, details, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (action, category, target_type, target_id, actor, json.dumps(details), now),
        )
    except Exception:
        pass


@router.get("/states")
async def list_states(user: dict = Depends(authenticate_request)):
    return {
        "states": sorted(VALID_LIFECYCLE_STATES),
        "transitions": {s: sorted(t) for s, t in VALID_TRANSITIONS.items()},
    }


@router.get("/endpoints")
async def list_lifecycle_endpoints(
    status: str = None,
    page: int = Query(1, ge=1),
    limit: int = Query(50, ge=1, le=200),
    user: dict = Depends(authenticate_request),
):
    conn = get_connection()
    conditions = []
    params = []
    if status:
        if status.upper() not in VALID_LIFECYCLE_STATES:
            raise HTTPException(status_code=400, detail=f"Invalid state: {status}")
        conditions.append("lifecycle_status = ?")
        params.append(status.upper())
    if user.get("org_id"):
        conditions.append("org_id = ?")
        params.append(user["org_id"])
    where = "WHERE " + " AND ".join(conditions) if conditions else ""
    offset = (page - 1) * limit
    total = conn.execute(f"SELECT COUNT(*) FROM endpoints {where}", params).fetchone()[0]
    rows = conn.execute(
        f"SELECT endpoint_id, hostname, lifecycle_status, lifecycle_updated_at, health_status, health_score, update_status, group_id, current_config_version, last_seen, first_seen, agent_version, os, ip_address FROM endpoints {where} ORDER BY lifecycle_updated_at DESC LIMIT ? OFFSET ?",
        (*params, limit, offset)
    ).fetchall()
    conn.close()
    return {"endpoints": [dict(r) for r in rows], "total": total, "page": page, "limit": limit}


@router.post("/endpoints/{endpoint_id}/transition")
async def transition_endpoint(
    endpoint_id: str,
    payload: TransitionRequest,
    user: dict = Depends(authenticate_request),
):
    to_state = payload.to_state.upper()
    reason = payload.reason
    if to_state not in VALID_LIFECYCLE_STATES:
        raise HTTPException(status_code=400, detail=f"Invalid target state: {to_state}")

    conn = get_connection()
    row = conn.execute("SELECT lifecycle_status FROM endpoints WHERE endpoint_id = ?", (endpoint_id,)).fetchone()
    if not row:
        conn.close()
        raise HTTPException(status_code=404, detail="Endpoint not found")

    from_state = row["lifecycle_status"] or "PENDING_REGISTRATION"
    if not _is_valid_transition(from_state, to_state):
        conn.close()
        raise HTTPException(status_code=400, detail=f"Cannot transition from {from_state} to {to_state}")

    now = int(time.time())
    conn.execute(
        "UPDATE endpoints SET lifecycle_status = ?, lifecycle_updated_at = ? WHERE endpoint_id = ?",
        (to_state, now, endpoint_id),
    )
    _log_transition(conn, endpoint_id, from_state, to_state, payload.triggered_by, reason)
    conn.commit()
    conn.close()
    return {"status": "transitioned", "endpoint_id": endpoint_id, "from": from_state, "to": to_state}


@router.get("/endpoints/{endpoint_id}/history")
async def get_lifecycle_history(endpoint_id: str, limit: int = Query(50, ge=1, le=200), user: dict = Depends(authenticate_request)):
    conn = get_connection()
    rows = conn.execute(
        "SELECT * FROM endpoint_lifecycle_log WHERE endpoint_id = ? ORDER BY timestamp DESC LIMIT ?",
        (endpoint_id, limit),
    ).fetchall()
    conn.close()
    return {"endpoint_id": endpoint_id, "transitions": [dict(r) for r in rows]}


@router.post("/endpoints/bulk-transition")
async def bulk_transition(payload: BulkTransitionRequest, user: dict = Depends(authenticate_request)):
    endpoint_ids = payload.endpoint_ids
    to_state = payload.to_state.upper()
    reason = payload.reason
    if to_state not in VALID_LIFECYCLE_STATES:
        raise HTTPException(status_code=400, detail=f"Invalid state: {to_state}")
    conn = get_connection()
    now = int(time.time())
    results = []
    for eid in endpoint_ids:
        row = conn.execute("SELECT lifecycle_status FROM endpoints WHERE endpoint_id = ?", (eid,)).fetchone()
        if not row:
            results.append({"endpoint_id": eid, "status": "error", "detail": "not_found"})
            continue
        from_state = row["lifecycle_status"] or "PENDING_REGISTRATION"
        if not _is_valid_transition(from_state, to_state):
            results.append({"endpoint_id": eid, "status": "error", "detail": f"invalid_transition:{from_state}->{to_state}"})
            continue
        conn.execute("UPDATE endpoints SET lifecycle_status = ?, lifecycle_updated_at = ? WHERE endpoint_id = ?", (to_state, now, eid))
        _log_transition(conn, eid, from_state, to_state, user.get("username", "admin"), reason)
        results.append({"endpoint_id": eid, "status": "transitioned", "from": from_state, "to": to_state})
    conn.commit()
    conn.close()
    return {"results": results, "total": len(results)}
