import os
import platform
import socket
import time
import subprocess
from datetime import datetime

try:
    import psutil
except ImportError:
    psutil = None


def collect_system_info() -> dict:
    hostname = socket.gethostname()
    boot_time = None
    uptime_seconds = 0
    disk_usage = {}
    memory = {}

    if psutil:
        boot_time = psutil.boot_time()
        uptime_seconds = time.time() - boot_time
        disk_usage = psutil.disk_usage("/")._asdict() if hasattr(psutil, "disk_usage") else {}
        mem = psutil.virtual_memory()
        memory = {
            "total": mem.total,
            "available": mem.available,
            "percent": mem.percent,
            "used": mem.used,
            "free": mem.free,
        }

    return {
        "hostname": hostname,
        "os": platform.system(),
        "os_version": platform.version(),
        "os_release": platform.release(),
        "architecture": platform.machine(),
        "processor": platform.processor(),
        "python_version": platform.python_version(),
        "boot_time": boot_time,
        "boot_time_iso": datetime.fromtimestamp(boot_time).isoformat() if boot_time else None,
        "uptime_seconds": uptime_seconds,
        "uptime_human": _format_uptime(uptime_seconds),
        "current_user": _get_current_user(),
        "disk_usage": disk_usage,
        "memory": memory,
        "environment_variables": dict(os.environ),
        "collection_time": int(time.time()),
    }


def collect_device_fingerprint() -> dict:
    info = {}
    if platform.system() == "Windows":
        try:
            import winreg
            keys = [
                (winreg.HKEY_LOCAL_MACHINE, r"HARDWARE\DESCRIPTION\System\BIOS", "SystemManufacturer"),
                (winreg.HKEY_LOCAL_MACHINE, r"HARDWARE\DESCRIPTION\System\BIOS", "SystemProductName"),
                (winreg.HKEY_LOCAL_MACHINE, r"HARDWARE\DESCRIPTION\System\BIOS", "SystemVersion"),
                (winreg.HKEY_LOCAL_MACHINE, r"HARDWARE\DESCRIPTION\System\BIOS", "BIOSVendor"),
                (winreg.HKEY_LOCAL_MACHINE, r"HARDWARE\DESCRIPTION\System\BIOS", "BIOSVersion"),
                (winreg.HKEY_LOCAL_MACHINE, r"HARDWARE\DESCRIPTION\System\BIOS", "BIOSReleaseDate"),
            ]
            for hkey, path, value in keys:
                try:
                    with winreg.OpenKey(hkey, path) as key:
                        info[value] = winreg.QueryValueEx(key, value)[0]
                except (OSError, FileNotFoundError):
                    pass
        except ImportError:
            pass
    info["hostname"] = socket.gethostname()
    info["domain"] = os.environ.get("USERDOMAIN", "")
    return info


def collect_ip_addresses() -> list:
    addresses = []
    if psutil:
        for iface, addrs in psutil.net_if_addrs().items():
            for addr in addrs:
                if addr.family == socket.AF_INET:
                    addresses.append({
                        "interface": iface,
                        "ip": addr.address,
                        "netmask": addr.netmask,
                        "broadcast": addr.broadcast,
                    })
    if not addresses:
        try:
            hostname = socket.gethostname()
            ip = socket.gethostbyname(hostname)
            addresses.append({"interface": "default", "ip": ip})
        except socket.gaierror:
            pass
    return addresses


def collect_windows_version() -> dict:
    return {
        "system": platform.system(),
        "release": platform.release(),
        "version": platform.version(),
        "machine": platform.machine(),
        "processor": platform.processor(),
        "node": platform.node(),
    }


def collect_logged_in_users() -> list:
    users = []
    if psutil:
        for user in psutil.users():
            users.append({
                "name": user.name,
                "terminal": user.terminal,
                "host": user.host,
                "started": user.started,
                "started_iso": datetime.fromtimestamp(user.started).isoformat() if user.started else None,
                "pid": user.pid,
            })
    return users


def _get_current_user() -> str:
    try:
        return os.getlogin()
    except OSError:
        return os.environ.get("USERNAME", os.environ.get("USER", "unknown"))


def _format_uptime(seconds: float) -> str:
    days = int(seconds // 86400)
    hours = int((seconds % 86400) // 3600)
    minutes = int((seconds % 3600) // 60)
    secs = int(seconds % 60)
    parts = []
    if days > 0:
        parts.append(f"{days}d")
    if hours > 0:
        parts.append(f"{hours}h")
    if minutes > 0:
        parts.append(f"{minutes}m")
    parts.append(f"{secs}s")
    return " ".join(parts)
