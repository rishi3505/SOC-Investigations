"""
Configuration Manager — Centralized configuration profiles with versioning,
assignment to endpoints/groups, drift detection, and agent sync.
"""
import json
import time
from fastapi import APIRouter, Depends, HTTPException, Query
from ..database import get_connection
from ..auth import authenticate_request
from ..models import CreateProfileRequest, UpdateProfileRequest, AssignConfigRequest, SyncConfigRequest, DriftReportRequest

router = APIRouter(prefix="/api/v1/config", tags=["Configuration Manager"])


def _write_audit(conn, action, category, target_type, target_id, actor, details):
    now = int(time.time())
    try:
        conn.execute(
            "INSERT INTO audit_logs_extended (action, category, target_type, target_id, actor, details, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (action, category, target_type, target_id, actor, json.dumps(details), now),
        )
    except Exception:
        pass


DEFAULT_CONFIG = {
    "sampling": {"interval_seconds": 2, "sliding_window_size": 5, "idle_interval_seconds": 5, "idle_threshold_seconds": 10},
    "ml": {"anomaly_threshold": 0.7, "confidence_threshold": 0.5, "adaptation_rate": 0.01},
    "response": {"max_risk_level": "CRITICAL", "auto_contain": True, "require_mfa_for": ["HIGH", "CRITICAL"]},
    "logging": {"level": "INFO", "max_file_size_mb": 10, "retention_days": 30},
    "heartbeat": {"interval_seconds": 60, "timeout_seconds": 120},
    "threat_hunting": {"frequency_minutes": 360, "max_results": 100},
    "monitoring": {"keyboard": True, "mouse": True, "system": True, "location": True, "device_fingerprint": True},
    "updates": {"auto_update": False, "maintenance_window": "02:00-04:00"},
    "retention": {"behavior_days": 90, "incident_days": 365, "heartbeat_days": 30},
}


@router.post("/profiles")
async def create_profile(payload: CreateProfileRequest, user: dict = Depends(authenticate_request)):
    name = payload.name
    if not name:
        raise HTTPException(status_code=400, detail="Profile name required")
    config = payload.config
    conn = get_connection()
    now = int(time.time())
    try:
        cursor = conn.execute(
            "INSERT INTO config_profiles (name, description, config_json, version, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?)",
            (name, payload.description, json.dumps(config) if isinstance(config, dict) else config, payload.version, user.get("username", "admin"), now),
        )
        profile_id = cursor.lastrowid
        _write_audit(conn, "config.profile.create", "configuration", "config_profile", str(profile_id), user.get("username", "admin"), {"name": name})
        conn.commit()
        conn.close()
        return {"status": "created", "profile_id": profile_id, "name": name}
    except Exception as e:
        conn.close()
        raise HTTPException(status_code=400, detail=str(e))


@router.get("/profiles")
async def list_profiles(active: bool = None, user: dict = Depends(authenticate_request)):
    conn = get_connection()
    if active is not None:
        rows = conn.execute("SELECT * FROM config_profiles WHERE active = ? ORDER BY name", (1 if active else 0,)).fetchall()
    else:
        rows = conn.execute("SELECT * FROM config_profiles ORDER BY name").fetchall()
    conn.close()
    return {"profiles": [dict(r) for r in rows]}


@router.get("/profiles/{profile_id}")
async def get_profile(profile_id: int, user: dict = Depends(authenticate_request)):
    conn = get_connection()
    row = conn.execute("SELECT * FROM config_profiles WHERE id = ?", (profile_id,)).fetchone()
    conn.close()
    if not row:
        raise HTTPException(status_code=404, detail="Profile not found")
    return dict(row)


@router.put("/profiles/{profile_id}")
async def update_profile(profile_id: int, payload: UpdateProfileRequest, user: dict = Depends(authenticate_request)):
    conn = get_connection()
    row = conn.execute("SELECT * FROM config_profiles WHERE id = ?", (profile_id,)).fetchone()
    if not row:
        conn.close()
        raise HTTPException(status_code=404, detail="Profile not found")
    profile = dict(row)
    now = int(time.time())
    old_version = profile["version"]
    parts = old_version.split(".")
    new_version = f"{int(parts[0])}.{int(parts[1]) + 1}.0" if len(parts) >= 2 else "2.0.0"

    update_data = payload.model_dump(exclude_none=True)
    config_val = update_data.pop("config", None) or update_data.pop("config_json", None)
    if config_val is not None:
        conn.execute("UPDATE config_profiles SET config_json = ?, version = ?, updated_at = ? WHERE id = ?",
                     (json.dumps(config_val) if isinstance(config_val, dict) else config_val, new_version, now, profile_id))
    if payload.name is not None:
        conn.execute("UPDATE config_profiles SET name = ?, version = ?, updated_at = ? WHERE id = ?",
                     (payload.name, new_version, now, profile_id))
    if payload.active is not None:
        conn.execute("UPDATE config_profiles SET active = ?, updated_at = ? WHERE id = ?",
                     (1 if payload.active else 0, now, profile_id))
    if payload.description is not None:
        conn.execute("UPDATE config_profiles SET description = ?, updated_at = ? WHERE id = ?",
                     (payload.description, now, profile_id))
    _write_audit(conn, "config.profile.update", "configuration", "config_profile", str(profile_id),
                 user.get("username", "admin"), {"name": profile["name"], "old_version": old_version, "new_version": new_version})
    conn.commit()
    conn.close()
    return {"status": "updated", "profile_id": profile_id, "version": new_version}


@router.delete("/profiles/{profile_id}")
async def delete_profile(profile_id: int, user: dict = Depends(authenticate_request)):
    conn = get_connection()
    row = conn.execute("SELECT name FROM config_profiles WHERE id = ?", (profile_id,)).fetchone()
    if not row:
        conn.close()
        raise HTTPException(status_code=404, detail="Profile not found")
    conn.execute("DELETE FROM config_assignments WHERE profile_id = ?", (profile_id,))
    conn.execute("DELETE FROM config_profiles WHERE id = ?", (profile_id,))
    _write_audit(conn, "config.profile.delete", "configuration", "config_profile", str(profile_id),
                 user.get("username", "admin"), {"name": row["name"]})
    conn.commit()
    conn.close()
    return {"status": "deleted"}


@router.post("/assign")
async def assign_profile(payload: AssignConfigRequest, user: dict = Depends(authenticate_request)):
    profile_id = payload.profile_id
    target_type = payload.target_type
    target_ids = payload.target_ids
    if not profile_id or not target_ids:
        raise HTTPException(status_code=400, detail="profile_id and target_ids required")
    conn = get_connection()
    now = int(time.time())
    try:
        for target_id in target_ids:
            conn.execute(
                "INSERT OR REPLACE INTO config_assignments (profile_id, target_type, target_id, assigned_at, status) VALUES (?, ?, ?, ?, 'PENDING')",
                (profile_id, target_type, target_id, now),
            )
            if target_type == "endpoint":
                conn.execute("UPDATE endpoints SET current_config_id = ? WHERE endpoint_id = ?", (profile_id, target_id))
            _write_audit(conn, "config.assign", "configuration", target_type, target_id,
                         user.get("username", "admin"), {"profile_id": profile_id})
        conn.commit()
        conn.close()
        return {"status": "assigned", "profile_id": profile_id, "target_type": target_type, "target_ids": target_ids}
    except Exception as e:
        conn.close()
        raise HTTPException(status_code=400, detail=str(e))


@router.get("/assignments")
async def list_assignments(profile_id: int = None, target_type: str = None, user: dict = Depends(authenticate_request)):
    conn = get_connection()
    conditions = []
    params = []
    if profile_id:
        conditions.append("profile_id = ?"); params.append(profile_id)
    if target_type:
        conditions.append("target_type = ?"); params.append(target_type)
    where = "WHERE " + " AND ".join(conditions) if conditions else ""
    rows = conn.execute(f"SELECT * FROM config_assignments {where} ORDER BY assigned_at DESC", params).fetchall()
    conn.close()
    return {"assignments": [dict(r) for r in rows]}


@router.post("/sync/{endpoint_id}")
async def sync_config(endpoint_id: str, payload: SyncConfigRequest, user: dict = Depends(authenticate_request)):
    """Agent-facing: endpoint requests its assigned configuration."""
    conn = get_connection()
    ep = conn.execute("SELECT current_config_id, current_config_version FROM endpoints WHERE endpoint_id = ?", (endpoint_id,)).fetchone()
    if not ep:
        conn.close()
        raise HTTPException(status_code=404, detail="Endpoint not found")

    config_data = {}
    version = "0"
    profile_id = payload.profile_id or ep["current_config_id"]

    if profile_id:
        row = conn.execute("SELECT config_json, version FROM config_profiles WHERE id = ? AND active = 1", (profile_id,)).fetchone()
        if row:
            config_data = json.loads(row["config_json"])
            version = row["version"]

    conn.execute("UPDATE endpoints SET current_config_version = ? WHERE endpoint_id = ?", (version, endpoint_id))
    conn.execute("UPDATE config_assignments SET status = 'APPLIED', applied_at = ? WHERE profile_id = ? AND target_id = ? AND target_type = 'endpoint'",
                 (int(time.time()), profile_id, endpoint_id) if profile_id else (int(time.time()), 0, endpoint_id))
    conn.commit()
    conn.close()

    return {
        "endpoint_id": endpoint_id,
        "config_version": version,
        "config": config_data,
    }


@router.get("/drift")
async def list_config_drift(user: dict = Depends(authenticate_request)):
    conn = get_connection()
    rows = conn.execute("SELECT * FROM config_drift_log ORDER BY detected_at DESC LIMIT 100").fetchall()
    conn.close()
    return {"drift_events": [dict(r) for r in rows]}


@router.post("/drift/report")
async def report_config_drift(payload: DriftReportRequest, user: dict = Depends(authenticate_request)):
    conn = get_connection()
    now = int(time.time())
    conn.execute(
        "INSERT INTO config_drift_log (endpoint_id, profile_id, expected_version, actual_version, drift_details, detected_at) VALUES (?, ?, ?, ?, ?, ?)",
        (payload.endpoint_id, payload.profile_id, "", payload.drift_score, json.dumps(payload.drift_json) if isinstance(payload.drift_json, dict) else payload.drift_json, now),
    )
    _write_audit(conn, "config.drift.detected", "configuration", "endpoint", payload.endpoint_id,
                 user.get("username", "system"), payload.model_dump())
    conn.commit()
    conn.close()
    return {"status": "reported"}
