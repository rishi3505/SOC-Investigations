"""
Threat Hunting Engine — Runs detection rules against historical behavior data in the
CMS database, correlates with IOC matches, and stores hunt results separately from incidents.
"""
import json
import os
import sqlite3
import time
import uuid
from threading import Lock
from typing import Optional

HUNT_DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "hunt_store.db")

HUNT_SEVERITIES = frozenset({"INFORMATIONAL", "LOW", "MEDIUM", "HIGH", "CRITICAL"})
HUNT_STATUSES = frozenset({"OPEN", "VERIFIED", "FALSE_POSITIVE", "ESCALATED", "CLOSED"})


def _get_conn() -> sqlite3.Connection:
    conn = sqlite3.connect(HUNT_DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    return conn


def init_hunt_db():
    conn = _get_conn()
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS hunt_results (
            id TEXT PRIMARY KEY,
            rule_id TEXT NOT NULL,
            rule_title TEXT NOT NULL,
            severity TEXT NOT NULL DEFAULT 'MEDIUM',
            status TEXT NOT NULL DEFAULT 'OPEN',
            mitre_technique_id TEXT DEFAULT '',
            mitre_technique_name TEXT DEFAULT '',
            mitre_tactic TEXT DEFAULT '',
            endpoint_id TEXT DEFAULT '',
            user_id TEXT DEFAULT '',
            risk_score REAL DEFAULT 0,
            match_reasons TEXT DEFAULT '[]',
            matched_iocs TEXT DEFAULT '[]',
            payload_snapshot TEXT DEFAULT '{}',
            analyst_notes TEXT DEFAULT '',
            created_at INTEGER NOT NULL,
            verified_at INTEGER,
            verified_by TEXT DEFAULT ''
        );
        CREATE INDEX IF NOT EXISTS idx_hunt_severity ON hunt_results(severity);
        CREATE INDEX IF NOT EXISTS idx_hunt_status ON hunt_results(status);
        CREATE INDEX IF NOT EXISTS idx_hunt_rule ON hunt_results(rule_id);
        CREATE INDEX IF NOT EXISTS idx_hunt_mitre ON hunt_results(mitre_technique_id);
        CREATE INDEX IF NOT EXISTS idx_hunt_created ON hunt_results(created_at);
    """)
    conn.commit()
    conn.close()


class ThreatHunter:
    def __init__(self):
        self._lock = Lock()
        self._stats = {"total_hunts": 0, "total_findings": 0, "last_hunt_time": 0}
        self._running = False

    def hunt(
        self,
        rule_id: str,
        rule_title: str,
        severity: str = "MEDIUM",
        mitre_technique_id: str = "",
        mitre_technique_name: str = "",
        mitre_tactic: str = "",
        endpoint_id: str = "",
        user_id: str = "",
        risk_score: float = 0,
        match_reasons: Optional[list] = None,
        matched_iocs: Optional[list] = None,
        payload_snapshot: Optional[dict] = None,
    ) -> str:
        severity = severity.upper()
        if severity not in HUNT_SEVERITIES:
            severity = "MEDIUM"
        now = int(time.time())
        hunt_id = f"HUNT-{uuid.uuid4().hex[:8].upper()}-{now}"

        conn = _get_conn()
        conn.execute("""
            INSERT INTO hunt_results
                (id, rule_id, rule_title, severity, mitre_technique_id,
                 mitre_technique_name, mitre_tactic, endpoint_id, user_id,
                 risk_score, match_reasons, matched_iocs, payload_snapshot, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            hunt_id, rule_id, rule_title, severity,
            mitre_technique_id, mitre_technique_name, mitre_tactic,
            endpoint_id, user_id, risk_score,
            json.dumps(match_reasons or []),
            json.dumps(matched_iocs or []),
            json.dumps(payload_snapshot or {}),
            now,
        ))
        conn.commit()
        conn.close()

        with self._lock:
            self._stats["total_hunts"] += 1
            self._stats["total_findings"] += 1
            self._stats["last_hunt_time"] = now

        return hunt_id

    def bulk_hunt(self, results: list[dict]) -> list[str]:
        ids = []
        for r in results:
            ids.append(self.hunt(**r))
        return ids

    def run_hunt_cycle(self, behavior_records: list[dict], ioc_matches_by_record: dict[str, list[dict]]) -> list[str]:
        from rules.rule_engine import evaluate_all_rules

        hunt_ids = []
        for record in behavior_records:
            record_id = record.get("id") or record.get("endpoint_id", "unknown")
            iocs = ioc_matches_by_record.get(str(record_id), [])
            triggered = evaluate_all_rules(record, iocs)
            for result in triggered:
                hid = self.hunt(
                    rule_id=result["rule_id"],
                    rule_title=result["rule_title"],
                    severity=result["severity"],
                    mitre_technique_id=result["mitre_technique_id"],
                    mitre_technique_name=result["mitre_technique_name"],
                    mitre_tactic=result["mitre_tactic"],
                    endpoint_id=record.get("endpoint_id", ""),
                    user_id=record.get("user_id", ""),
                    risk_score=record.get("risk_score", 0),
                    match_reasons=result["match_reasons"],
                    matched_iocs=[i.get("value") for i in iocs],
                    payload_snapshot=record,
                )
                hunt_ids.append(hid)
        return hunt_ids

    def get_results(
        self,
        severity: Optional[str] = None,
        status: Optional[str] = None,
        rule_id: Optional[str] = None,
        mitre_technique: Optional[str] = None,
        page: int = 1,
        limit: int = 50,
    ) -> dict:
        conn = _get_conn()
        conditions = []
        params = []
        if severity:
            conditions.append("severity = ?"); params.append(severity.upper())
        if status:
            conditions.append("status = ?"); params.append(status.upper())
        if rule_id:
            conditions.append("rule_id LIKE ?"); params.append(f"%{rule_id}%")
        if mitre_technique:
            conditions.append("mitre_technique_id LIKE ?"); params.append(f"%{mitre_technique}%")
        where = "WHERE " + " AND ".join(conditions) if conditions else ""
        offset = (page - 1) * limit
        total = conn.execute(f"SELECT COUNT(*) FROM hunt_results {where}", params).fetchone()[0]
        rows = conn.execute(
            f"SELECT * FROM hunt_results {where} ORDER BY created_at DESC LIMIT ? OFFSET ?",
            (*params, limit, offset)
        ).fetchall()
        conn.close()
        return {
            "results": [dict(r) for r in rows],
            "total": total,
            "page": page,
            "limit": limit,
        }

    def get_result_by_id(self, hunt_id: str) -> Optional[dict]:
        conn = _get_conn()
        row = conn.execute("SELECT * FROM hunt_results WHERE id = ?", (hunt_id,)).fetchone()
        conn.close()
        return dict(row) if row else None

    def update_result(self, hunt_id: str, status: str, analyst_notes: str = "", verified_by: str = "") -> bool:
        valid = {"OPEN", "VERIFIED", "FALSE_POSITIVE", "ESCALATED", "CLOSED"}
        if status.upper() not in valid:
            return False
        conn = _get_conn()
        now = int(time.time())
        conn.execute(
            "UPDATE hunt_results SET status=?, analyst_notes=?, verified_at=?, verified_by=? WHERE id=?",
            (status.upper(), analyst_notes, now, verified_by, hunt_id),
        )
        conn.commit()
        conn.close()
        return True

    def get_stats(self) -> dict:
        conn = _get_conn()
        total = conn.execute("SELECT COUNT(*) FROM hunt_results").fetchone()[0]
        by_severity = dict(conn.execute(
            "SELECT severity, COUNT(*) as cnt FROM hunt_results GROUP BY severity ORDER BY cnt DESC"
        ).fetchall())
        by_status = dict(conn.execute(
            "SELECT status, COUNT(*) as cnt FROM hunt_results GROUP BY status ORDER BY cnt DESC"
        ).fetchall())
        by_technique = [dict(r) for r in conn.execute(
            "SELECT mitre_technique_id, COUNT(*) as cnt FROM hunt_results WHERE mitre_technique_id != '' GROUP BY mitre_technique_id ORDER BY cnt DESC LIMIT 10"
        ).fetchall()]
        conn.close()
        return {
            "total_findings": total,
            "by_severity": by_severity,
            "by_status": by_status,
            "top_techniques": by_technique,
            "last_hunt_time": self._stats["last_hunt_time"],
        }

    def export_results(self, severity: Optional[str] = None, format: str = "json") -> str:
        conn = _get_conn()
        if severity:
            rows = conn.execute("SELECT * FROM hunt_results WHERE severity = ? ORDER BY created_at DESC", (severity.upper(),)).fetchall()
        else:
            rows = conn.execute("SELECT * FROM hunt_results ORDER BY created_at DESC").fetchall()
        conn.close()
        data = [dict(r) for r in rows]
        if format == "json":
            return json.dumps(data, indent=2)
        lines = ["id,rule_id,severity,status,mitre_technique,user_id,risk_score,created_at"]
        for r in data:
            lines.append(f"{r['id']},{r['rule_id']},{r['severity']},{r['status']},{r['mitre_technique_id']},{r['user_id']},{r['risk_score']},{r['created_at']}")
        return "\n".join(lines)


_hunter = ThreatHunter()


def get_hunter() -> ThreatHunter:
    return _hunter


def init_hunter():
    init_hunt_db()
