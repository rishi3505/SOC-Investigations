"""
Evidence Collector — Collects requested forensic evidence on-demand and
uploads it to CMS. Supports processes, network connections, event logs,
behavior snapshots, and threat hunting results.
"""
import json
import os
import subprocess
import sys
import tempfile
import time
import zipfile
from typing import Optional

import psutil
import requests

from .logging_setup import get_logger

logger = get_logger("forensics")


class EvidenceCollector:
    def __init__(self, cms_url: str, device_id: str):
        self._cms_url = cms_url.rstrip("/")
        self._device_id = device_id

    def collect_processes(self) -> list[dict]:
        processes = []
        for proc in psutil.process_iter(["pid", "name", "cmdline", "cpu_percent", "memory_percent", "create_time", "username"]):
            try:
                pinfo = proc.info
                processes.append({
                    "pid": pinfo["pid"],
                    "name": pinfo["name"],
                    "cmdline": " ".join(pinfo["cmdline"] or [])[:500],
                    "cpu_percent": pinfo["cpu_percent"],
                    "memory_percent": round(pinfo["memory_percent"] or 0, 2),
                    "created": pinfo["create_time"],
                    "user": pinfo["username"],
                })
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass
        return sorted(processes, key=lambda p: p["memory_percent"], reverse=True)[:200]

    def collect_network_connections(self) -> list[dict]:
        connections = []
        for conn in psutil.net_connections():
            try:
                connections.append({
                    "fd": conn.fd,
                    "family": str(conn.family),
                    "type": str(conn.type),
                    "laddr": f"{conn.laddr.ip}:{conn.laddr.port}" if conn.laddr else "",
                    "raddr": f"{conn.raddr.ip}:{conn.raddr.port}" if conn.raddr else "",
                    "status": conn.status,
                    "pid": conn.pid,
                })
            except Exception:
                pass
        return connections

    def collect_event_logs(self, log_name: str = "Security", max_events: int = 100) -> list[dict]:
        events = []
        try:
            import win32evtlog
            hand = win32evtlog.OpenEventLog(None, log_name)
            flags = win32evtlog.EVENTLOG_BACKWARDS_READ | win32evtlog.EVENTLOG_SEQUENTIAL_READ
            total = win32evtlog.GetNumberOfEventLogRecords(hand)
            for _ in range(min(max_events, total)):
                batch = win32evtlog.ReadEventLog(hand, flags, 0)
                if not batch:
                    break
                for evt in batch:
                    events.append({
                        "event_id": evt.EventID,
                        "source": evt.SourceName,
                        "time": evt.TimeGenerated.Format(),
                        "category": evt.EventCategory,
                        "type": evt.EventType,
                    })
            win32evtlog.CloseEventLog(hand)
        except Exception:
            try:
                output = subprocess.check_output(
                    ["wevtutil", "qe", log_name, f"/c:{max_events}", "/f:json", "/rd:true"],
                    timeout=15, stderr=subprocess.PIPE,
                ).decode("utf-8", errors="replace")
                events = json.loads(output) if output.strip().startswith("[") else []
            except Exception:
                pass
        return events[:max_events]

    def collect_behavior_snapshot(self) -> dict:
        snapshot = {}
        try:
            from .keyboard import KeyboardTracker
            kt = KeyboardTracker()
            snapshot["keyboard"] = {
                "typing_speed": kt.get_typing_speed() if hasattr(kt, "get_typing_speed") else 0,
            }
        except Exception:
            pass
        try:
            from .mouse_tracker import MouseTracker
            mt = MouseTracker()
            snapshot["mouse"] = {"speed": mt.get_mouse_speed() if hasattr(mt, "get_mouse_speed") else 0}
        except Exception:
            pass
        try:
            from .system_monitor import SystemMonitor
            sm = SystemMonitor()
            snapshot["system"] = {"active_app": sm.get_active_app() if hasattr(sm, "get_active_app") else ""}
        except Exception:
            pass
        return snapshot

    def collect_threat_hunt_results(self) -> list[dict]:
        results = []
        try:
            sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
            from rules.rule_engine import load_rules, evaluate_rule
            from threat_intelligence.ioc_matcher import match_payload
            rules = load_rules()
            behavior_payload = self.collect_behavior_snapshot()
            ioc_matches = match_payload(behavior_payload)
            for rule in rules:
                r = evaluate_rule(rule, behavior_payload, ioc_matches)
                if r:
                    results.append(r)
        except Exception as e:
            logger.error("Threat hunt collection failed: %s", e)
        return results

    def collect_all(self) -> dict:
        return {
            "processes": self.collect_processes(),
            "network_connections": self.collect_network_connections(),
            "event_logs": self.collect_event_logs(),
            "behavior_snapshot": self.collect_behavior_snapshot(),
            "threat_hunt_results": self.collect_threat_hunt_results(),
            "collected_at": int(time.time()),
        }

    def upload_evidence(self, evidence_type: str = "on_demand", data: Optional[dict] = None) -> dict:
        if data is None:
            data = self.collect_all()
        evidence_id = f"EVIDENCE-{int(time.time())}"
        package = {
            "evidence_id": evidence_id,
            "endpoint_id": self._device_id,
            "evidence_type": evidence_type,
            "collected_at": int(time.time()),
            "data": data,
        }
        try:
            resp = requests.post(
                f"{self._cms_url}/api/v1/forensics/upload",
                json=package,
                timeout=60,
            )
            if resp.status_code == 200:
                logger.info("Evidence %s uploaded successfully", evidence_id)
                return {"status": "uploaded", "evidence_id": evidence_id}
            else:
                logger.warning("Evidence upload HTTP %d", resp.status_code)
                return {"status": "error", "detail": f"HTTP {resp.status_code}"}
        except Exception as e:
            logger.error("Evidence upload failed: %s", e)
            return {"status": "error", "detail": str(e)}
