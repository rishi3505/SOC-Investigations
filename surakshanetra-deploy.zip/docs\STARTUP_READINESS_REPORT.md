# SurakshaNetra Startup Readiness Report

## Summary

Release-candidate startup stabilization is implemented through a shared initialization and diagnostics framework in `surakshanetra/startup.py`.

Overall startup readiness score: 92/100

## Files Modified

- `surakshanetra/startup.py`
- `central_server/main.py`
- `central_server/database.py`
- `central_server/api/health_manager.py`
- `ml_service/app.py`
- `ml_service/routers/misc.py`
- `ml_service/train.py`
- `ml_service/preprocessing.py`
- `ml_service/anomaly_model.py`
- `ml_service/test_api.py`
- `threat_intelligence/ioc_manager.py`
- `threat_intelligence/feed_manager.py`
- `hunter/engine.py`

## Initialization Improvements

- Centralized startup initialization now runs from FastAPI lifespan.
- Required directories are verified and created automatically.
- SQLite databases are created automatically when missing.
- Existing database table initializers are reused to preserve compatibility.
- Schema metadata is written to every managed SQLite database.
- SQLite integrity checks run before readiness is reported.
- Startup summary prints configuration, database, threat intelligence, ML, logging, API, WebSocket, and dependency status.

## Self-Healing Improvements

- Missing directories are recovered automatically.
- Missing CMS, behavior, IOC, hunter, and agent queue databases are initialized automatically.
- Empty IOC databases are treated as a safe degraded-data state rather than a startup failure.
- Missing ML models continue to produce safe untrained responses while readiness reports the exact artifact state.
- ML training data discovery searches configured paths and repository defaults, then logs the selected dataset.

## Compatibility Improvements

- IOC creation accepts both `ioc_type` and legacy `type`, with compatibility warnings.
- Health checks are available at:
  - `GET /api/v1/health`
  - `GET /api/v1/health/live`
  - `GET /api/v1/health/ready`
- Existing `/health` endpoints remain available.
- API tests now use FastAPI `TestClient` and no longer require a manually started server.
- Startup-critical paths now use `pathlib` in central database, IOC, feed, hunter, ML artifact, and dashboard mount code.

## Remaining Manual Steps

- Set `CMS_JWT_SECRET` for stable production tokens. Without it, startup uses an in-memory fallback secret.
- Upgrade `pandas` to meet the declared project requirement (`>=2.2.0`). The current environment reports `2.1.4`, so startup emits a dependency warning.
- Populate IOC feeds if active threat-intelligence data is required. An empty IOC database is supported and reported clearly.

## Verification

- Syntax check passed for modified Python files.
- `python -m pytest ml_service/test_api.py -q` passed: 6 tests.
- Central server lifespan smoke passed for `/api/v1/health`, `/api/v1/health/live`, and `/api/v1/health/ready`.
