"""
Forensic Evidence Collection Package.

Provides automated evidence collection, packaging, and chain-of-custody
tracking for security incidents. Designed for Windows environments with
cross-platform fallbacks for development and testing.
"""

from .collector import ForensicCollector
from .evidence_packer import EvidencePacker
from .chain_of_custody import ChainOfCustody
from .timeline import ForensicTimeline

__all__ = [
    "ForensicCollector",
    "EvidencePacker",
    "ChainOfCustody",
    "ForensicTimeline",
]
