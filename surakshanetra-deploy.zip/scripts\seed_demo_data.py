"""
SurakshaNetra v1.0.0 — Demo Dataset Generator

Seeds the database with realistic demo data for presentations and portfolio demonstrations.

Usage:
    python scripts/seed_demo_data.py

Requires:
    - SQLite databases initialized (run init_db() first)
    - 30-60 seconds to generate complete demo dataset
"""
import os
import sys
import time
import random
import sqlite3
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE_DIR))

from backend.db import init_db

random.seed(42)

USER_IDS = ["alice@company.com", "bob@company.com", "charlie@company.com"]
LOCATIONS = [
    ("New York", "USA"), ("London", "UK"), ("Tokyo", "Japan"),
    ("Sydney", "Australia"), ("Berlin", "Germany"), ("Bangalore", "India"),
]
DEVICES = ["DESKTOP-A1B2C3", "LAPTOP-D4E5F6", "WORKSTATION-G7H8I9"]
APPS = ["chrome.exe", "outlook.exe", "visualstudio.exe", "slack.exe", "terminal.exe", "word.exe", "explorer.exe"]

def seed_behavior_data():
    """Generate 2000 normal + 50 anomalous behavior records."""
    conn = sqlite3.connect(str(BASE_DIR / "data" / "behavior.db"))
    c = conn.cursor()

    for user_id in USER_IDS:
        for i in range(700):
            ts = int(time.time()) - (3600 * 24 * 7) + (i * 300)
            is_anomaly = (i > 650)
            base_speed = 45 if user_id == "alice@company.com" else (55 if user_id == "bob@company.com" else 40)
            c.execute("""
                INSERT INTO behavior_data (typing_speed, key_latency, avg_hold_time, latency_jitter,
                    mouse_speed, mouse_acceleration, direction_change_freq, click_frequency,
                    active_app, app_switch_count, idle_time, time_of_day, session_duration,
                    user_id, ip_address, city, country, is_new_location, timestamp)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                base_speed + random.gauss(0, 8) + (30 if is_anomaly else 0),
                120 + random.gauss(0, 20) + (80 if is_anomaly else 0),
                80 + random.gauss(0, 10),
                15 + random.gauss(0, 5) + (20 if is_anomaly else 0),
                200 + random.gauss(0, 40),
                0.5 + random.gauss(0, 0.1),
                3 + random.gauss(0, 1),
                0.2 + random.gauss(0, 0.05),
                random.choice(APPS),
                random.randint(0, 5),
                random.uniform(0, 30),
                random.randint(8, 18),
                random.uniform(120, 480),
                user_id,
                "192.168.1." + str(random.randint(1, 254)),
                LOCATIONS[i % len(LOCATIONS)][0],
                LOCATIONS[i % len(LOCATIONS)][1],
                1 if i < 5 else 0,
                ts,
            ))
        print(f"  Seeded behavior data for {user_id}")

    conn.commit()
    conn.close()
    print("  Behavior data seeded: 2100 records")

def seed_incidents():
    """Generate demo incidents across various severities."""
    conn = sqlite3.connect(str(BASE_DIR / "data" / "behavior.db"))
    c = conn.cursor()
    incidents = [
        ("INC-DEMO-001", "alice@company.com", "Anomalous typing pattern detected from unknown location",
         78.5, 0.85, "HIGH", "OPEN", "T1078", "Valid Accounts", "TA0005"),
        ("INC-DEMO-002", "bob@company.com", "Device fingerprint mismatch — hardware change detected",
         65.2, 0.72, "MEDIUM", "INVESTIGATING", "T1098", "Account Manipulation", "TA0003"),
        ("INC-DEMO-003", "charlie@company.com", "Login from new geographic location (Tokyo)",
         55.0, 0.68, "MEDIUM", "OPEN", "T1078", "Valid Accounts", "TA0001"),
        ("INC-DEMO-004", "alice@company.com", "Multiple failed MFA attempts followed by anomalous session",
         92.1, 0.95, "CRITICAL", "CONTAINED", "T1110", "Brute Force", "TA0006"),
        ("INC-DEMO-005", "bob@company.com", "Rapid application switching + abnormal mouse pattern",
         60.3, 0.70, "MEDIUM", "CLOSED", "T1059", "Command and Scripting", "TA0002"),
    ]
    for inc in incidents:
        c.execute("""
            INSERT OR REPLACE INTO incidents
                (incident_id, user_id, reason_json, risk_score, confidence, severity,
                 status, mitre_technique, mitre_technique_name, mitre_tactic, timestamp)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (inc[0], inc[1], inc[2], inc[3], inc[4], inc[5],
              inc[6], inc[7], inc[8], inc[9], int(time.time()) - random.randint(3600, 86400)))
    conn.commit()
    conn.close()
    print(f"  Incidents seeded: {len(incidents)} records")

def main():
    print("=" * 50)
    print("SurakshaNetra Demo Data Generator")
    print("=" * 50)

    print("\n[0/3] Initializing database...")
    init_db()
    print("  Database ready.")

    print("\n[1/3] Seeding behavior data...")
    seed_behavior_data()

    print("\n[2/3] Seeding incidents...")
    seed_incidents()

    print("\n[3/3] Complete!")
    print("\nDemo dataset ready for:")
    print("  - SOC Dashboard exploration")
    print("  - ML model training: python ml_service/train.py")
    print("  - ML service: python -m uvicorn ml_service.app:app")
    print("  - CMS: python central_server/main.py")
    print("  - API testing: http://127.0.0.1:9000/api/v1/analytics/overview")

if __name__ == "__main__":
    main()
