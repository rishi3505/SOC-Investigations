# SurakshaNetra — Attack Surface Analysis

## Version 1.0 — RC1

---

## 1. REST API Endpoints

| Endpoint | Method | Auth | Attack Vector | Likelihood | Impact | Mitigation |
|----------|--------|------|---------------|------------|--------|------------|
| `/api/v1/auth/login` | POST | None | Credential brute-force | MEDIUM | HIGH | SHA-256 hashing (to be bcrypt); no lockout |
| `/api/v1/analyze` | POST | Required | Data injection, payload bomb | LOW | LOW | Schema validated before processing |
| `/api/v1/endpoints/*` | GET/POST | Required | IDOR (endpoint_id enumeration) | LOW | MEDIUM | Auth scoped to user role |
| `/api/v1/commands/*` | GET/POST | Required | Unauthorized command dispatch | LOW | HIGH | HMAC signing, agent-poll model |
| `/api/v1/evidence/*` | GET | Required | Path traversal, data exfiltration | LOW | HIGH | Canonical path check against evidence base dir |
| `/api/v1/config/*` | GET/PUT | Required | Config tampering | LOW | HIGH | Auth + validation |
| `/api/v1/admin/*` | GET/POST | Required | Privilege escalation | LOW | HIGH | Role-based access |
| `/api/v1/policies/*` | GET/PUT/DELETE | Required | Policy manipulation | LOW | HIGH | Auth + validation |
| `/api/v1/threat-intel/*` | GET/POST | Required | IOC injection, feed manipulation | LOW | MEDIUM | Auth + feed validation |

### Unauthenticated Endpoints
| Endpoint | Justification | Risk |
|----------|---------------|------|
| `/health` (GET) | Health check for load balancers | LOW — no data returned |

## 2. Agent Attack Surface

| Attack Vector | Description | Likelihood | Impact | Mitigation |
|---------------|-------------|------------|--------|------------|
| Config file tampering | Modify `config.json` | MEDIUM | MEDIUM | Deep merge defaults; JSON schema validation |
| Queue DB corruption | Corrupt `_queue.json` or `buffer.json` | LOW | LOW | Graceful error handling; reconnect on corruption |
| Behavioral data injection | Crafted keystroke/mouse data | LOW | LOW | JSON parsing; no eval/exec |
| wevtutil command injection | Malicious log name | VERY LOW | HIGH | Fixed: shell=False + list form |
| Listener resource exhaustion | High-frequency events | LOW | LOW | Configurable rate limits |
| Binary tampering | Modify agent.exe | MEDIUM | CRITICAL | File integrity monitoring (future: code signing) |
| MITM on agent-CMS channel | Intercept HTTPS | VERY LOW | CRITICAL | TLS 1.2+; system CA trust store |

## 3. Database Attack Surface

| Attack Vector | Description | Likelihood | Impact | Mitigation |
|---------------|-------------|------------|--------|------------|
| Unauthorized file read | Access .db files directly | LOW | HIGH | SQLite WAL mode; file permissions |
| SQL injection (insert_behavior) | Via `data.keys()` | LOW | MEDIUM | Only called from trusted code path |
| Weak password hash cracking | SHA-256 without salt | MEDIUM | MEDIUM | Salted SHA-256 (to be bcrypt) |
| Evidence data leak | Forensic packages on disk | LOW | HIGH | Evidence base dir restricted; path validation on access |

## 4. Dashboard Attack Surface

| Attack Vector | Description | Likelihood | Impact | Mitigation |
|---------------|-------------|------------|--------|------------|
| XSS via API response | Malicious data in tables | LOW | MEDIUM | React auto-escapes; no innerHTML |
| JWT theft via XSS | Access localStorage | LOW | HIGH | JWT in header, not localStorage |
| API key in bundle | Exposed in source maps | LOW | HIGH | API keys only server-side |
| CSP bypass | Inline script injection | LOW | MEDIUM | CSP policy needs explicit configuration |
| Dependency supply chain | Malicious npm package | LOW | HIGH | Package.json pinned; audit regular |

## 5. File System Attack Surface

| Attack Vector | Description | Likelihood | Impact | Mitigation |
|---------------|-------------|------------|--------|------------|
| Log path injection | Write logs to arbitrary locations | LOW | MEDIUM | Fixed: restricted to agent subdirectory |
| Evidence directory traversal | Upload/read outside evidence base | LOW | HIGH | Fixed: canonical path validation |
| Model file tampering | Replace .pkl files | LOW | HIGH | Read-only at runtime; git-tracked |

## 6. Network Attack Surface

| Attack Vector | Description | Likelihood | Impact | Mitigation |
|---------------|-------------|------------|--------|------------|
| CORS bypass | Cross-origin requests to CMS | LOW | MEDIUM | Fixed: explicit origin list from env var |
| SSRF via threat intel feeds | Feed URLs controlled by config | LOW | MEDIUM | Pre-configured feed list; no user feed URLs |
| Port scanning CMS | Open port 9000 | MEDIUM | LOW | UFW/firewall at deployment level |

## 7. Deployment Attack Surface

| Attack Vector | Description | Likelihood | Impact | Mitigation |
|---------------|-------------|------------|--------|------------|
| Default credentials | Weak JWT/command key | LOW | CRITICAL | Fixed: auto-generated 64-char hex keys |
| Unpinned dependencies | Supply chain via pip | MEDIUM | HIGH | Fixed: requirements.txt pinned with ~= |
| No containerization | Host-level compromise | MEDIUM | CRITICAL | Future: Dockerfile + docker-compose |
| Plaintext secrets in env | .env file exposure | MEDIUM | HIGH | Documented: use env vars, not .env in prod |
