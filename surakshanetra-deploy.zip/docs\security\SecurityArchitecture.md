# SurakshaNetra — Security Architecture

## Version 1.0 — RC1

---

## 1. Authentication

### 1.1 JWT Authentication (Primary)
- **Algorithm**: HMAC-SHA256 (HS256)
- **Key Source**: `CMS_JWT_SECRET` env var or `secrets.token_hex(32)` (auto-generated)
- **Expiry**: 24 hours from issuance
- **Storage**: Bearer token in `Authorization` header (not localStorage)
- **Verification**: `central_server/auth.py:jwt.decode()` with expiry check
- **Dependency**: `authenticate_request` FastAPI dependency on all protected routes

### 1.2 API Key Authentication (Secondary)
- **Format**: `uuid.uuid4().hex + timestamp` (64-char hex string)
- **Storage**: Plaintext in `central.db` → `users.api_key` column
- **Usage**: Machine-to-machine (agent ↔ CMS)
- **Verification**: `authenticate_request` checks X-API-Key header as fallback

### 1.3 Authentication Flow
```
Request -> Authorization: Bearer <JWT>?
    |-> Yes -> Verify JWT -> Extract user/roles -> Route
    |-> No  -> X-API-Key header?
              |-> Yes -> Lookup API key -> Authenticate -> Route
              |-> No  -> 401 Unauthorized

Login: POST /api/v1/auth/login
    -> Verify password (SHA-256 hash) -> Issue JWT
```

## 2. Authorization

- **Role Model**: User `role` field in JWT payload (`admin`, `analyst`, `viewer`)
- **Enforcement**: Route-level via `authenticate_request` returns `user: dict` (role checked inline)
- **Scope**: No granular RBAC beyond role; admin has full access, analyst limited to read/ack

## 3. Encryption

### 3.1 Transport Security
- **Protocol**: HTTPS/TLS 1.2+ (system CA trust store)
- **Cipher**: Server-configured (no app-level cipher pinning)
- **Dashboard ↔ CMS**: Via Vite proxy in dev; nginx reverse proxy expected in production

### 3.2 Data at Rest
- **Databases**: SQLite WAL mode — no encryption at rest (plaintext files)
- **Evidence Files**: Plaintext ZIP archives on `evidence/` directory
- **Config Files**: Plaintext JSON (agent `config.json`)
- **Recommendation**: Full-disk encryption (BitLocker/LUKS) for production deployments

## 4. Input Validation

| Component | Approach | Notes |
|-----------|----------|-------|
| CMS API | `pydantic.BaseModel` (in progress) | Some endpoints still use `payload: dict` |
| Agent | JSON parsing + `_deep_merge()` | Config merged against defaults with strict keys |
| ML Service | `pydantic` validated requests | All inference endpoints typed |
| Dashboard | React JSX auto-escaping | No `innerHTML` or `dangerouslySetInnerHTML` |
| Forensics | Regex sanitization | `incident_id` cleaned of path traversal chars |
| Threat Intel | `json.loads()` on feed data | No eval; feed URL from config only |

## 5. Audit Logging

- **Storage**: `central.db` → `audit_logs` + `audit_logs_extended` tables
- **Captured Fields**: `actor_id`, `action`, `target_type`, `target_id`, `details`, `ip_address`, `timestamp`
- **Coverage**: All admin operations (endpoint lifecycle, config changes, commands, policies, updates, groups, inventory)
- **Searchability**: GET `/api/v1/audit/logs` with pagination, filters
- **Integrity**: Append-only in application layer (no DB triggers enforcing immutability)

## 6. Secrets Management

| Secret | Location | Generation | Rotation |
|--------|----------|------------|----------|
| JWT Key | `CMS_JWT_SECRET` env var | `secrets.token_hex(32)` | Manual env var change |
| Command Key | `COMMAND_SIGNING_KEY` env var | `secrets.token_hex(32)` | Manual env var change |
| API Keys | `users.api_key` in DB | `uuid.uuid4().hex` | Via admin API |
| Passwords | `users.password_hash` in DB | SHA-256(user-provided) | Via login reset |

## 7. Error Handling

- **Global Exception Handler**: `central_server/main.py:107-109` catches all unhandled exceptions
- **Client Response**: JSON `{"detail": "Internal server error"}` — no stack traces exposed
- **Server Logging**: Full traceback written to server logs with `logging.exception()`
- **HTTP Status Codes**: Standard REST (200, 201, 400, 401, 403, 404, 422, 500)

## 8. CORS Policy

- **Default Origins**: `http://localhost:5173`, `http://localhost:3000`, `http://127.0.0.1:5173`
- **Configuration**: `CORS_ORIGINS` env var (comma-separated)
- **Credentials**: `allow_credentials=True` (only when explicit origins set)
- **Wildcard**: Wildcard `*` explicitly rejected (incompatible with credentials)

## 9. Security Headers (Dashboard)

| Header | Value | Status |
|--------|-------|--------|
| `Content-Security-Policy` | `default-src 'self'` | Not configured (recommended) |
| `X-Content-Type-Options` | `nosniff` | Not configured (recommended) |
| `X-Frame-Options` | `DENY` | Not configured (recommended) |
| `Strict-Transport-Security` | `max-age=31536000` | Not configured (recommended) |

## 10. Dependency Management

- **Python**: `requirements.txt` with `~=` pins — grouped by role (core/agent/dashboard/dev)
- **Node.js**: `package.json` with caret ranges — lockfile (`package-lock.json`) for deterministic builds
- **Supply Chain**: Monthly `pip audit` / `npm audit` recommended
