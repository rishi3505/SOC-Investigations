"""
Inventory Collector — Collects hardware, software, OS, and security product
inventory from the Windows endpoint and reports to CMS. Tracks changes over time.
"""
import json
import platform
import subprocess
import sys
import threading
import time
from typing import Optional

import requests
import psutil

from .logging_setup import get_logger
from .version import get_version_info

logger = get_logger("communication")


class InventoryCollector:
    def __init__(self, cms_url: str, device_id: str, collect_interval: float = 86400.0):
        self._cms_url = cms_url.rstrip("/")
        self._device_id = device_id
        self._collect_interval = collect_interval
        self._thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()

    def start(self):
        if self._thread and self._thread.is_alive():
            return
        self._stop_event.clear()
        self._thread = threading.Thread(target=self._run, name="inventory", daemon=True)
        self._thread.start()
        logger.info("Inventory collector started (interval=%ds)", self._collect_interval)

    def stop(self):
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=5)
        logger.info("Inventory collector stopped")

    def collect_and_report(self) -> dict:
        try:
            inventory = self._collect()
            resp = requests.post(
                f"{self._cms_url}/api/v1/inventory/report/{self._device_id}",
                json=inventory,
                timeout=30,
            )
            if resp.status_code == 200:
                result = resp.json()
                logger.info("Inventory reported (hash=%s, changes=%d)", result.get("hash"), result.get("changes", 0))
                return result
            else:
                logger.warning("Inventory report HTTP %d", resp.status_code)
                return {"status": "error", "detail": f"HTTP {resp.status_code}"}
        except Exception as e:
            logger.error("Inventory collection failed: %s", e)
            return {"status": "error", "detail": str(e)}

    def _collect(self) -> dict:
        version_info = get_version_info()
        uname = platform.uname()

        cpu_info = self._get_cpu_info()
        memory = psutil.virtual_memory()
        disks = psutil.disk_partitions()
        total_disk = sum(psutil.disk_usage(d.mountpoint).total for d in disks) / (1024**3)
        free_disk = sum(psutil.disk_usage(d.mountpoint).free for d in disks) / (1024**3)

        inventory = {
            "hostname": platform.node(),
            "os": "Windows",
            "os_version": uname.version,
            "os_build": uname.release,
            "architecture": uname.machine,
            "cpu_brand": cpu_info.get("brand", platform.processor()),
            "cpu_cores": psutil.cpu_count(logical=False) or 0,
            "cpu_threads": psutil.cpu_count(logical=True) or 0,
            "total_ram_mb": round(memory.total / (1024 * 1024)),
            "disk_count": len(disks),
            "total_disk_gb": round(total_disk, 1),
            "free_disk_gb": round(free_disk, 1),
            "gpu_info": self._get_gpu_info(),
            "network_interfaces": self._get_network_info(),
            "installed_software": self._get_installed_software(),
            "security_software": self._get_security_software(),
            "python_version": sys.version.split()[0],
            "agent_version": version_info.get("agent_version", ""),
            "agent_build": version_info.get("build_number", 0),
            "device_fingerprint": self._get_fingerprint(),
            "windows_edition": self._get_windows_edition(),
            "windows_install_date": self._get_windows_install_date(),
            "last_boot": str(time.time() - (time.time() - psutil.boot_time())),
        }
        return inventory

    def _get_cpu_info(self) -> dict:
        try:
            output = subprocess.check_output(
                "wmic cpu get name,numberofcores,numberoflogicalprocessors /format:csv",
                shell=True, timeout=5, stderr=subprocess.PIPE,
            ).decode("utf-8", errors="replace")
            lines = [l.strip() for l in output.splitlines() if l.strip() and "," in l]
            if lines:
                parts = lines[-1].split(",")
                return {"brand": parts[1] if len(parts) > 1 else "", "cores": parts[2] if len(parts) > 2 else "", "threads": parts[3] if len(parts) > 3 else ""}
        except Exception:
            pass
        return {}

    def _get_gpu_info(self) -> list:
        gpus = []
        try:
            output = subprocess.check_output(
                "wmic path win32_VideoController get name,adapterram /format:csv",
                shell=True, timeout=5, stderr=subprocess.PIPE,
            ).decode("utf-8", errors="replace")
            for line in output.splitlines():
                if not line.strip() or "Name" in line:
                    continue
                parts = line.split(",")
                if len(parts) >= 2 and parts[1].strip():
                    gpus.append({"name": parts[1].strip(), "memory": parts[2].strip() if len(parts) > 2 else ""})
        except Exception:
            pass
        return gpus

    def _get_network_info(self) -> list:
        interfaces = []
        for name, addrs in psutil.net_if_addrs().items():
            for addr in addrs:
                if addr.family.name == "AF_INET":
                    interfaces.append({"name": name, "ip": addr.address, "netmask": addr.netmask})
        return interfaces

    def _get_installed_software(self) -> list:
        software = []
        try:
            output = subprocess.check_output(
                'reg query HKLM\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall /s /f "DisplayName" /t REG_SZ 2>nul',
                shell=True, timeout=10, stderr=subprocess.PIPE,
            ).decode("utf-8", errors="replace")
            for line in output.splitlines():
                line = line.strip()
                if line.startswith("DisplayName"):
                    parts = line.split("REG_SZ", 1)
                    if len(parts) > 1:
                        name = parts[1].strip()
                        if name and len(name) < 200:
                            software.append(name)
        except Exception:
            pass
        return list(set(software))[:500]

    def _get_security_software(self) -> list:
        security = []
        try:
            output = subprocess.check_output(
                'wmic /namespace:\\\\root\\SecurityCenter2 path AntiVirusProduct get displayName /format:csv',
                shell=True, timeout=5, stderr=subprocess.PIPE,
            ).decode("utf-8", errors="replace")
            for line in output.splitlines():
                if line.strip() and "displayName" not in line and "," in line:
                    name = line.split(",")[-1].strip()
                    if name:
                        security.append({"type": "antivirus", "name": name})
        except Exception:
            pass
        try:
            output = subprocess.check_output(
                'wmic /namespace:\\\\root\\SecurityCenter2 path FirewallProduct get displayName /format:csv',
                shell=True, timeout=5, stderr=subprocess.PIPE,
            ).decode("utf-8", errors="replace")
            for line in output.splitlines():
                if line.strip() and "displayName" not in line and "," in line:
                    name = line.split(",")[-1].strip()
                    if name:
                        security.append({"type": "firewall", "name": name})
        except Exception:
            pass
        return security

    def _get_fingerprint(self) -> dict:
        try:
            from .device_fingerprint import DeviceFingerprinter
            fp = DeviceFingerprinter()
            return fp.collect() or {}
        except Exception:
            return {}

    def _get_windows_edition(self) -> str:
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows NT\CurrentVersion") as key:
                return winreg.QueryValueEx(key, "ProductName")[0]
        except Exception:
            return ""

    def _get_windows_install_date(self) -> str:
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows NT\CurrentVersion") as key:
                install_date = winreg.QueryValueEx(key, "InstallDate")[0]
                return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(int(install_date)))
        except Exception:
            return ""

    def _run(self):
        self.collect_and_report()
        while not self._stop_event.wait(self._collect_interval):
            self.collect_and_report()
