"""
Threat Hunting Package — Automated threat hunting engine that runs detection rules
against stored behavior data and IOC matches, producing hunt results with MITRE ATT&CK enrichment.
"""
