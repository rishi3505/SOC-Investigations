"""
Audit Manager — Admin action audit logging and querying.
"""
import json
import time
from fastapi import APIRouter, Depends, HTTPException, Query
from ..database import get_connection
from ..auth import authenticate_request

router = APIRouter(prefix="/api/v1/audit", tags=["Audit Manager"])


@router.get("/logs")
async def list_audit_logs(
    category: str = None,
    action: str = None,
    target_type: str = None,
    target_id: str = None,
    actor: str = None,
    page: int = Query(1, ge=1),
    limit: int = Query(50, ge=1, le=500),
    user: dict = Depends(authenticate_request),
):
    conn = get_connection()
    conditions = []
    params = []
    if category:
        conditions.append("category = ?"); params.append(category)
    if action:
        conditions.append("action LIKE ?"); params.append(f"%{action}%")
    if target_type:
        conditions.append("target_type = ?"); params.append(target_type)
    if target_id:
        conditions.append("target_id LIKE ?"); params.append(f"%{target_id}%")
    if actor:
        conditions.append("actor LIKE ?"); params.append(f"%{actor}%")
    where = "WHERE " + " AND ".join(conditions) if conditions else ""
    offset = (page - 1) * limit
    total = conn.execute(f"SELECT COUNT(*) FROM audit_logs_extended {where}", params).fetchone()[0]
    rows = conn.execute(
        f"SELECT * FROM audit_logs_extended {where} ORDER BY timestamp DESC LIMIT ? OFFSET ?",
        (*params, limit, offset)
    ).fetchall()
    conn.close()
    return {"logs": [dict(r) for r in rows], "total": total, "page": page, "limit": limit}


@router.get("/summary")
async def audit_summary(days: int = Query(7, ge=1, le=90), user: dict = Depends(authenticate_request)):
    conn = get_connection()
    since = int(time.time()) - (days * 86400)
    by_category = dict(conn.execute(
        "SELECT category, COUNT(*) as cnt FROM audit_logs_extended WHERE timestamp > ? GROUP BY category ORDER BY cnt DESC",
        (since,)
    ).fetchall())
    by_action = dict(conn.execute(
        "SELECT action, COUNT(*) as cnt FROM audit_logs_extended WHERE timestamp > ? GROUP BY action ORDER BY cnt DESC LIMIT 20",
        (since,)
    ).fetchall())
    by_actor = dict(conn.execute(
        "SELECT actor, COUNT(*) as cnt FROM audit_logs_extended WHERE timestamp > ? GROUP BY actor ORDER BY cnt DESC LIMIT 10",
        (since,)
    ).fetchall())
    total = conn.execute("SELECT COUNT(*) FROM audit_logs_extended WHERE timestamp > ?", (since,)).fetchone()[0]
    conn.close()
    return {
        "total_logs": total,
        "period_days": days,
        "by_category": by_category,
        "by_action": by_action,
        "by_actor": by_actor,
    }
