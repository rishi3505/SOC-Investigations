"""
Remote Command Router — Issue, track, acknowledge, and manage remote commands.
Provides agent-facing endpoints for command polling and acknowledgment,
and admin-facing endpoints for command management.
"""
import json
import time
from fastapi import APIRouter, Depends, HTTPException, Query
from ..database import get_connection
from ..auth import authenticate_request
from remote_commands.command_engine import get_command_engine, CommandEngine
from remote_commands.command_types import COMMAND_REGISTRY, list_command_types
from ..models import IssueCommandRequest, AgentPollRequest, AgentAckRequest, AgentCompleteRequest

router = APIRouter(prefix="/api/v1/commands", tags=["Remote Commands"])


def _get_engine() -> CommandEngine:
    return get_command_engine(get_connection)


def _write_audit(conn, action, category, target_type, target_id, actor, details):
    now = int(time.time())
    try:
        conn.execute(
            "INSERT INTO audit_logs_extended (action, category, target_type, target_id, actor, details, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (action, category, target_type, target_id, actor, json.dumps(details), now),
        )
    except Exception:
        pass


@router.get("/types")
async def list_available_commands(category: str = None, user: dict = Depends(authenticate_request)):
    return {"command_types": list_command_types(category)}


@router.post("/issue")
async def issue_command(payload: IssueCommandRequest, user: dict = Depends(authenticate_request)):
    engine = _get_engine()
    result = engine.issue(
        command_type=payload.command_type,
        target_type=payload.target_type,
        target_ids=payload.target_ids,
        payload=payload.payload,
        priority=payload.priority,
        issued_by=user.get("username", "admin"),
        expires_in_seconds=payload.expires_in_seconds,
    )
    if result.get("status") == "error":
        raise HTTPException(status_code=400, detail=result["detail"])
    conn = get_connection()
    _write_audit(conn, f"command.{payload.command_type}", "commands",
                 payload.target_type,
                 str(payload.target_ids),
                 user.get("username", "admin"), {"command_id": result["command_id"]})
    conn.commit()
    conn.close()
    return result


@router.get("")
async def list_commands(
    status: str = None,
    command_type: str = None,
    page: int = Query(1, ge=1),
    limit: int = Query(50, ge=1, le=200),
    user: dict = Depends(authenticate_request),
):
    engine = _get_engine()
    return engine.list_commands(status=status, command_type=command_type, page=page, limit=limit)


@router.get("/{command_id}")
async def get_command(command_id: str, user: dict = Depends(authenticate_request)):
    engine = _get_engine()
    cmd = engine.get_command(command_id)
    if not cmd:
        raise HTTPException(status_code=404, detail="Command not found")
    return cmd


@router.get("/{command_id}/acknowledgments")
async def get_acknowledgments(command_id: str, user: dict = Depends(authenticate_request)):
    engine = _get_engine()
    return {"command_id": command_id, "acknowledgments": engine.get_acknowledgments(command_id)}


@router.post("/agent/poll")
async def agent_poll_commands(payload: AgentPollRequest, user: dict = Depends(authenticate_request)):
    endpoint_id = payload.endpoint_id
    if not endpoint_id:
        raise HTTPException(status_code=400, detail="endpoint_id required")
    engine = _get_engine()
    pending = engine.get_pending_for_agent(endpoint_id)
    conn = get_connection()
    conn.execute("UPDATE endpoints SET last_seen = ?, health_status = 'ONLINE' WHERE endpoint_id = ?",
                 (int(time.time()), endpoint_id))
    conn.commit()
    conn.close()
    return {"commands": pending, "count": len(pending)}


@router.post("/agent/acknowledge")
async def agent_acknowledge(payload: AgentAckRequest, user: dict = Depends(authenticate_request)):
    command_id = payload.command_id
    endpoint_id = payload.endpoint_id
    if not command_id or not endpoint_id:
        raise HTTPException(status_code=400, detail="command_id and endpoint_id required")
    engine = _get_engine()
    result = engine.acknowledge(command_id, endpoint_id, payload.output)
    if result.get("status") == "error":
        raise HTTPException(status_code=400, detail=result["detail"])
    return result


@router.post("/agent/complete")
async def agent_complete(payload: AgentCompleteRequest, user: dict = Depends(authenticate_request)):
    command_id = payload.command_id
    endpoint_id = payload.endpoint_id
    if not command_id or not endpoint_id:
        raise HTTPException(status_code=400, detail="command_id and endpoint_id required")
    engine = _get_engine()
    result = engine.complete(command_id, endpoint_id, payload.status == "COMPLETED", payload.output)
    return result
