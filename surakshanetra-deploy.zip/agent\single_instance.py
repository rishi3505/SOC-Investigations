import ctypes
import ctypes.wintypes
import logging

logger = logging.getLogger(__name__)

_MUTEX_NAME = "Global\\SurakshaNetraAgent-SingleInstance-{A3F2B8C1-9D4E-4F7A-B6C5-1E2D3F4A5B6C}"
_mutex_handle = None


def _create_mutex(name: str) -> int:
    kernel32 = ctypes.windll.kernel32
    return kernel32.CreateMutexW(None, False, name)


def _get_last_error() -> int:
    kernel32 = ctypes.windll.kernel32
    return kernel32.GetLastError()


ERROR_ALREADY_EXISTS = 183


def try_acquire() -> bool:
    global _mutex_handle

    if _mutex_handle is not None:
        return True

    handle = _create_mutex(_MUTEX_NAME)
    if handle == 0:
        logger.error("Failed to create mutex (error %d)", _get_last_error())
        return False

    err = _get_last_error()
    if err == ERROR_ALREADY_EXISTS:
        ctypes.windll.kernel32.CloseHandle(handle)
        logger.warning("Another instance of SurakshaNetra Agent is already running")
        return False

    _mutex_handle = handle
    logger.debug("Single-instance mutex acquired")
    return True


def release():
    global _mutex_handle
    if _mutex_handle is not None:
        ctypes.windll.kernel32.ReleaseMutex(_mutex_handle)
        ctypes.windll.kernel32.CloseHandle(_mutex_handle)
        _mutex_handle = None
        logger.debug("Single-instance mutex released")
