"""
Inventory Manager — Collects, stores, and versions endpoint hardware/software inventory.
Tracks changes over time for forensic and compliance purposes.
"""
import hashlib
import json
import time
from fastapi import APIRouter, Depends, HTTPException, Query
from ..database import get_connection
from ..auth import authenticate_request

router = APIRouter(prefix="/api/v1/inventory", tags=["Inventory Manager"])


def _hash_inventory(inv: dict) -> str:
    return hashlib.md5(json.dumps(inv, sort_keys=True).encode()).hexdigest()


@router.post("/report/{endpoint_id}")
async def report_inventory(endpoint_id: str, payload: dict, user: dict = Depends(authenticate_request)):
    conn = get_connection()
    now = int(time.time())

    inventory = {
        "hostname": payload.get("hostname", ""),
        "os": payload.get("os", ""),
        "os_version": payload.get("os_version", ""),
        "os_build": payload.get("os_build", ""),
        "architecture": payload.get("architecture", ""),
        "cpu_brand": payload.get("cpu_brand", ""),
        "cpu_cores": payload.get("cpu_cores", 0),
        "cpu_threads": payload.get("cpu_threads", 0),
        "total_ram_mb": payload.get("total_ram_mb", 0),
        "disk_count": payload.get("disk_count", 0),
        "total_disk_gb": payload.get("total_disk_gb", 0),
        "free_disk_gb": payload.get("free_disk_gb", 0),
        "gpu_info": json.dumps(payload.get("gpu_info", [])),
        "network_interfaces": json.dumps(payload.get("network_interfaces", [])),
        "installed_software": json.dumps(payload.get("installed_software", [])),
        "security_software": json.dumps(payload.get("security_software", [])),
        "python_version": payload.get("python_version", ""),
        "agent_version": payload.get("agent_version", ""),
        "agent_build": payload.get("agent_build", 0),
        "device_fingerprint": json.dumps(payload.get("device_fingerprint", {})),
        "windows_edition": payload.get("windows_edition", ""),
        "windows_install_date": payload.get("windows_install_date", ""),
        "last_boot": payload.get("last_boot", ""),
        "collected_at": now,
    }

    inventory_hash = _hash_inventory(inventory)

    existing = conn.execute("SELECT inventory_hash FROM endpoints WHERE endpoint_id = ?", (endpoint_id,)).fetchone()
    if existing and existing["inventory_hash"] == inventory_hash:
        conn.execute("UPDATE endpoints SET inventory_updated_at = ? WHERE endpoint_id = ?", (now, endpoint_id))
        conn.commit()
        conn.close()
        return {"status": "unchanged", "hash": inventory_hash}

    old_row = None
    if existing:
        old_row = conn.execute("SELECT * FROM inventories WHERE endpoint_id = ?", (endpoint_id,)).fetchone()

    conn.execute("""
        INSERT OR REPLACE INTO inventories
            (endpoint_id, hostname, os, os_version, os_build, architecture,
             cpu_brand, cpu_cores, cpu_threads, total_ram_mb, disk_count,
             total_disk_gb, free_disk_gb, gpu_info, network_interfaces,
             installed_software, security_software, python_version,
             agent_version, agent_build, device_fingerprint, windows_edition,
             windows_install_date, last_boot, collected_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (endpoint_id, inventory["hostname"], inventory["os"], inventory["os_version"],
          inventory["os_build"], inventory["architecture"], inventory["cpu_brand"],
          inventory["cpu_cores"], inventory["cpu_threads"], inventory["total_ram_mb"],
          inventory["disk_count"], inventory["total_disk_gb"], inventory["free_disk_gb"],
          inventory["gpu_info"], inventory["network_interfaces"],
          inventory["installed_software"], inventory["security_software"],
          inventory["python_version"], inventory["agent_version"], inventory["agent_build"],
          inventory["device_fingerprint"], inventory["windows_edition"],
          inventory["windows_install_date"], inventory["last_boot"], now))

    changed_fields = []
    if old_row:
        old = dict(old_row)
        for key in inventory:
            if str(old.get(key, "")) != str(inventory[key]):
                changed_fields.append(key)
    else:
        changed_fields = list(inventory.keys())

    conn.execute(
        "INSERT INTO inventory_history (endpoint_id, snapshot, changed_fields, collected_at) VALUES (?, ?, ?, ?)",
        (endpoint_id, json.dumps(inventory), json.dumps(changed_fields), now),
    )
    conn.execute("UPDATE endpoints SET inventory_hash = ?, inventory_updated_at = ? WHERE endpoint_id = ?",
                 (inventory_hash, now, endpoint_id))
    conn.commit()
    conn.close()
    return {"status": "recorded", "hash": inventory_hash, "changes": len(changed_fields), "changed_fields": changed_fields}


@router.get("/{endpoint_id}")
async def get_inventory(endpoint_id: str, user: dict = Depends(authenticate_request)):
    conn = get_connection()
    row = conn.execute("SELECT * FROM inventories WHERE endpoint_id = ?", (endpoint_id,)).fetchone()
    conn.close()
    if not row:
        raise HTTPException(status_code=404, detail="No inventory for endpoint")
    inv = dict(row)
    for json_field in ("gpu_info", "network_interfaces", "installed_software", "security_software", "device_fingerprint"):
        try:
            inv[json_field] = json.loads(inv[json_field])
        except (json.JSONDecodeError, TypeError):
            pass
    return inv


@router.get("/{endpoint_id}/history")
async def get_inventory_history(endpoint_id: str, limit: int = Query(50, ge=1, le=200), user: dict = Depends(authenticate_request)):
    conn = get_connection()
    rows = conn.execute(
        "SELECT * FROM inventory_history WHERE endpoint_id = ? ORDER BY collected_at DESC LIMIT ?",
        (endpoint_id, limit),
    ).fetchall()
    conn.close()
    return {"endpoint_id": endpoint_id, "history": [dict(r) for r in rows]}


@router.get("/software/{endpoint_id}")
async def get_installed_software(endpoint_id: str, user: dict = Depends(authenticate_request)):
    conn = get_connection()
    row = conn.execute("SELECT installed_software FROM inventories WHERE endpoint_id = ?", (endpoint_id,)).fetchone()
    conn.close()
    if not row:
        raise HTTPException(status_code=404, detail="No inventory for endpoint")
    try:
        software = json.loads(row["installed_software"])
    except (json.JSONDecodeError, TypeError):
        software = []
    return {"endpoint_id": endpoint_id, "software": software, "count": len(software)}
