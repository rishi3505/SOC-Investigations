"""
Configuration Sync — Periodically fetches assigned configuration profile from CMS
and applies it locally. Reports configuration drift.
"""
import json
import threading
import time
from typing import Optional

import requests

from .logging_setup import get_logger

logger = get_logger("communication")


class ConfigSync:
    def __init__(self, cms_url: str, device_id: str, local_config_path: str, sync_interval: float = 300.0):
        self._cms_url = cms_url.rstrip("/")
        self._device_id = device_id
        self._local_config_path = local_config_path
        self._sync_interval = sync_interval
        self._thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        self._current_version = "0"

    def start(self):
        if self._thread and self._thread.is_alive():
            return
        self._stop_event.clear()
        self._thread = threading.Thread(target=self._run, name="config-sync", daemon=True)
        self._thread.start()
        logger.info("Config sync started (interval=%ds)", self._sync_interval)

    def stop(self):
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=5)
        logger.info("Config sync stopped")

    def sync_now(self) -> dict:
        try:
            resp = requests.post(
                f"{self._cms_url}/api/v1/config/sync/{self._device_id}",
                json={},
                timeout=10,
            )
            if resp.status_code == 200:
                data = resp.json()
                config = data.get("config", {})
                version = data.get("config_version", "0")
                if config:
                    with open(self._local_config_path, "w") as f:
                        json.dump(config, f, indent=2)
                    self._current_version = version
                    logger.info("Config synced to version %s", version)
                return {"success": True, "version": version, "config": config}
            else:
                logger.warning("Config sync returned HTTP %d", resp.status_code)
                return {"success": False, "error": f"HTTP {resp.status_code}"}
        except Exception as e:
            logger.error("Config sync failed: %s", e)
            return {"success": False, "error": str(e)}

    def report_drift(self, expected_version: str, actual_version: str, drift_details: dict):
        try:
            requests.post(
                f"{self._cms_url}/api/v1/config/drift/report",
                json={
                    "endpoint_id": self._device_id,
                    "expected_version": expected_version,
                    "actual_version": actual_version,
                    "drift_details": drift_details,
                },
                timeout=10,
            )
        except Exception as e:
            logger.error("Drift report failed: %s", e)

    def _run(self):
        # Sync immediately on start, then periodically
        self.sync_now()
        while not self._stop_event.wait(self._sync_interval):
            self.sync_now()
