"""
Feed Manager — Ingests threat intelligence feeds from external sources
(URLs, local files, STIX/TAXII) and populates the local IOC database.
"""
import csv
import json
import os
import time
from dataclasses import dataclass
from typing import Optional
from urllib.request import urlopen, Request
from urllib.error import URLError

import sqlite3

from threat_intelligence.ioc_manager import IOC_TYPES, bulk_add_iocs


FEED_DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ioc_store.db")

SEVERITY_MAP = {"low": "LOW", "medium": "MEDIUM", "high": "HIGH", "critical": "CRITICAL",
                "info": "LOW", "warning": "MEDIUM", "minor": "LOW", "major": "HIGH"}

CONFIDENCE_MAP = {"low": "LOW", "medium": "MEDIUM", "high": "HIGH", "very_high": "VERY_HIGH",
                  "certain": "VERY_HIGH", "likely": "HIGH", "possible": "MEDIUM", "unlikely": "LOW"}


@dataclass
class FeedConfig:
    name: str
    url: str
    format: str  # csv, json, stix, text
    enabled: bool = True
    interval_minutes: int = 60
    ioc_type: str = "IP"
    api_key: str = ""
    headers: Optional[dict] = None
    field_mapping: Optional[dict] = None


FEED_REGISTRY = [
    FeedConfig(name="AlienVault OTX Pulse", url="https://otx.alienvault.com/api/v1/indicators/export",
               format="json", enabled=False, interval_minutes=360, api_key="",
               field_mapping={"indicator": "value", "type": "type", "description": "description"}),
    FeedConfig(name="AbuseIPDB", url="https://feeds.abuseipdb.com/blacklist.csv",
               format="csv", enabled=False, interval_minutes=60, ioc_type="IP"),
    FeedConfig(name="URLhaus", url="https://urlhaus.abuse.ch/downloads/csv_recent/",
               format="csv", enabled=False, interval_minutes=60, ioc_type="URL"),
]


def _feed_conn() -> sqlite3.Connection:
    conn = sqlite3.connect(FEED_DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_feeds_table():
    conn = _feed_conn()
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS threat_feeds (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            url TEXT NOT NULL,
            format TEXT DEFAULT 'json',
            enabled INTEGER DEFAULT 1,
            interval_minutes INTEGER DEFAULT 60,
            last_run INTEGER,
            next_run INTEGER,
            last_status TEXT DEFAULT 'never',
            last_error TEXT,
            total_imported INTEGER DEFAULT 0,
            ioc_type TEXT DEFAULT 'IP',
            created_at INTEGER NOT NULL,
            api_key TEXT DEFAULT ''
        );
    """)
    conn.commit()
    conn.close()


def register_feeds() -> int:
    conn = _feed_conn()
    now = int(time.time())
    count = 0
    for feed in FEED_REGISTRY:
        try:
            conn.execute("""
                INSERT OR IGNORE INTO threat_feeds
                    (name, url, format, enabled, interval_minutes, ioc_type, api_key, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (feed.name, feed.url, feed.format, 1 if feed.enabled else 0,
                  feed.interval_minutes, feed.ioc_type, feed.api_key, now))
            count += 1
        except Exception:
            pass
    conn.commit()
    conn.close()
    return count


def get_feeds() -> list[dict]:
    conn = _feed_conn()
    rows = conn.execute("SELECT * FROM threat_feeds ORDER BY name").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def update_feed_config(feed_id: int, **kwargs) -> bool:
    allowed = {"enabled", "interval_minutes", "api_key", "url", "ioc_type"}
    updates = {k: v for k, v in kwargs.items() if k in allowed}
    if not updates:
        return False
    set_clause = ", ".join(f"{k} = ?" for k in updates)
    conn = _feed_conn()
    conn.execute(f"UPDATE threat_feeds SET {set_clause} WHERE id = ?", (*updates.values(), feed_id))
    conn.commit()
    conn.close()
    return True


def fetch_feed(feed: dict) -> tuple[list[dict], str]:
    url = feed["url"]
    headers = {"User-Agent": "AI-Continuous-Auth-XDR/2.0"}
    if feed.get("api_key"):
        headers["Authorization"] = f"Bearer {feed['api_key']}"
    try:
        req = Request(url, headers=headers)
        with urlopen(req, timeout=30) as resp:
            raw = resp.read().decode("utf-8", errors="replace")
    except URLError as e:
        return [], f"Network error: {e.reason}"
    except Exception as e:
        return [], f"Fetch error: {e}"

    fmt = feed.get("format", "json")
    iocs = []
    try:
        if fmt == "json":
            data = json.loads(raw)
            iocs = _parse_json_feed(data, feed)
        elif fmt == "csv":
            iocs = _parse_csv_feed(raw, feed)
        elif fmt == "text":
            iocs = _parse_text_feed(raw, feed)
        elif fmt == "stix":
            data = json.loads(raw)
            iocs = _parse_stix_feed(data, feed)
        else:
            return [], f"Unsupported format: {fmt}"
    except Exception as e:
        return [], f"Parse error: {e}"
    return iocs, ""


def _parse_json_feed(data: dict | list, feed: dict) -> list[dict]:
    iocs = []
    mapping = feed.get("field_mapping") or {}
    default_type = feed.get("ioc_type", "IP")
    items = data if isinstance(data, list) else data.get("results", data.get("indicators", [data]))
    for item in items:
        if not isinstance(item, dict):
            continue
        value = item.get(mapping.get("value", "value")) or item.get("indicator") or item.get("ip") or ""
        if not value:
            continue
        ioc_type = (item.get(mapping.get("type", "type")) or default_type).upper()
        ioc_type = _normalize_type(ioc_type)
        if not ioc_type:
            continue
        iocs.append({
            "ioc_type": ioc_type, "value": str(value).strip(),
            "threat_family": item.get("threat_family") or item.get("malware") or item.get("family") or "UNKNOWN",
            "severity": _map_severity(item.get("severity", "")),
            "confidence": _map_confidence(item.get("confidence", "")),
            "source": feed["name"],
            "description": str(item.get(mapping.get("description", "description")) or "")[:500],
            "mitre_technique_id": item.get("mitre_technique_id") or "",
        })
    return iocs


def _parse_csv_feed(raw: str, feed: dict) -> list[dict]:
    iocs = []
    default_type = feed.get("ioc_type", "IP")
    reader = csv.DictReader(raw.splitlines())
    for row in reader:
        value = (row.get("value") or row.get("indicator") or row.get("ip") or row.get("ioc") or "").strip()
        if not value:
            continue
        ioc_type = (row.get("type") or default_type).upper()
        ioc_type = _normalize_type(ioc_type)
        if not ioc_type:
            continue
        iocs.append({
            "ioc_type": ioc_type, "value": value,
            "threat_family": row.get("threat_family", "UNKNOWN"),
            "severity": _map_severity(row.get("severity", "")),
            "confidence": _map_confidence(row.get("confidence", "")),
            "source": feed["name"],
            "description": (row.get("description") or "")[:500],
        })
    return iocs


def _parse_text_feed(raw: str, feed: dict) -> list[dict]:
    iocs = []
    default_type = feed.get("ioc_type", "IP")
    for line in raw.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or line.startswith("//"):
            continue
        iocs.append({
            "ioc_type": default_type, "value": line,
            "threat_family": "UNKNOWN", "severity": "MEDIUM",
            "confidence": "MEDIUM", "source": feed["name"],
            "description": "",
        })
    return iocs


def _parse_stix_feed(data: dict, feed: dict) -> list[dict]:
    import re
    iocs = []
    objects = data.get("objects", [])
    for obj in objects:
        if obj.get("type") not in ("indicator", "observed-data"):
            continue
        pattern = obj.get("pattern", "")
        m = re.search(r"\[(?:file|ipv4-addr|domain-name|url):value\s*=\s*'([^']+)'\]", pattern)
        value = m.group(1) if m else ""
        if not value:
            continue
        iocs.append({
            "ioc_type": feed.get("ioc_type", "IP"), "value": value,
            "threat_family": obj.get("malware", ["UNKNOWN"])[0] if isinstance(obj.get("malware"), list) else "UNKNOWN",
            "severity": _map_severity(obj.get("severity", "")),
            "confidence": _map_confidence(obj.get("confidence", "")),
            "source": feed["name"],
            "description": (obj.get("description") or "")[:500],
        })
    return iocs


def _normalize_type(t: str) -> str:
    mapping = {
        "IPV4": "IP", "IPV6": "IP", "IP_ADDRESS": "IP", "IPADDR": "IP",
        "DOMAIN": "DOMAIN", "DOMAIN_NAME": "DOMAIN", "HOSTNAME": "DOMAIN",
        "URL": "URL", "URI": "URL",
        "SHA256": "SHA256", "HASH": "SHA256", "FILE_HASH": "SHA256",
        "MD5": "MD5",
        "PROCESS": "PROCESS_NAME", "PROCESSNAME": "PROCESS_NAME",
        "REGISTRY": "REGISTRY_KEY", "REGKEY": "REGISTRY_KEY",
        "TASK": "SCHEDULED_TASK", "SCHTASK": "SCHEDULED_TASK",
        "SERVICE": "SERVICE_NAME",
        "USERAGENT": "USER_AGENT", "UA": "USER_AGENT",
        "EMAIL": "EMAIL", "EMAIL_ADDRESS": "EMAIL",
    }
    return mapping.get(t.upper(), t if t in IOC_TYPES else "")


def import_feed_results(feed_name: str, iocs: list[dict]) -> tuple[int, int]:
    if not iocs:
        return 0, 0
    imported = bulk_add_iocs([
        {"ioc_type": i["ioc_type"], "value": i["value"],
         "threat_family": i.get("threat_family", "UNKNOWN"),
         "severity": i.get("severity", "MEDIUM"),
         "confidence": i.get("confidence", "MEDIUM"),
         "source": feed_name,
         "description": i.get("description", ""),
         "mitre_technique_id": i.get("mitre_technique_id", ""),
         "mitre_technique_name": i.get("mitre_technique_name", ""),
         "mitre_tactic": i.get("mitre_tactic", ""),
         "tags": i.get("tags", []),
         "reference_url": i.get("reference_url", "")}
        for i in iocs
    ])
    return imported, max(0, len(iocs) - imported)


def run_feed(feed_id: int) -> dict:
    conn = _feed_conn()
    row = conn.execute("SELECT * FROM threat_feeds WHERE id = ?", (feed_id,)).fetchone()
    if not row:
        conn.close()
        return {"status": "error", "message": "Feed not found"}
    feed = dict(row)
    now = int(time.time())
    iocs, error = fetch_feed(feed)
    if error:
        conn.execute("UPDATE threat_feeds SET last_run=?, next_run=?, last_status='error', last_error=? WHERE id=?",
                      (now, now + feed["interval_minutes"] * 60, str(error)[:500], feed_id))
        conn.commit()
        conn.close()
        return {"status": "error", "message": error}
    imported, failed = import_feed_results(feed["name"], iocs)
    conn.execute("""UPDATE threat_feeds SET last_run=?, next_run=?, last_status='success',
        last_error=NULL, total_imported=total_imported+? WHERE id=?""",
                 (now, now + feed["interval_minutes"] * 60, imported, feed_id))
    conn.commit()
    conn.close()
    return {"status": "success", "imported": imported, "failed": failed, "total": len(iocs)}


def run_all_due_feeds() -> list[dict]:
    now = int(time.time())
    conn = _feed_conn()
    due = conn.execute(
        "SELECT * FROM threat_feeds WHERE enabled = 1 AND (next_run IS NULL OR next_run <= ?)", (now,)
    ).fetchall()
    conn.close()
    results = []
    for feed in due:
        results.append(run_feed(feed["id"]))
    return results


def _map_severity(s: str) -> str:
    return SEVERITY_MAP.get(s.strip().lower(), "MEDIUM")


def _map_confidence(c: str) -> str:
    return CONFIDENCE_MAP.get(c.strip().lower(), "MEDIUM")
