# SurakshaNetra API Reference v1.0.0

Base URL: `http://<host>:9000` (CMS) or `http://<host>:8000` (ML Service)

---

## Central Management Server (Port 9000)

### Health & Status

**GET** `/health`
- Response: `{"status":"online","service":"central-management-server","version":"2.0.0","timestamp":<unix>}`

### Authentication

**POST** `/api/v1/auth/login`
- Body: `{"username":"admin","password":"..."}`
- Response: `{"access_token":"...","token_type":"bearer"}`

All other endpoints require `Authorization: Bearer <token>` or `X-API-Key: <key>` header.

### Endpoint Management

**GET** `/api/v1/endpoints` — List endpoints (paginated, filterable)
**GET** `/api/v1/endpoints/{id}` — Endpoint details + lifecycle timeline
**PUT** `/api/v1/endpoints/{id}` — Update tags/metadata
**GET** `/api/v1/endpoints/{id}/timeline` — Lifecycle timeline

### Agent Registry

**POST** `/api/v1/agent/register` — Register new agent
**GET** `/api/v1/agent/status/{id}` — Agent status

### Heartbeat

**POST** `/api/v1/agent/heartbeat` — Receive agent heartbeat
**GET** `/api/v1/agent/heartbeat/status` — Heartbeat status summary

### Incident Management

**GET** `/api/v1/incidents` — List incidents (paginated, filterable)
**GET** `/api/v1/incidents/stats` — Aggregated incident statistics
**GET** `/api/v1/incidents/{id}` — Incident detail
**PUT** `/api/v1/incidents/{id}/status` — Update incident status
**POST** `/api/v1/incidents/{id}/containment` — Trigger containment actions
**GET** `/api/v1/incidents/{id}/evidence` — List evidence packages
**GET** `/api/v1/incidents/{id}/evidence/{package_id}/download` — Download evidence ZIP

### Device Registry

**GET** `/api/v1/devices` — List devices
**POST** `/api/v1/devices/register` — Register device
**POST** `/api/v1/devices/approve` — Approve device
**POST** `/api/v1/devices/revoke` — Revoke device

### Policy Management

**GET** `/api/v1/policies` — List policies
**POST** `/api/v1/policies` — Create policy
**PUT** `/api/v1/policies/{id}` — Update policy
**DELETE** `/api/v1/policies/{id}` — Delete policy
**POST** `/api/v1/policies/{id}/push` — Push policy to endpoints
**GET** `/api/v1/policies/agent` — Get latest policy (for agent)

### Configuration Profiles

**GET** `/api/v1/config/profiles` — List config profiles
**POST** `/api/v1/config/profiles` — Create profile
**PUT** `/api/v1/config/profiles/{id}` — Update profile
**DELETE** `/api/v1/config/profiles/{id}` — Delete profile
**GET** `/api/v1/config/assignments` — List assignments
**POST** `/api/v1/config/assign` — Assign profile to endpoint
**POST** `/api/v1/config/sync` — Agent config sync
**GET** `/api/v1/config/drift` — Config drift log

### Update Management

**GET** `/api/v1/updates/releases` — List releases
**POST** `/api/v1/updates/releases` — Create release
**PUT** `/api/v1/updates/releases/{id}` — Update release status
**POST** `/api/v1/updates/deploy` — Deploy update
**GET** `/api/v1/updates/deployments` — List deployments
**GET** `/api/v1/updates/status/{endpoint_id}` — Check update status
**POST** `/api/v1/updates/check` — Check for updates

### Lifecycle Management

**GET** `/api/v1/lifecycle/states` — List lifecycle states
**GET** `/api/v1/lifecycle/endpoints` — List endpoints with lifecycle status
**POST** `/api/v1/lifecycle/transition` — Transition endpoint state
**GET** `/api/v1/lifecycle/history/{endpoint_id}` — Lifecycle history
**POST** `/api/v1/lifecycle/bulk-transition` — Bulk state transition

### Remote Commands

**GET** `/api/v1/commands/types` — List command types
**POST** `/api/v1/commands/issue` — Issue remote command
**GET** `/api/v1/commands` — List commands
**POST** `/api/v1/commands/poll` — Agent polls for pending commands
**POST** `/api/v1/commands/acknowledge` — Agent acknowledges
**POST** `/api/v1/commands/complete` — Agent reports completion

### Health Monitoring

**POST** `/api/v1/health/snapshot` — Record health snapshot
**GET** `/api/v1/health/history` — Health history
**GET** `/api/v1/health/score/{endpoint_id}` — Health score
**GET** `/api/v1/health/overview` — Health overview

### Inventory

**POST** `/api/v1/inventory/report` — Agent reports inventory
**GET** `/api/v1/inventory` — Get inventory
**GET** `/api/v1/inventory/history` — Inventory change history
**GET** `/api/v1/inventory/software` — Software inventory

### Group Management

**GET** `/api/v1/groups` — List groups
**POST** `/api/v1/groups` — Create group
**PUT** `/api/v1/groups/{id}` — Update group
**DELETE** `/api/v1/groups/{id}` — Delete group
**POST** `/api/v1/groups/{id}/members` — Add member
**DELETE** `/api/v1/groups/{id}/members/{member_id}` — Remove member

### Audit Logs

**GET** `/api/v1/audit` — List audit logs
**GET** `/api/v1/audit/summary` — Audit summary

### Notifications

**GET** `/api/v1/notifications` — List notifications
**POST** `/api/v1/notifications/mark-read` — Mark notification read
**POST** `/api/v1/notifications/read-all` — Mark all read
**GET** `/api/v1/notifications/unread-count` — Unread count

### Analytics

**GET** `/api/v1/analytics/overview` — Dashboard overview stats
**GET** `/api/v1/analytics/trends` — Incident trends
**GET** `/api/v1/analytics/mttd` — Mean Time to Detect
**GET** `/api/v1/analytics/mttr` — Mean Time to Respond/Resolve
**GET** `/api/v1/analytics/policy-triggers` — Policy trigger stats
**GET** `/api/v1/analytics/health-trends` — Health trends
**GET** `/api/v1/analytics/false-positive-rate` — False positive rate

### Threat Intelligence

**GET** `/api/v1/threat-intel/iocs` — List IOCs
**POST** `/api/v1/threat-intel/iocs` — Create IOC
**PUT** `/api/v1/threat-intel/iocs/{id}` — Update IOC
**DELETE** `/api/v1/threat-intel/iocs/{id}` — Delete IOC
**GET** `/api/v1/threat-intel/iocs/stats` — IOC statistics
**POST** `/api/v1/threat-intel/iocs/match` — Match value against IOCs
**GET** `/api/v1/threat-intel/reputation/{value}` — Get reputation
**POST** `/api/v1/threat-intel/score` — Compute threat score
**GET** `/api/v1/threat-intel/feeds` — List feeds
**POST** `/api/v1/threat-intel/feeds/{id}/fetch` — Fetch feed
**GET** `/api/v1/threat-intel/rules` — List detection rules
**GET** `/api/v1/threat-intel/hunts` — List hunt results
**PUT** `/api/v1/threat-intel/hunts/{id}` — Update hunt result

### Search

**GET** `/api/v1/dashboard/search?q=<query>` — Global search across endpoints, devices, groups

---

## ML Service (Port 8000)

### Health

**GET** `/health`
- Response: `{"status":"online","model_loaded":true,"records_buffered":<count>}`

### Analyze

**POST** `/api/v1/analyze`
- Body: `{typing_speed, key_latency, avg_hold_time, latency_jitter, mouse_speed, mouse_acceleration, direction_change_freq, click_frequency, active_app, app_switch_count, idle_time, time_of_day, session_duration, user_id, ip_address, city, country, device_hash}`
- Response: `{risk_level, risk_score, confidence, session_active, ...}`

### Feedback

**POST** `/api/v1/feedback`
- Body: `{"behavior_id":<int>, "label":"anomaly"|"normal"}`

### Retrain

**POST** `/api/v1/retrain`
- Response: `{"status":"retrain_started","message":"..."}`

### Dashboard

**GET** `/api/v1/dashboard/stats`
**GET** `/api/v1/dashboard/sessions/{user_id}`
**GET** `/api/v1/dashboard/behavior/{user_id}`
**GET** `/api/v1/dashboard/locations`
**GET** `/api/v1/dashboard/thresholds/{user_id}`

### Incidents

**GET** `/api/v1/incidents` — List incidents
**GET** `/api/v1/incidents/{id}` — Incident detail
**PUT** `/api/v1/incidents/{id}/status` — Update status
**GET** `/api/v1/incidents/{id}/evidence` — Evidence list
**GET** `/api/v1/incidents/{id}/evidence/{package_id}/download` — Download ZIP

### MFA

**POST** `/api/v1/mfa-result` — Submit MFA challenge result

### Response History / Policy Audit

**GET** `/api/v1/response-history`
**GET** `/api/v1/policy-audit`

### MITRE

**GET** `/api/v1/mitre-techniques` — List MITRE techniques

### User State

**GET** `/api/v1/user-state/{user_id}` — Get user state (risk, threshold, session)

### Devices

**GET** `/api/v1/devices` — List devices
**POST** `/api/v1/devices/approve` — Approve device
**GET** `/api/v1/devices/history?device_hash=<hash>` — Device history

### Trusted Locations

**GET** `/api/v1/trusted-locations` — List trusted locations
