import time
import win32gui
import win32process
import psutil
from datetime import datetime

class SystemMonitor:
    """
    Monitors system-level context, such as active foreground applications,
    app switches, session duration, and calendar time properties.
    """
    def __init__(self):
        # Time the agent started running
        self.session_start = time.time()
        self.last_app = None
        self.app_switch_count = 0
        
    def get_active_app(self):
        """
        Uses win32gui to identify the exact foreground application, 
        giving clear application names (e.g., 'chrome', 'Code') for better ML data.
        """
        try:
            hwnd = win32gui.GetForegroundWindow()
            if hwnd:
                _, pid = win32process.GetWindowThreadProcessId(hwnd)
                try:
                    proc_name = psutil.Process(pid).name()
                    if proc_name.lower().endswith(".exe"):
                        proc_name = proc_name[:-4] # e.g. chrome.exe -> chrome
                    return proc_name
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass
                
                # Fallback to window title
                window_title = win32gui.GetWindowText(hwnd)
                if window_title:
                    return window_title[:30]
        except Exception:
            pass
            
        return "Unknown"

    def update_app_switch(self, current_app):
        """Counts how many times the active application changes during the interval."""
        if self.last_app is not None and self.last_app != current_app:
            self.app_switch_count += 1
        self.last_app = current_app

    def get_metrics_and_reset(self):
        """Returns the active application, application switch count, 
        time of day, and session duration."""
        current_app = self.get_active_app()
        self.update_app_switch(current_app)
        
        current_time = time.time()
        session_duration = current_time - self.session_start
        dt_now = datetime.fromtimestamp(current_time)
        time_of_day = dt_now.hour # 0-23
        
        metrics = {
            "active_app": current_app,
            "app_switch_count": self.app_switch_count,
            "time_of_day": time_of_day,
            "session_duration": session_duration
        }
        
        # Reset switch count for tracking distinct switches per interval
        self.app_switch_count = 0
        
        return metrics
