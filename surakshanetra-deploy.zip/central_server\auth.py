"""
Central Management Server — JWT & API Key Authentication
"""
import hashlib
import hmac
import json
import time
import uuid
from functools import wraps

from fastapi import HTTPException, Request
from jose import JWTError, jwt

from .config import JWT_SECRET, JWT_ALGORITHM, JWT_EXPIRY_HOURS, API_KEY_HEADER
from .database import get_connection


def create_token(user_id: int, username: str, role: str, org_id: int = None) -> str:
    payload = {
        "sub": str(user_id),
        "username": username,
        "role": role,
        "org_id": org_id,
        "iat": int(time.time()),
        "exp": int(time.time()) + JWT_EXPIRY_HOURS * 3600,
        "jti": uuid.uuid4().hex,
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)


def decode_token(token: str) -> dict:
    try:
        return jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
    except JWTError as e:
        raise HTTPException(status_code=401, detail=f"Invalid token: {e}")


def verify_api_key(api_key: str) -> dict:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id, username, role, org_id FROM users WHERE api_key = ?", (api_key,))
    row = cursor.fetchone()
    conn.close()
    if not row:
        raise HTTPException(status_code=401, detail="Invalid API key")
    return {"user_id": row["id"], "username": row["username"], "role": row["role"], "org_id": row["org_id"]}


def generate_api_key() -> str:
    return f"ak_{uuid.uuid4().hex}_{int(time.time())}"


async def authenticate_request(request: Request) -> dict:
    auth_header = request.headers.get("Authorization", "")
    api_key = request.headers.get(API_KEY_HEADER, "")

    if auth_header.startswith("Bearer "):
        token = auth_header[7:]
        return decode_token(token)
    elif api_key:
        return verify_api_key(api_key)

    raise HTTPException(status_code=401, detail="Authentication required")


def require_role(role: str):
    async def role_checker(request: Request):
        user = await authenticate_request(request)
        if user.get("role") != role and role != "any":
            allowed_roles = {"admin": ["admin"], "analyst": ["admin", "analyst"], "viewer": ["admin", "analyst", "viewer"]}
            if user.get("role") not in allowed_roles.get(role, []):
                raise HTTPException(status_code=403, detail="Insufficient permissions")
        return user
    return role_checker
