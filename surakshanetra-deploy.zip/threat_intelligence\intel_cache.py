"""
Intel Cache — In-memory cache with TTL for threat intelligence lookups.
Reduces IOC database queries for repeated artifact evaluations.
"""
import time
from collections import OrderedDict
from threading import Lock


class IntelCache:
    def __init__(self, capacity: int = 10000, ttl: int = 300):
        self._capacity = capacity
        self._ttl = ttl
        self._store: OrderedDict = OrderedDict()
        self._lock = Lock()

    def get(self, key: str):
        with self._lock:
            entry = self._store.get(key)
            if entry is None:
                return None
            if time.time() - entry["ts"] > self._ttl:
                del self._store[key]
                return None
            self._store.move_to_end(key)
            return entry["value"]

    def set(self, key: str, value):
        with self._lock:
            if len(self._store) >= self._capacity:
                self._store.popitem(last=False)
            self._store[key] = {"value": value, "ts": time.time()}

    def delete(self, key: str):
        with self._lock:
            self._store.pop(key, None)

    def clear(self):
        with self._lock:
            self._store.clear()

    def invalidate_by_prefix(self, prefix: str):
        with self._lock:
            to_delete = [k for k in self._store if k.startswith(prefix)]
            for k in to_delete:
                del self._store[k]

    def get_stats(self) -> dict:
        with self._lock:
            return {"size": len(self._store), "capacity": self._capacity, "ttl_seconds": self._ttl}

    def __len__(self):
        return len(self._store)
